# 05 — Architecture globale (C4, modules, exécution, pile)

> **Révision du 2026-11-21.** Monolithe modulaire **conservé** (une base de code, une image) mais **plusieurs processus** lancés depuis le même code : `api`, `worker` (files `sim`, `doc`, `export`). Base cible **PostgreSQL 17/18 + pgvector** ; **SQLite** conservé comme profil léger. Aucune décision de ce document n'est dimensionnée sur la machine de développement personnelle : les environnements sont décrits dans [17](17-portability-environments-ci.md) et la validation multi-machines dans [18](18-validation-strategy.md).

## 5.1 C4 niveau 1 — Contexte

```mermaid
flowchart TB
  fac(["Propriétaire / animateur<br/>de l'espace de travail"])
  ply(["Participant (siège humain)"])
  obs(["Observateur · juge · auditeur"])
  alerte[["ALERTE Platform<br/>simule des exercices de crise multi-agents,<br/>révèle et documente les lacunes institutionnelles"]]
  llm[("Serveurs de modèles OpenAI-compatibles<br/>génération + embeddings<br/>Ollama · vLLM · TEI")]
  src[/"Documents officiels du pays<br/>PDF · DOCX · MD · TXT · CSV"/]
  arc[/"Archives de KB .zip<br/>import / export"/]
  itu[("ITU AI for Good Lab / Sandbox<br/>cible de partage explicite,<br/>modalités à confirmer")]
  fac --> alerte
  ply --> alerte
  obs --> alerte
  src -->|import| alerte
  arc <-->|export · réimport| alerte
  alerte -->|complétions et embeddings| llm
  alerte -.->|publication de records<br/>sur décision explicite| itu
```

## 5.2 C4 niveau 2 — Conteneurs et processus

```mermaid
flowchart LR
  subgraph browser["Navigateur"]
    spa["SPA React 19 + TypeScript + Vite<br/>Studio · Room · Gaps · Reports · Audit"]
  end
  subgraph app["Image alerte-platform : un seul code, plusieurs processus"]
    api["Processus api<br/>FastAPI · REST + SSE<br/>ne lance jamais de simulation"]
    wsim["Worker file sim<br/>exécute les exercices"]
    wdoc["Worker files doc + export<br/>ingestion · embeddings · exports · rapports · PDF"]
  end
  pg[("PostgreSQL 17/18 + pgvector<br/>métier · jobs · ledger · vecteurs · lexical")]
  blobs[("Stockage de blobs<br/>disque ou S3-compatible")]
  llm[("Serveurs de modèles<br/>génération · embeddings")]
  spa -- "HTTPS · JSON" --> api
  spa -- "SSE (curseur sur le ledger)" --> api
  api --- pg
  wsim --- pg
  wdoc --- pg
  wdoc --- blobs
  api --- blobs
  wsim -- "HTTP /v1/chat/completions" --> llm
  wdoc -- "HTTP /v1/embeddings" --> llm
  light["Profil léger : SQLite + stockage local<br/>api + worker dans un seul processus (config)"]
  light -.-> app
```

* **Même code, configuration différente** : le profil léger remplace PostgreSQL par SQLite et peut embarquer le worker dans le processus `api` (`ALERTE_EMBEDDED_WORKER=true`) ; la logique métier, les permissions et les contrats sont identiques.
* Le SPA est construit à l'image (multi-stage) et servi par `api` ; en développement, Vite sert le front séparément.
* Les serveurs de modèles sont **hors image** et interchangeables (ports `LLMProvider` / `Embedder`).
* Aucun Redis, aucun broker : la file de jobs est dans la base (§5.6).

## 5.3 C4 niveau 3 — Composants (backend)

```mermaid
flowchart TB
  subgraph core["core — config · db (dialect) · ids · jobs · auth · blobs · canonical_json · errors · clock"]
  end
  ws["workspaces<br/>espaces · pays · institutions · domaines · membres"]
  man["mandates<br/>registre de mandats · actions · graphe"]
  kn["knowledge<br/>KB · documents · versions · ingestion · chunks<br/>index lexical+vecteur · SearchScope · archives · partage"]
  ag["agents<br/>définitions · droits · fournisseurs LLM · outils<br/>boucle · citations · décisions"]
  sc["scenarios<br/>scénarios · injects · demandes · pannes · préparation"]
  sim["simulation<br/>exercices · snapshot · sièges · état · runner<br/>tableau · coordinateur · humain · flux SSE"]
  au["audit<br/>ledger · vérification · ancres · catalogue d'événements"]
  gp["gaps<br/>règles · signaux · candidats · preuves · revues<br/>références · couverture · précédents"]
  rp["reports<br/>génération · versions · rendus · PDF · rapports importés"]
  ev["evaluation<br/>T1-T6 · scorecard · benchmarks · fixtures cachées"]
  ws --> core
  man --> ws & kn
  kn --> ws
  ag --> kn & ws & au
  sc --> ws & man
  sim --> ag & sc & au & kn & ws
  gp --> man & kn & au & ws & sc
  sim -. "hook : fin d'inject" .-> gp
  rp --> gp & au & sim & ev & ws
  ev --> au & gp & kn & sc
```

Les flèches pointent vers la **dépendance autorisée** ; tout autre import est interdit (test d'architecture, §5.5). `simulation` n'appelle `gaps` que par un point d'extension (`on_inject_closed`).

## 5.4 Modules : responsabilités, interfaces, dépendances

| Module | Responsabilité | Interface publique | Dépend de |
|---|---|---|---|
| `core` | Configuration (env), sessions DB et **adaptateurs de dialecte**, identifiants, erreurs, **authentification/autorisation** (`require_role`), **file de jobs** (claim, lease, fencing, heartbeat), blobs, JSON canonique, horloge | `get_session()`, `Settings`, `JobQueue`, `require_role`, `BlobStore` | — |
| `workspaces` | Espaces, membres, pays, institutions (portée nationale/internationale), domaines | `WorkspaceService`, `InstitutionService` | core |
| `mandates` | Registre de mandats, catalogue d'actions (`basis_kind`), validation humaine, graphe (NetworkX en mémoire) | `MandateRegistry.active_for(snapshot)` | workspaces, knowledge |
| `knowledge` | KB, documents/versions, ingestion (extraction, OCR, chunking, analyseur lexical), **ports `Embedder`/`VectorIndex`/`LexicalIndex`**, **recherche à portée contrainte**, archives, politique de partage | `search(scope, query, k)`, `IngestPipeline`, `ArchiveService` | workspaces |
| `agents` | Définitions, profils de modèle, droits, runtime, outils, citations, **port `LLMProvider`** | `AgentRuntime.activate(ctx)`, `CitationChecker` | knowledge, workspaces, audit |
| `scenarios` | Scénarios, injects, demandes, préparation | `ReadinessChecker` | workspaces, mandates |
| `simulation` | Exercices, snapshot, portée, sièges, états, **runner de job `sim`**, coordinateur, tâches humaines, flux SSE | `ExerciseService`, `ExerciseRunner`, `stream()` | agents, scenarios, audit, knowledge, workspaces |
| `audit` | Catalogue d'événements, ledger, vérification, ancres, trace | `Ledger.append()`, `verify()` | core |
| `gaps` | Règles G, signaux, candidats, preuves, couverture, revues, références | `GapEngine.detect()`, `ReferenceMatcher` | mandates, knowledge, audit, workspaces, scenarios |
| `reports` | Assemblage, versions, rendus MD/JSON/CSV/XLSX/**PDF** (port `PdfRenderer`), rapports importés, comparaison | `ReportService.generate()`, `render()` | gaps, audit, simulation, evaluation, workspaces |
| `evaluation` | T1–T6, scorecard, benchmarks, **fixtures cachées** | `EvaluationService` | audit, gaps, knowledge, scenarios |

## 5.5 Règles de dépendance et ports

1. **Graphe §5.3 seul autorisé** ; test `tests/architecture/test_imports.py` (parse des imports ; équivalent d'`import-linter`).
2. **Un module n'écrit que ses tables** ; les autres passent par son service.
3. **`evaluation.fixtures` est privé** (test d'import) ; le conteneur de production peut l'exclure.
4. **Routeurs minces** (BP-02).
5. **Ports** (interfaces) et leurs adaptateurs :

| Port | Adaptateurs prévus | Contrat de test commun |
|---|---|---|
| `LLMProvider` | `openai_compat` (Ollama, vLLM, API compatible) ; `scripted` ; `cassette` | schéma d'enveloppe, 1 retry, repli consigné |
| `Embedder` | client `/v1/embeddings` (TEI, vLLM, Ollama) ; `sentence_transformers` ; `fixture` (tests) | dimension, normalisation, **empreinte complète** |
| `VectorIndex` | `pgvector` (cible) ; `sqlite_exact` (NumPy, sans serveur) ; `qdrant` (optionnel, P2) | aucun chunk hors portée n'est jamais renvoyé ; recall@k de référence |
| `LexicalIndex` | `pg_tsvector` ; `sqlite_fts5` ; `pg_textsearch` (optionnel) | recall@10 sur requêtes de référence FR/AR |
| `PdfRenderer` | `weasyprint` ; `xhtml2pdf` | texte du PDF (extrait par pypdfium2) conforme au gabarit |
| `BlobStore` | disque ; S3-compatible | adressage par SHA-256 |
| `Clock` | système ; fixe (tests) | — |

## 5.6 Modèle d'exécution (processus, jobs, reprise)

| Élément | Conception |
|---|---|
| Processus | `python -m app.api` (FastAPI/uvicorn, **ne lance jamais de simulation ni de traitement lourd**) ; `python -m app.worker --queues sim` ; `python -m app.worker --queues doc,export`. Même code. Lancement : Docker/Podman compose **ou** `python -m app.dev` (multiplateforme, `subprocess.Popen`, groupe de processus Windows) ; mode léger : worker embarqué (thread) |
| File de jobs | Table `job` (doc 06). **Claim** : PostgreSQL `SELECT … FOR UPDATE SKIP LOCKED` ; SQLite `BEGIN IMMEDIATE` ; ordre `run_after, id`. Le claim pose `lease_owner`, un **`lease_token` aléatoire** et `lease_expires_at` |
| **Fencing** | Toute écriture d'étape d'un job s'exécute `… WHERE job_id=? AND lease_token=?` **dans la même transaction** que l'écriture métier/ledger ; si zéro ligne → le worker est un **zombie** (lease expiré et repris ailleurs) et **abandonne**. Empêche les doubles écritures après suspension/partition |
| Heartbeat | Thread dédié qui prolonge le lease ; **plus un timeout par étape** (un heartbeat ne doit pas masquer une étape bloquée) |
| Reprise | Un job `running` dont le lease a expiré redevient `queued` (tentative +1) ; au démarrage d'un worker, balayage des jobs expirés ; `max_attempts` puis `failed` avec erreur |
| Idempotence | `idempotency_key` unique par création ; étapes de simulation identifiées par `step_key` ; un appel LLM déjà enregistré (`llm_call`, même `step_key`+`prompt_sha256`) est **réutilisé** ; sinon nouvel appel inscrit `LLM_CALL` (`retried=true`) (*effectively-once* — l'exactly-once est impossible, on ne le promet pas) |
| Siège humain | La tâche humaine met le job en **`waiting_input`** et **libère le lease** ; la soumission (API) **remet le job en file** ; plus de lease de plusieurs heures |
| Commandes | Pause/reprise/arrêt/pas/surprise/bascule : lignes `command`, lues **entre deux étapes** par le worker `sim` |
| Progression | `job_event` (progression d'ingestion/export/rapport) ; les simulations exposent le **ledger** |
| **SSE** | L'endpoint lit la table par **curseur** : pour un exercice, `ledger_event.seq` (gap-free **par exercice**, jamais un id auto-incrémenté qui peut sauter des lignes committées tard) ; pour un job, `job_event.seq` ; polling ~1 s ; **`LISTEN/NOTIFY` (PG) comme simple signal de réveil**, jamais comme source de vérité. Reprise par `Last-Event-ID` |
| Ledger | `ledger_head` par exercice verrouillée `FOR UPDATE` / `BEGIN IMMEDIATE` ; hash calculé sur les **octets canoniques stockés** (doc 10) |
| Arrêt propre | SIGTERM → termine l'étape courante et libère le lease (Linux/macOS) ; **sous Windows les signaux ne sont pas fiables** : la reprise repose sur l'**expiration du lease**, pas sur un arrêt propre |
| Injection de pannes (tests) | `ALERTE_FAULT=after_llm_before_commit \| after_ledger_before_event \| mid_ingest_batch \| mid_pdf` + `Popen.kill()` (3 OS) ; zombie : `SIGSTOP`/`SIGCONT` après expiration (Linux/macOS) |

```mermaid
sequenceDiagram
  participant A as api
  participant DB as Base (job)
  participant W1 as worker 1
  participant W2 as worker 2
  A->>DB: INSERT job(queue=sim, idempotency_key)
  W1->>DB: claim (SKIP LOCKED), lease_token=T1, expire à t+60s
  loop chaque étape
    W1->>DB: écriture WHERE job_id AND lease_token=T1 (même transaction que le ledger)
    W1->>DB: heartbeat (prolonge le lease)
  end
  Note over W1: worker suspendu ou planté
  W2->>DB: lease expiré, re-claim, lease_token=T2, tentative+1
  W2->>DB: reprend à la dernière étape validée (step_key)
  W1->>DB: (zombie) écriture WHERE lease_token=T1
  DB-->>W1: 0 ligne, abandon, aucune écriture
```

## 5.7 Pile technique : choix et justification (révisés)

| Domaine | Choix | Justification / statut de vérification |
|---|---|---|
| API | FastAPI + Pydantic v2 (imposé) | OpenAPI → types TS |
| ORM / migrations | **SQLAlchemy 2.0 (sync)** ; **Alembic** (`render_as_batch` pour SQLite) ; migrations testées **de zéro sur les deux dialectes** | Les appels lents sont les LLM, déjà hors du chemin des requêtes ; l'async n'apporte rien de décisif |
| Base **cible** | **PostgreSQL 17/18** (épinglé) avec **pgvector 0.8.x** | Un seul magasin transactionnel : relationnel, jobs, ledger, vecteurs, lexical, permissions en SQL. Image `pgvector/pgvector:pg17` vérifiée : PostgreSQL 17.12, pgvector 0.8.7, configs FTS `french` et `arabic` présentes ([A16](appendix/A16-verification-log.md)) |
| Base **profil léger** | **SQLite** (WAL), mono-hôte | Zéro installation sur Windows/macOS/Linux ; profil de dev et de CI ; **repli possible** si la Sandbox n'offre pas PostgreSQL (inconnu) pour une démo mono-hôte à faible concurrence ; **non recommandé** pour un déploiement partagé (un seul écrivain) |
| Pilote PostgreSQL | **psycopg 3 (sync)** — licence **LGPL-3.0** (lien dynamique ; à documenter dans le SBOM) | Pas d'async sous Windows (boucle Proactor) |
| Vecteurs | `VectorIndex` : **pgvector** (`halfvec(1024)`, **recherche exacte pré-filtrée par la portée du siège, aucun index HNSW en P0** ; index partiels par KB si un HNSW devient nécessaire) ; **SQLite exact (NumPy)** ; **Qdrant** adaptateur optionnel | Exact + pré-filtre : **aucune perte de rappel due à un index approximatif** ; **zéro fuite garanti par le pré-filtrage SQL et vérifié par un test de propriété** (à écrire) ; mesuré **sur le poste de développement personnel, à titre indicatif seulement** (à re-mesurer sur E2/E3) : 20 000 × 1024 dims, scan complet 170 ms, 5 000 filtrés 45 ms (conteneur PostgreSQL 17.12 éphémère). **Non reproduit** : la perte de rappel du filtre post-HNSW de pgvector sur données aléatoires — risque documenté à tester sur corpus réel |
| Lexical | `LexicalIndex` : analyseur **applicatif** (NFKC, normalisation arabe, Snowball FR/AR) → colonne `search_text` → **FTS5 `bm25()`** (SQLite) / **`tsvector 'simple'` + GIN + `ts_rank_cd`** (PG) ; `pg_textsearch` (BM25 natif, jeune) optionnel plus tard | Libellé honnête : « BM25 (FTS5) / ts_rank_cd (PG) » ; la fusion RRF n'utilise que les **rangs** ; parité jugée sur recall@10, pas sur les scores. Une table de postings maison a été **écartée** (sur-conçue : ~30 M de lignes à 200 k chunks) |
| Fusion et rerank | RRF k=60 ; reranker `bge-reranker-v2-m3` après mesure | — |
| Embeddings | **BGE-M3** (MIT, 1024 d, dense) par défaut via `Embedder` OpenAI-compatible (TEI / vLLM / Ollama) ; **empreinte complète** (modèle, révision, runtime, quantification, normalisation) | Vecteurs de runtimes différents **non comparables** → refus de mélange |
| LLM | `LLMProvider` OpenAI-compatible ; modèles à licence permissive : **Qwen2.5-7B/14B/32B-Instruct (Apache-2.0)**, **Mistral Nemo 12B (Apache-2.0)** ; Llama/Gemma **non** par défaut (licences non OSI) ([19](19-licenses-and-sbom.md)) | Qualité des sorties structurées par modèle : **à mesurer sur E2/Sandbox** |
| Extraction PDF | **pypdfium2 (Apache-2.0/BSD) + pdfplumber (MIT)** ; OCR **Tesseract** (`ara+fra+eng`) ; **PyMuPDF exclu (AGPL-3.0)** ; docling (MIT) optionnel | Le prototype `alerte/` importe PyMuPDF (`knowledge/extract/pdf.py`) : **à remplacer au portage** |
| PDF des rapports | **WeasyPrint** (BSD-3 ; Pango requis) + **xhtml2pdf** repli pur-Python (Apache-2.0, RTL via `arabic-reshaper`+`python-bidi`) ; polices arabes libres embarquées | Les deux testés ; wkhtmltopdf exclu (archivé) |
| Identité | **Argon2id** (`argon2-cffi`), sessions serveur (cookie `HttpOnly`, `SameSite=Lax`, contrôle d'`Origin`), jetons hachés SHA-256 ; port IdP pour OIDC plus tard | [13](13-security-testing-deployment.md) |
| Intégrité | `hashlib` SHA-256 ; JSON canonique RFC 8785 ; Ed25519 (`cryptography`) en P1 | — |
| Frontend | React 19 · TS · **Vite 8 (Node ≥ 20.19 ou 22.12)** · React Router · TanStack Query · Tailwind · Radix/shadcn · react-i18next · openapi-typescript · Recharts | Versions lues par sous-agent : **à relire sur npm** à l'échafaudage |
| Gestion des dépendances | **`uv` + `uv.lock`** (`uv sync --locked`) ; `package-lock.json` + `npm ci` ; `.nvmrc` | [17](17-portability-environments-ci.md) |
| Conteneurs | Dockerfile/compose **standards OCI** : Docker Engine, **Podman** et `podman compose` ; Docker Desktop **non requis** | [17](17-portability-environments-ci.md) |
| NetworkX | En mémoire pour les règles de graphe | — |

## 5.8 Profils d'environnement

| Profil | Base | Vecteurs/lexique | Processus | Usage |
|---|---|---|---|---|
| `light` | SQLite | `sqlite_exact` + FTS5 | api + worker embarqué | Dev quotidien, CI 3 OS, tests unitaires/intégration |
| `shared` (**cible**) | PostgreSQL + pgvector | `pgvector` + `tsvector` | api + worker sim + worker doc/export | Déploiement d'équipe, recette, démo ; Sandbox si PostgreSQL disponible |
| `shared-gpu` | idem | idem | idem + serveurs vLLM/TEI | Validation des fonctions IA (E2/E4) |

Le **code est identique** ; seule la configuration (`ALERTE_PROFILE`, URLs de modèles, base) change. Détails et machines : [17](17-portability-environments-ci.md), [18](18-validation-strategy.md).

## 5.9 Registre de réutilisation du prototype `alerte/` (portage, pas réécriture)

Le dossier `alerte/` reste **intact** ; les éléments utiles sont **copiés puis adaptés** dans `alerte-platform/` derrière les ports, avec revue de licence et sans PyMuPDF.

| Élément de `alerte/` | Décision | Remarque |
|---|---|---|
| `knowledge/extract/*` (pipeline d'extraction + OCR + rapport de qualité) | **Porter** (≈ cœur de l'ingestion) | Remplacer PyMuPDF par pypdfium2/pdfplumber ; conserver la logique de qualité d'extraction et le cache |
| `knowledge/chunk.py` (découpage par article FR/EN/AR) | **Porter** | Ajouter page/section/`doc_title`, tests |
| Texte déjà extrait : `index/documents.json` + `chunks.jsonl` (45 docs, 4 235 chunks) | **Importer** (script `legacy_to_archive`) | Évite de refaire l'OCR ; marquer les fichiers douteux (AE-04, AE-06, CM-01, CM-07…) |
| `ocr/tessdata` (ara/fra/eng) | Réutiliser ou télécharger selon plateforme | Voir [17](17-portability-environments-ci.md) |
| `sim/ledger.py` (chaîne SHA-256) | **Concept repris**, réécrit (octets canoniques, `ledger_head`) | Le code existant calcule sur des colonnes |
| `sim/citations.py` | **À durcir** (le contrôle actuel est permissif) | Spécification en [08 §8.5](08-agents-and-simulation.md) |
| `analysis/gaps.py`, `data/mandates/*.csv`, `actions.yaml`, `precedents.yaml` | **Données et règles à re-lier** | Les `source_doc` historiques ne résolvent plus (diagnostic v1) ; import avec statut `proposed` |
| `data/scenarios/*.yaml`, `roles/*.yaml` | **Importer** comme scénarios/agents d'exemple | Générique : aucun pays codé en dur dans le moteur |
| `sim/engine.py`, `sim/brain.py` | **Ne pas porter** | Moteur à règles/templates ; remplacé par le runtime d'agents |
| `ui/` (Streamlit) | **Ne pas porter** | Remplacé par React |
| `data/framework/dimensions.json` | **Réutiliser** après contrôle | 13 libellés alignés avec le rapport ITU (A10) |

## 5.10 Index des décisions d'architecture (ADR)

Les ADR sont dans [`adr/`](adr/README.md). Les ADR **008, 010 à 019** (révision du 2026-11-21) **priment** sur toute formulation contraire des documents antérieurs.
