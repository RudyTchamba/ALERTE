# 06 — Modèle de données (v2, définitif avant implémentation)

> **Révision du 2026-11-21.** Principaux changements par rapport à la v1 : isolation inter-espaces **par clés étrangères composites** ; listes JSON **normalisées** en tables de jointure ; institutions nationales, **internationales et transfrontalières** (`scope` + `institution_jurisdiction`) ; **modèles/configurations réutilisables** (`is_template`, `cloned_from_id`) ; **identité réelle** (`app_user`, `workspace_member`, `auth_session`, `access_token`) ; **file de jobs durable** (`job`, `job_event`, jeton de lease) ; `ledger_head` par exercice et **octets canoniques stockés** ; table de portée relationnelle **`exercise_scope_item`** (sécurité) ; `llm_call` écrit avant l'appel ; empreinte d'embedder ; couverture documentaire ; deux axes de lacune renommés. SQLAlchemy 2.0, **PostgreSQL 17/18 (cible)** et **SQLite (profil léger)** avec les mêmes modèles (voir [05 §5.7](05-architecture-overview.md) et [17](17-portability-environments-ci.md)).

## 6.0 Conventions transverses

| Règle | Détail et vérification |
|---|---|
| Identifiants | `id` texte **ULID** (triable, non devinable) ; un `code` lisible par humain là où l'interface l'affiche. Aucun identifiant auto-incrémenté n'est utilisé comme curseur (voir `ledger_event.seq`) |
| **Isolation inter-espaces** | Toute table de premier niveau porte `workspace_id` et une contrainte `UNIQUE (workspace_id, id)`. **Toute clé étrangère vers une table à espace est composite** : `FOREIGN KEY (workspace_id, institution_id) REFERENCES institution (workspace_id, id)`. Une ligne d'un espace **ne peut pas** référencer une ligne d'un autre espace (garanti par la base, pas par le code). Les tables enfants sans `workspace_id` propre (ex. `inject_tag`) héritent par leur parent composite. **Test** : tentative d'insertion croisée → erreur d'intégrité sur les deux dialectes. Défense en profondeur sur PostgreSQL : **RLS** par `SET app.workspace_id` (P1) |
| SQLite | `PRAGMA foreign_keys=ON` **à chaque connexion** (sinon l'isolation est silencieusement inactive) ; vérifié par un test de démarrage qui échoue si la pragma est absente |
| Dialectes | Code spécifique à un dialecte **uniquement** dans `backend/app/db/dialect/` (verrous, claim de jobs, recherche, JSON, types vecteur). Une fonctionnalité est « faite » seulement si elle est **verte sur PostgreSQL** ; SQLite doit rester vert |
| Dates | UTC ; `timestamptz` (PG) / ISO 8601 texte (SQLite). **Aucun hash n'est recalculé depuis des colonnes** : le hash du ledger couvre les **octets canoniques stockés**, qui contiennent les dates sous forme de **texte figé** ; `replay_digest` exclut `real_time` (voir [10 §10.3](10-audit-and-evaluation.md)) |
| JSON | Réservé aux **documents** (payload d'événement, snapshot figé, résultats de recherche, contenu de rapport, paramètres libres). Toute relation interrogée ou liée par permission est **normalisée** (§6.7) |
| Immutabilité | Voir §6.6 |
| Suppression | Archivage (`archived_at`) pour tout objet référencé par un exercice lancé ; suppression physique seulement pour les brouillons non référencés |
| Réutilisation | `is_template` + `cloned_from_id` sur `agent`, `scenario` (et paramétrage de pays par duplication) : une **bibliothèque** de configurations clonables ; **cloner dans un exercice = copier** dans le snapshot ; modifier un modèle ensuite ne modifie jamais un exercice passé |

### 6.1 Identité, espaces de travail, pays, institutions, mandats

```mermaid
erDiagram
  APP_USER ||--o{ WORKSPACE_MEMBER : "belongs to"
  WORKSPACE ||--o{ WORKSPACE_MEMBER : has
  APP_USER ||--o{ AUTH_SESSION : opens
  WORKSPACE ||--o{ ACCESS_TOKEN : issues
  WORKSPACE ||--o{ COUNTRY : has
  COUNTRY ||--o{ COUNTRY_LANGUAGE : speaks
  WORKSPACE ||--o{ INSTITUTION : has
  INSTITUTION ||--o{ INSTITUTION_JURISDICTION : "acts in"
  COUNTRY ||--o{ INSTITUTION_JURISDICTION : "hosts"
  INSTITUTION ||--o{ INSTITUTION_DOMAIN : "covers"
  WORKSPACE ||--o{ ACTION_ITEM : defines
  INSTITUTION ||--o{ MANDATE : holds
  ACTION_ITEM ||--o{ MANDATE : concerns
  MANDATE ||--o{ MANDATE_SOURCE : cites
  MANDATE }o--o| MANDATE : "depends_on / conflicts_with"
  INSTITUTION ||--o{ REGISTRY_REVIEW : "coverage reviews"
  WORKSPACE ||--o{ SECURITY_EVENT : logs
  INTERNATIONAL_REFERENCE ||--o{ ACTION_ITEM : justifies

  WORKSPACE {
    text id PK
    text name
    text slug UK
    text status
    datetime archived_at
  }
  APP_USER {
    text id PK
    text email UK
    text display_name
    text password_hash
    text status
    datetime created_at
  }
  WORKSPACE_MEMBER {
    text workspace_id PK, FK
    text user_id PK, FK
    text role
  }
  AUTH_SESSION {
    text id PK
    text user_id FK
    text token_sha256 UK
    datetime expires_at
    datetime revoked_at
  }
  ACCESS_TOKEN {
    text id PK
    text workspace_id FK
    text kind
    text token_sha256 UK
    text role
    text scope_exercise_id FK
    text scope_seat_id FK
    datetime expires_at
    datetime revoked_at
    text created_by
  }
  COUNTRY {
    text id PK
    text workspace_id FK
    text iso2
    text name
    text notes
    datetime archived_at
  }
  COUNTRY_LANGUAGE {
    text country_id PK, FK
    text language PK
  }
  INSTITUTION {
    text id PK
    text workspace_id FK
    text code
    text name
    text name_local
    text scope
    text kind
    text description
    datetime archived_at
  }
  INSTITUTION_JURISDICTION {
    text institution_id PK, FK
    text country_id PK, FK
    text role
  }
  INSTITUTION_DOMAIN {
    text institution_id PK, FK
    text domain PK
  }
  ACTION_ITEM {
    text id PK
    text workspace_id FK
    text code
    text label
    text domain
    text basis_kind
    text reference_id FK
    text justification
    text review_status
  }
  MANDATE {
    text id PK
    text workspace_id FK
    text institution_id FK
    text action_id FK
    text kind
    text description
    text procedure_status
    bool has_deadline
    text dependency_text
    text depends_on_id FK
    text conflicts_with_id FK
    text evidence_tag
    text validation
    text origin
    text created_by
  }
  MANDATE_SOURCE {
    text id PK
    text mandate_id FK
    text document_version_id FK
    text chunk_id FK
    text article
    int page
    text quote
    text quote_sha256
  }
  REGISTRY_REVIEW {
    text id PK
    text institution_id FK
    text status
    text reviewer
    text note
    datetime reviewed_at
  }
  SECURITY_EVENT {
    text id PK
    text workspace_id FK
    text type
    text actor_user_id FK
    json payload
    datetime created_at
  }
  INTERNATIONAL_REFERENCE {
    text id PK
    text workspace_id FK
    text jurisdiction
    text instrument
  }
```

| Table | Remarques |
|---|---|
| `app_user`, `workspace_member`, `auth_session`, `access_token` | **Comptes réels** : e-mail + mot de passe **Argon2id** ; une session = jeton aléatoire dont seul le **SHA-256** est stocké ; l'appartenance à un espace porte le rôle `owner \| facilitator \| participant \| observer \| auditor`. `access_token` : jetons de **siège**, d'**observation** ou d'**API** (portée `scope_exercise_id` / `scope_seat_id`, expiration, révocation, hash seul). Les **agents IA ne sont pas des utilisateurs** : ce sont des *principals* internes non connectables |
| `institution.scope` | `national \| international \| transnational \| subnational`. Une organisation internationale (OMS, UIT, IFRC) n'a **aucun pays** ; `institution_jurisdiction(institution_id, country_id, role)` relie une institution à 0..n pays avec un rôle (`seat`, `operates_in`, `member`) ; les actions transfrontalières sont modélisées par des mandats d'institutions dont les juridictions diffèrent |
| `institution.kind` | `ministry \| agency \| regulator \| operator \| local_authority \| ai_system \| advisory \| other` ; `ai_system` = système IA testé (comportement scénarisé) |
| `country_language`, `institution_domain` | Normalisent les anciens champs JSON `languages`, `domains` |
| `action_item` | Catalogue d'actions « que la situation exige ». **`basis_kind`** ∈ `referential \| scenario_author \| agent_proposed` ; **`reference_id`** → `international_reference` (référence citée et vérifiable) **obligatoire** pour `referential` ; `justification` texte obligatoire pour `scenario_author` ; `review_status` ∈ `proposed \| accepted \| rejected`. **Règle de présentation** : seule une action `referential` acceptée peut être décrite comme « attente documentée » ; `scenario_author` est toujours étiqueté « attente fixée par le concepteur du scénario » et **jamais** « obligation institutionnelle officielle » |
| `mandate.kind` | `power \| duty \| lead \| coordination \| information_sharing \| procedure \| human_oversight \| liability \| inclusion \| channel_protection \| international_agreement \| prohibition` |
| `mandate.validation` | `proposed \| validated \| rejected` ; seul `validated` compte comme preuve documentaire |
| `mandate_source` | Un mandat actif **doit** pointer vers un chunk réel (test CI). Un mandat est actif dans un exercice si la version de document de sa source est dans la portée de l'exercice (c'est ce qui permet l'ablation de corpus) |
| `registry_review` | Par institution : `unreviewed \| partial \| reviewed_complete` + relecteur. **Une institution dont le registre n'est pas `reviewed_complete` ne peut jamais être décrite comme « sans mandat »** |

### 6.2 Bases de connaissances, documents, chunks, index

```mermaid
erDiagram
  WORKSPACE ||--o{ KNOWLEDGE_BASE : owns
  COUNTRY ||--o{ KNOWLEDGE_BASE : concerns
  KNOWLEDGE_BASE ||--o{ KB_LANGUAGE : "contains"
  KNOWLEDGE_BASE ||--o{ DOCUMENT : contains
  KNOWLEDGE_BASE ||--o{ KB_EXPECTED_DOCUMENT : "expects (coverage)"
  DOCUMENT ||--o{ DOCUMENT_VERSION : "versions (append-only)"
  DOCUMENT_VERSION ||--o{ CHUNK : "split into"
  CHUNK ||--o{ CHUNK_EMBEDDING : "embedded as"
  EMBEDDER_PROFILE ||--o{ CHUNK_EMBEDDING : "produced by"
  KNOWLEDGE_BASE ||--o{ KB_VERSION : publishes
  KB_VERSION ||--o{ KB_VERSION_ITEM : lists
  DOCUMENT_VERSION ||--o{ KB_VERSION_ITEM : "included in"
  KNOWLEDGE_BASE ||--o{ KB_EXPORT : "exported as"
  KNOWLEDGE_BASE ||--o{ KB_SHARE_RECORD : "shared as"
  DOCUMENT_VERSION }o--|| BLOB : "original file"
  JOB ||--o{ KB_EXPORT : produces
  KNOWLEDGE_BASE ||--o{ IMPORT_MAP : "maps archive ids"

  KNOWLEDGE_BASE {
    text id PK
    text workspace_id FK
    text country_id FK
    text code
    text name
    text description
    text domain
    text kind
    text sharing_policy
    text embedder_profile_id FK
    json chunking_params
    text status
    datetime archived_at
  }
  KB_LANGUAGE {
    text kb_id PK, FK
    text language PK
  }
  KB_EXPECTED_DOCUMENT {
    text id PK
    text kb_id FK
    text title
    text jurisdiction
    text citation
    text status
    text matched_document_id FK
  }
  DOCUMENT {
    text id PK
    text workspace_id FK
    text kb_id FK
    text code
    text title
    text doc_type
    text doc_number
    date doc_date
    text jurisdiction
    text language
    text source_url
    text reliability
    text validity
    text replaced_by_id FK
    text license_spdx
    text redistribution
    text sharing_override
    text evidence_default
    date accessed_at
    text current_version_id FK
  }
  DOCUMENT_VERSION {
    text id PK
    text workspace_id FK
    text document_id FK
    int version_no
    text blob_sha256 FK
    text mime
    int bytes
    text extraction_method
    real extraction_quality
    text lifecycle
    text supersedes_id FK
    text note
  }
  CHUNK {
    text id PK
    text workspace_id FK
    text document_version_id FK
    text kb_id FK
    text doc_title
    int ordinal
    int page_start
    int page_end
    text article
    text section
    text language
    text text
    text search_text
    text text_sha256
    int char_start
    int char_end
    text evidence_tag
  }
  EMBEDDER_PROFILE {
    text id PK
    text workspace_id FK
    text model
    text revision
    text runtime
    text quantization
    int dim
    bool normalized
    text pooling
    text fingerprint_sha256 UK
  }
  CHUNK_EMBEDDING {
    text chunk_id PK, FK
    text embedder_profile_id PK, FK
    halfvec vec
  }
  KB_VERSION {
    text id PK
    text kb_id FK
    int version_no
    text note
    text manifest_sha256
  }
  KB_VERSION_ITEM {
    text kb_version_id PK, FK
    text document_version_id PK, FK
  }
  KB_EXPORT {
    text id PK
    text kb_id FK
    text kb_version_id FK
    text mode
    text purpose
    json options
    text job_id FK
    text blob_sha256
    text status
  }
  KB_SHARE_RECORD {
    text id PK
    text kb_id FK
    text kb_version_id FK
    text target
    text scope
    text authorized_by
    datetime authorized_at
    text manifest_sha256
  }
  BLOB {
    text sha256 PK
    int bytes
    text mime
    text storage_key
  }
  IMPORT_MAP {
    text id PK
    text kb_id FK
    text archive_id
    text local_id
    text kind
  }
```

| Table | Remarques |
|---|---|
| `knowledge_base.kind` | `national \| global_practices \| scenario \| prior_reports \| mixed` |
| `knowledge_base.sharing_policy` | `local_only \| share_records \| share_records_and_embeddings` (par défaut `local_only`). **`document.sharing_override`** permet de déclarer un document `local_only` dans une KB partageable (dérogation par document). Voir [16](16-itu-reference-code-and-compliance.md) §16.4 |
| `kb_share_record` | Provenance de chaque partage : **qui l'a autorisé, quand, vers quelle cible, avec quelle portée, quelle empreinte de manifeste** (jamais de partage implicite) |
| `kb_expected_document` | **Couverture documentaire** : liste *attendue* saisie par l'utilisateur (« lois X, Y, Z devraient exister ») avec statut `present \| missing \| replaced \| unreachable` et lien vers le document apparié ; alimente `negative_search.corpus_coverage` et `gap.corpus_coverage` |
| `document.reliability` | `official \| summary \| unofficial \| not_found` ; `validity` : `in_force \| replaced \| unknown` (+ `replaced_by_id`) |
| `document.redistribution` | `allowed \| restricted \| unknown` + `license_spdx` (ou `LicenseRef-…`). Défaut `unknown`. L'export « ouvert » exclut `restricted` et `unknown` |
| `document_version.lifecycle` | `processing \| ready \| needs_review \| retired \| failed` — **colonne de cycle de vie** mutable (journalisée) ; le **contenu** (fichier, texte, chunks) est immuable |
| `chunk.search_text` | Texte **normalisé par l'analyseur applicatif** (Unicode NFKC ; arabe : retrait des diacritiques et du tatwīl, normalisation des alef/ya/ta marbuta ; Snowball FR/AR) — indexé par le moteur lexical natif du dialecte (FTS5 / `tsvector 'simple'`). `doc_title` dénormalisé pour l'index |
| `embedder_profile` | **Empreinte complète** : modèle + révision + runtime (TEI/Ollama/vLLM/sentence-transformers) + quantification + normalisation + pooling + dimension → `fingerprint_sha256`. `knowledge_base.embedder_profile_id` est la référence ; **la requête refuse tout mélange** de vecteurs issus d'empreintes différentes |
| `chunk_embedding` | Type vecteur selon dialecte : **`halfvec(1024)`** (pgvector, ½ taille) ou BLOB float16 (SQLite). Un chunk peut avoir plusieurs embeddings (une ligne par profil) |
| `kb_version` / `kb_version_item` | Publier = figer l'ensemble des `document_version_id` ; `manifest_sha256` = identité de la version |
| `security_event` | (module `workspaces`) connexions, échecs, révocations, créations de jetons ; **jamais** le jeton ni le mot de passe |
| `blob` | Stockage adressé par contenu ; `storage_key` abstrait (disque local ou S3-compatible) — **jamais un chemin absolu** |
| `import_map` | Correspondance `{archive_id, local_id, kind}` à l'import (table technique du module `knowledge`) |

### 6.3 Agents, scénarios, exercices (configuration et portée)

```mermaid
erDiagram
  WORKSPACE ||--o{ MODEL_PROFILE : configures
  INSTITUTION ||--o{ AGENT : "represented by"
  MODEL_PROFILE ||--o{ AGENT : uses
  AGENT ||--o{ AGENT_TOOL : "may call"
  AGENT ||--o{ AGENT_KB_GRANT : "may read"
  KNOWLEDGE_BASE ||--o{ AGENT_KB_GRANT : "readable by"
  WORKSPACE ||--o{ SCENARIO : defines
  SCENARIO ||--o{ INJECT : sequences
  INJECT ||--o{ INJECT_TAG : "tagged"
  INJECT ||--o{ INJECT_DEMAND : requires
  ACTION_ITEM ||--o{ INJECT_DEMAND : "is demanded"
  INJECT ||--o{ INJECT_RECIPIENT : "delivered to"
  INSTITUTION ||--o{ INJECT_RECIPIENT : receives
  SCENARIO ||--o{ EXERCISE : "run as"
  EXERCISE ||--|| EXERCISE_SNAPSHOT : "frozen by"
  EXERCISE ||--o{ SEAT : has
  SEAT ||--o{ SEAT_ASSIGNMENT : history
  SEAT ||--o{ EXERCISE_SCOPE_ITEM : "may read (frozen)"
  DOCUMENT_VERSION ||--o{ EXERCISE_SCOPE_ITEM : "readable"

  MODEL_PROFILE {
    text id PK
    text workspace_id FK
    text name
    text provider
    text endpoint_ref
    text model
    real temperature
    int max_tokens
    int timeout_s
    json extra
  }
  AGENT {
    text id PK
    text workspace_id FK
    text institution_id FK
    text cloned_from_id FK
    bool is_template
    text code
    text name
    text role_kind
    text mission
    text instructions
    text model_profile_id FK
    int max_steps
    int max_search_calls
    int max_legal_calls
    datetime archived_at
  }
  AGENT_TOOL {
    text agent_id PK, FK
    text tool PK
  }
  AGENT_KB_GRANT {
    text agent_id PK, FK
    text kb_id PK, FK
    text mode
  }
  SCENARIO {
    text id PK
    text workspace_id FK
    text country_id FK
    text cloned_from_id FK
    bool is_template
    text code
    text title
    text description
    text language
    int version
    text status
  }
  INJECT {
    text id PK
    text workspace_id FK
    text scenario_id FK
    int seq
    text sim_time
    text title
    text body
    text from_actor
    text fault_mode
    text system_output
    text source_note
  }
  INJECT_TAG {
    text inject_id PK, FK
    text tag PK
  }
  INJECT_DEMAND {
    text id PK
    text inject_id FK
    text action_id FK
    text note
  }
  INJECT_RECIPIENT {
    text inject_id PK, FK
    text institution_id PK, FK
  }
  EXERCISE {
    text id PK
    text workspace_id FK
    text scenario_id FK
    text parent_exercise_id FK
    text code
    text title
    text state
    text pace
    text ai_mode
    json settings
    datetime started_at
    datetime ended_at
    text snapshot_sha256
    text commitment_sha256
  }
  EXERCISE_SNAPSHOT {
    text exercise_id PK, FK
    json payload
    text payload_sha256
  }
  SEAT {
    text id PK
    text workspace_id FK
    text exercise_id FK
    text code
    text institution_ref
    text agent_ref
    text controller
    text human_name
    text user_id FK
  }
  SEAT_ASSIGNMENT {
    text id PK
    text seat_id FK
    text controller
    text human_name
    text reason
    text by_actor
  }
  EXERCISE_SCOPE_ITEM {
    text seat_id PK, FK
    text document_version_id PK, FK
  }
```

| Table | Remarques |
|---|---|
| `agent` | `role_kind` ∈ `institution \| ai_system \| legal_adviser` (le coordinateur est du **code**, pas un agent). `max_steps` (défaut 4), `max_search_calls` (3), `max_legal_calls` (2). `agent_tool` ⊂ {`search_kb`, `ask_legal`, `post`, `decide`} |
| `model_profile.endpoint_ref` | **Nom d'une variable d'environnement** (jamais une URL saisie) → pas de SSRF ; l'endpoint effectivement appelé est enregistré dans `llm_call` (preuve de non-sortie de données) |
| `agent_kb_grant` | Source de vérité des droits **à la configuration**. Au lancement, elle est **matérialisée** dans `exercise_scope_item` |
| `exercise_scope_item(seat_id, document_version_id)` | **Table de sécurité** : les versions de documents que ce siège peut lire pendant cet exercice (calculée au lancement : grants ∩ version publiée de chaque KB). **Toute recherche d'un siège est une jointure sur cette table**, deny-by-default. Elle n'est pas modifiable après le lancement |
| `inject_tag` | `life_risk, rights_risk, harm_possible, ai_output_used_in_decision, public_communication, channel_abuse, foreign_actor, time_critical, …` |
| `inject.fault_mode` | catalogue de 15 modes : les 12 de la Spec (L279-290) + `degraded_inputs`, `silent_institution`, `llm_outage` ([08 §8.8](08-agents-and-simulation.md)) |
| `exercise.ai_mode` | `ai \| scripted \| cassette` — **étiquette obligatoire** affichée partout ; `scripted`/`cassette` ne sont jamais présentés comme preuve du fonctionnement des agents IA |
| `exercise.commitment_sha256` | **Pré-engagement** : empreinte des règles de détection, des demandes (`inject_demand`), de la version du registre de mandats et du catalogue d'actions **au lancement** ; inscrite dans le premier événement du ledger (aucun réglage a posteriori) |
| `exercise_snapshot.payload` | JSON canonique de la configuration figée (pays, institutions, agents copiés, profils de modèle sans secrets, grants, scénario, actions, mandats validés, paramètres) ; son SHA-256 est dans `SNAPSHOT` |
| `seat.controller` | `agent \| human \| scripted` ; historique dans `seat_assignment` |

### 6.4 Exécution : jobs, ledger, tableau, décisions, appels LLM

```mermaid
erDiagram
  JOB ||--o{ JOB_EVENT : emits
  EXERCISE ||--o{ JOB : "run by"
  EXERCISE ||--|| LEDGER_HEAD : "head of"
  EXERCISE ||--o{ LEDGER_EVENT : "append-only"
  EXERCISE ||--o{ LEDGER_ANCHOR : "checkpoints"
  EXERCISE ||--o{ STEP : "idempotent steps"
  EXERCISE ||--o{ COMMAND : "facilitator commands"
  EXERCISE ||--o{ LLM_CALL : "model calls"
  EXERCISE ||--o{ BOARD_MESSAGE : holds
  SEAT ||--o{ INBOX_ITEM : receives
  SEAT ||--o{ DECISION : records
  DECISION ||--o{ DECISION_CITATION : cites
  SEAT ||--o{ HUMAN_TASK : awaits
  SEAT ||--o{ RETRIEVAL : logs

  JOB {
    text id PK
    text workspace_id FK
    text queue
    text kind
    text status
    text idempotency_key UK
    json payload
    json result
    int attempts
    int max_attempts
    text lease_owner
    text lease_token
    datetime lease_expires_at
    datetime heartbeat_at
    int timeout_s
    datetime run_after
    text error
    text exercise_id FK
    text created_by
  }
  JOB_EVENT {
    text id PK
    text job_id FK
    int seq
    text type
    json payload
  }
  LEDGER_HEAD {
    text exercise_id PK, FK
    int last_seq
    text last_hash
  }
  LEDGER_EVENT {
    text id PK
    text exercise_id FK
    int seq
    text type
    text actor
    text seat_id FK
    text sim_time
    datetime real_time
    text visibility
    bytes canonical_bytes
    text prev_hash
    text hash
  }
  LEDGER_ANCHOR {
    text id PK
    text exercise_id FK
    int seq
    text hash
    text kind
    text signature
    datetime created_at
  }
  STEP {
    text id PK
    text exercise_id FK
    text step_key
    text kind
    text status
    datetime started_at
    datetime finished_at
  }
  COMMAND {
    text id PK
    text exercise_id FK
    text kind
    json args
    text status
    text issued_by
  }
  LLM_CALL {
    text id PK
    text exercise_id FK
    text step_key
    int attempt
    text provider
    text model
    text endpoint_ref
    json params
    text request_blob_sha256
    text response_blob_sha256
    bool valid
    bool retried
    text status
    int tokens_in
    int tokens_out
    int ms
  }
  BOARD_MESSAGE {
    text id PK
    text exercise_id FK
    text inject_ref
    int round
    text from_seat FK
    text to_seat FK
    text msg_type
    text body
    text in_reply_to FK
    text reply_status
    int ledger_seq
  }
  INBOX_ITEM {
    text id PK
    text exercise_id FK
    text seat_id FK
    text source
    text ref_id
    int delivered_seq
    bool read
  }
  DECISION {
    text id PK
    text exercise_id FK
    text seat_id FK
    text inject_ref
    int round
    text action
    text action_code
    text outcome
    text confidence
    json options_considered
    json gap_flags
    text rationale
    text evidence_tag
    text author
    text status
    int ledger_seq
  }
  DECISION_CITATION {
    text id PK
    text decision_id FK
    text chunk_id FK
    text document_version_id FK
    text article
    text quote
    text check_status
    text check_reason
  }
  HUMAN_TASK {
    text id PK
    text exercise_id FK
    text seat_id FK
    text inject_ref
    int round
    text status
    datetime deadline_at
    text fallback
  }
  RETRIEVAL {
    text id PK
    text exercise_id FK
    text seat_id FK
    text query
    text scope_hash
    text embedder_profile_id FK
    json results
    int ledger_seq
  }
```

| Table | Remarques |
|---|---|
| `job` | File durable (voir [05 §5.6](05-architecture-overview.md)). `queue` ∈ `sim \| doc \| export` ; `status` ∈ `queued \| running \| waiting_input \| succeeded \| failed \| cancelled \| interrupted` ; **`lease_token`** (jeton de *fencing* : toute écriture d'étape fait `UPDATE … WHERE job_id=? AND lease_token=?` dans la même transaction, sinon abandon) ; `lease_expires_at` + `heartbeat_at` ; `idempotency_key` unique ; `timeout_s` par étape. `waiting_input` (siège humain) **libère le lease** |
| `ledger_head` | **Une ligne par exercice** (pas globale) : `last_seq`, `last_hash` ; verrouillée `FOR UPDATE` (PG) / `BEGIN IMMEDIATE` (SQLite) pour attribuer `seq = last_seq + 1` **sans trou** |
| `ledger_event` | `UNIQUE(exercise_id, seq)` ; **`canonical_bytes`** = charge canonique (RFC 8785) **stockée telle quelle** ; `hash = SHA256(prev_hash ‖ 0x0A ‖ canonical_bytes)` (formule unique, identique en [10 §10.3](10-audit-and-evaluation.md)) est calculé **sur ces octets**, jamais recalculé depuis des colonnes (évite toute dérive entre PG et SQLite lors d'un export/import) ; les colonnes `type`, `seq`, etc. sont des **copies indexées** vérifiées contre les octets |
| `llm_call` | **Écrit avant l'appel** (clé d'idempotence `exercise/step_key/attempt`) ; `request_blob_sha256` et `response_blob_sha256` désignent les **blobs** du prompt et de la réponse brute (rejeu par `cassette`) ; `params` (JSON : température, schéma…), `valid` (réponse conforme au schéma), `retried` ; à la reprise : réponse existante réutilisée, sinon nouvel appel enregistré avec `retried=true` et un événement `LLM_CALL` marqué `retried` au ledger (*effectively-once* : l'exactly-once est impossible). **Aucune transaction n'est ouverte pendant l'appel** |
| `decision.status` | `recorded \| not_verified \| not_recorded` ; `author` ∈ `agent \| human \| fallback` ; `legal_basis` est reconstruit depuis `decision_citation` |
| `board_message.reply_status` | `accepted \| refused \| not_our_role \| null` |
| `inject_ref` (`board_message`, `decision`, `human_task`) | **Clé du snapshot**, pas une FK : une exécution ne doit pas dépendre de la ligne vivante `inject` (le scénario peut évoluer). Seules les références **intra-exercice** et vers du contenu **immuable** (`chunk`, `document_version`) sont des FK |
| `step` | `UNIQUE(exercise_id, step_key)` (l'idempotence est **par exercice**) |

### 6.5 Lacunes, références, rapports, évaluation

```mermaid
erDiagram
  EXERCISE ||--o{ GAP : yields
  GAP ||--o{ GAP_INSTITUTION : concerns
  GAP ||--o{ GAP_EVIDENCE : "supported by"
  GAP ||--o{ GAP_REVIEW : "reviewed (append-only)"
  GAP ||--o{ GAP_REFERENCE : "compared with"
  INTERNATIONAL_REFERENCE ||--o{ GAP_REFERENCE : "cited as"
  GAP ||--o{ IMPROVEMENT_ACTION : "leads to"
  GAP ||--o{ GAP_PRIOR_LINK : "relates to"
  IMPORTED_FINDING ||--o{ GAP_PRIOR_LINK : "relates to"
  EXERCISE ||--o{ NEGATIVE_SEARCH : records
  WORKSPACE ||--o{ REPORT : owns
  REPORT ||--o{ REPORT_VERSION : "versions (immutable)"
  REPORT_VERSION ||--o{ REPORT_ARTIFACT : "rendered as"
  REPORT ||--o{ IMPORTED_FINDING : "extracted (kind=imported)"
  EXERCISE ||--o{ ASSESSMENT : scores
  RUBRIC_DIMENSION ||--o{ RUBRIC_CRITERION : defines
  RUBRIC_CRITERION ||--o{ ASSESSMENT : "answered by"
  EXERCISE ||--o{ EVAL_RUN : measures
  KNOWLEDGE_BASE ||--o{ EVAL_QUESTION : "tested by"
  BENCHMARK_SET ||--o{ BENCHMARK_ITEM : lists
  SCENARIO ||--o{ EVAL_FIXTURE : "sealed ground truth"

  GAP {
    text id PK
    text workspace_id FK
    text exercise_id FK
    text fingerprint
    text code
    text category
    text title
    text description
    text domain
    text action_id FK
    text evidence_origin
    text cause
    text confidence
    int severity
    text consequence
    text review_status
    text origin_kind
    text registry_state
    real corpus_coverage
    text recommendation_draft
  }
  GAP_INSTITUTION {
    text gap_id PK, FK
    text institution_id PK, FK
  }
  GAP_EVIDENCE {
    text id PK
    text gap_id FK
    text kind
    json ref
    text excerpt
    text role
  }
  NEGATIVE_SEARCH {
    text id PK
    text exercise_id FK
    text gap_id FK
    json queries
    json languages
    int corpus_documents
    real corpus_coverage
    json top_hits
    text verdict
    datetime run_at
  }
  GAP_REVIEW {
    text id PK
    text gap_id FK
    text reviewer_user_id FK
    text action
    text from_status
    text to_status
    text reality_label
    boolean blind
    text comment
  }
  INTERNATIONAL_REFERENCE {
    text id PK
    text workspace_id FK
    text jurisdiction
    text instrument
    text article
    text summary
    bool binding
    text domain
    text gap_code
    text document_version_id FK
    text chunk_id FK
    text url
    text evidence_tag
  }
  GAP_REFERENCE {
    text id PK
    text gap_id FK
    text reference_id FK
    text fit_note
    real fit_score
    text status
  }
  IMPROVEMENT_ACTION {
    text id PK
    text gap_id FK
    text owner_institution_id FK
    text description
    date due_date
    text status
    text kpi
  }
  IMPORTED_FINDING {
    text id PK
    text report_id FK
    text title
    text body
    text code_hint
    int severity_hint
    int source_page
    text status
  }
  GAP_PRIOR_LINK {
    text gap_id PK, FK
    text imported_finding_id PK, FK
    text relation
  }
  REPORT {
    text id PK
    text workspace_id FK
    text exercise_id FK
    text kind
    text title
    text confidentiality
    text document_version_id FK
  }
  REPORT_VERSION {
    text id PK
    text report_id FK
    int version_no
    text status
    json content
    text content_sha256
    int ledger_head_seq
    text ledger_head_hash
    text generator_version
    text parent_version_id FK
  }
  REPORT_ARTIFACT {
    text id PK
    text report_version_id FK
    text format
    text blob_sha256
    int bytes
  }
  RUBRIC_DIMENSION {
    text id PK
    int number
    text name
    text factor
    text question
  }
  RUBRIC_CRITERION {
    text id PK
    text dimension_id FK
    text text
    real weight
  }
  ASSESSMENT {
    text id PK
    text exercise_id FK
    text criterion_id FK
    text answer
    json evidence
    text assessor
    text reviewed_by
    text note
  }
  EVAL_QUESTION {
    text id PK
    text kb_id FK
    text question
    text expected_doc_code
    text expected_article
    text lang
  }
  EVAL_RUN {
    text id PK
    text exercise_id FK
    text kb_id FK
    text metric
    json result
    text status
    datetime run_at
  }
  BENCHMARK_SET {
    text id PK
    text workspace_id FK
    text name
    text source_url
    text description
  }
  BENCHMARK_ITEM {
    text id PK
    text set_id FK
    text label
    text domain
    text expected_gap_code
  }
  EVAL_FIXTURE {
    text id PK
    text scenario_id FK
    text expected_gap_key
    text rationale
    text sealed_sha256
    datetime sealed_at
  }
```

| Table | Remarques |
|---|---|
| `gap.evidence_origin` (axe 1 — **« Origine de la preuve »**) | `hypothesis` (agent seul) · `observed` (signal de simulation) · `rule_deduced` (règle sur le registre) · `document_supported` (règle **et** registre `reviewed_complete` **et** couverture ≥ seuil **et** recherche négative sans contre-preuve) |
| `gap.review_status` (axe 2 — **« Statut de revue »**) | `proposed \| confirmed \| disputed \| rejected` ; ne change que par `gap_review` humaine |
| `gap.cause` | `institutional \| documentary \| artifact \| undetermined` : si le document pertinent était dans la portée mais **n'a pas été récupéré**, la cause est `artifact` (échec de recherche), pas une lacune institutionnelle |
| `gap.origin_kind` | `rule \| coordinator_signal \| agent_hypothesis \| imported` |
| `gap.corpus_coverage` | Rapport documents attendus présents / attendus (de `kb_expected_document`) ; toute absence est affichée avec ce ratio |
| `gap_institution` | Normalise l'ancien JSON `institution_ids` |
| `gap_review` | **Append-only** ; `reality_label` ∈ `real \| partially_real \| not_real` ; **`blind`** = revue faite sans voir l'étiquette du détecteur (T4) ; deux relecteurs → κ calculé |
| `international_reference` | Chaque entrée référence un **chunk** d'une KB `global_practices` *ou* une URL avec `evidence_tag=summary` explicite ; pas d'entrée sans source |
| `benchmark_set/item` | Listes de lacunes d'une **source externe** (IFRC, EW4All, catégories du rapport AI Readiness) pour mesurer la couverture indépendamment de nos propres fixtures |
| `eval_fixture` | **Table privée** du module `evaluation` ; fixtures scellées (`sealed_sha256`, `sealed_at`) avant les runs ; jamais lues par `gaps`, `agents`, `simulation` |
| `report.confidentiality` | `public \| participants \| restricted` : définit ce qu'un lecteur peut voir (les prompts bruts et boîtes privées ne sortent jamais d'un rapport `public/participants`) |
| `report_version` | Immuable une fois publiée ; `content` JSON structuré = source unique ; `ledger_head_*` lie la version à l'état du ledger |

## 6.6 Immutabilité et intégrité

* **Ajout seul** : `ledger_event`, `gap_review`, `seat_assignment`, `report_version` (publiée), contenu de `document_version`/`chunk`, `kb_share_record`. Pas d'`UPDATE`/`DELETE` applicatif (test qui parcourt les services) **et** triggers `BEFORE UPDATE/DELETE … RAISE` sur `ledger_event` et `gap_review` (PostgreSQL et SQLite). Les triggers protègent contre les erreurs applicatives, **pas** contre un administrateur de la base.
* **Colonnes de cycle de vie mutables, journalisées** : `document_version.lifecycle`, `archived_at`, `job.status`, `exercise.state`.
* **Aucun chemin absolu en base** ; fichiers désignés par `blob.sha256`.
* Index : `(exercise_id, seq)`, `(workspace_id, …)`, `chunk(kb_id)`, `chunk(document_version_id)`, `exercise_scope_item(seat_id)`, `gap(fingerprint)`, GIN/FTS sur `chunk.search_text`.
* **Pas d'index HNSW en P0** : recherche vectorielle exacte pré-filtrée par la portée du siège (voir [07 §7.3](07-knowledge-and-rag.md)).

## 6.7 Listes JSON : ce qui est normalisé et ce qui reste du JSON

| Ancien champ JSON (v1) | v2 |
|---|---|
| `country.languages`, `knowledge_base.languages` | `country_language`, `kb_language` |
| `institution.domains` | `institution_domain` |
| `agent.tools`, `agent.limits` | `agent_tool` ; colonnes `max_*` |
| `inject.tags`, destinataires | `inject_tag`, `inject_recipient` |
| `gap.institution_ids` | `gap_institution` |
| `international_reference.domains`, `gap_codes` | colonnes `domain`, `gap_code` (une ligne par couple si plusieurs) |
| `agent_kb_grant` (jamais JSON) | table + `exercise_scope_item` |
| **Restent en JSON (documents)** | `ledger_event.payload` (via `canonical_bytes`), `exercise_snapshot.payload`, `llm_call` (pas de JSON), `retrieval.results`, `negative_search.queries/top_hits`, `report_version.content`, `gap_evidence.ref`, `job.payload/result`, `model_profile.extra`, `knowledge_base.chunking_params`, `exercise.settings` |

## 6.8 Parité PostgreSQL / SQLite — points de dérive suivis

`PRAGMA foreign_keys` par connexion · fuseaux/précision des dates (aucun hash dessus) · collations et `LIKE` · opérateurs JSON · contraintes différées · concurrence (`SKIP LOCKED` / `FOR UPDATE` contre `BEGIN IMMEDIATE`) · RLS absente sous SQLite · types vecteur (`halfvec` / BLOB) · recherche plein texte. Chaque point **devra avoir** un test de **contrat commun** exécuté sur les deux dialectes ([18](18-validation-strategy.md)).
