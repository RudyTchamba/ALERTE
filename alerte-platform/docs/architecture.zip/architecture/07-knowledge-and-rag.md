# 07 — Bases de connaissances, pipeline documentaire, RAG hybride et export

> **Révision du 2026-11-21.** La recherche **vectorielle et hybride fait partie du chemin principal (P0)** : embeddings réels (BGE-M3 par défaut) derrière un port, recherche **exacte pré-filtrée** dans pgvector (ou SQLite/NumPy en profil léger), lexique natif du dialecte, fusion RRF. BM25/lexical seul n'est qu'un **mode dégradé** (moteur d'embeddings indisponible), signalé comme tel dans l'interface et les rapports. Pratiques : BP-20…27 ([04](04-best-practices-registry.md)). Comparatif de moteurs : [A11](appendix/A11-vector-db-comparison.md). Aucune décision n'est dimensionnée sur la machine de développement personnelle ([17](17-portability-environments-ci.md), [18](18-validation-strategy.md)).

## 7.1 Pipeline documentaire

```mermaid
flowchart LR
  U["Upload<br/>PDF · DOCX · MD · TXT · CSV"] --> V{"Contrôles<br/>type · taille · hash<br/>lisible ?"}
  V -- refus --> X["Rejet + raison"]
  V --> B[("Blob adressé<br/>par SHA-256")]
  B --> J[["Job ingest (file doc)"]]
  J --> E["Extraction par page<br/>pypdfium2 + pdfplumber<br/>+ OCR Tesseract si besoin"]
  E --> N["Normalisation<br/>NFC · caractères invisibles<br/>en-têtes/pieds répétés"]
  N --> S["Détection de structure<br/>articles · sections"]
  S --> C["Chunking<br/>conscient des articles"]
  C --> A["Analyseur lexical<br/>search_text FR/AR"]
  A --> Q["Contrôle qualité<br/>couverture · OCR · pages à relire"]
  Q --> M[["Job embed (par lots, reprenable par chunk)"]]
  M --> I["Index : lexical natif + vecteurs"]
  I --> R["document_version = ready<br/>ou needs_review"]
  R --> H["Revue humaine<br/>métadonnées · licence · validité"]
  H --> P["Publication :<br/>nouvelle kb_version"]
```

| Étape | Choix | Détail |
|---|---|---|
| Contrôles d'entrée (BP-27) | Liste blanche d'extensions + type réel ; taille max (défaut 100 Mo) ; nom de fichier **jamais** utilisé comme chemin (stockage par SHA-256 : évite aussi collisions de casse Windows/macOS et NFD/NFC) ; doublon par SHA-256 | Refus explicite ; PDF chiffré refusé |
| Extraction PDF | **pypdfium2** (rendu + texte) et **pdfplumber** (mise en page/tableaux) ; page sans texte ou très pauvre (< 80 caractères) → rendu image + **Tesseract** (`ara+fra+eng`) ; **PyMuPDF exclu** (AGPL-3.0) | `extraction_quality` = ratio caractères reconnus/page et confiance OCR. Alternative OCR sans installation système : RapidOCR (Apache-2.0), arabe à valider. docling (MIT) optionnel, lourd |
| DOCX / MD / TXT / CSV | `python-docx` ; lecture directe ; CSV : une ligne = un chunk avec en-têtes (registres de mandats) | — |
| Normalisation | Unicode NFC ; suppression des caractères de contrôle et **invisibles** (zero-width, balises Unicode « tag ») ; direction RTL préservée ; en-têtes/pieds répétés supprimés | Défense BP-29 ; chaque modification est comptée |
| Structure | Expressions multilingues : `Article N`, `Art. N`, `المادة N`, `Section`, `Chapitre/Chapter/الفصل` | Logique de l'ancien `chunk.py` (à porter, doc 05 §5.9) |
| Chunking | Un chunk = un article ; au-delà de `max_chars` (2 000) coupé par paragraphes avec 200 caractères de recouvrement, `article` conservé ; sans structure : ~512 tokens, 25 % de recouvrement | Paramètres dans `knowledge_base.chunking_params` et l'archive |
| **Analyseur lexical** | NFKC ; arabe : retrait des diacritiques (tachkīl) et du tatwīl, normalisation alef/ya/ta marbuta ; stemming **Snowball FR/AR** (`snowballstemmer`, MIT) → `chunk.search_text` | Indexé ensuite par le moteur natif ; PostgreSQL a aussi des configs `french`/`arabic` (vérifié) mais on indexe `search_text` en `'simple'` pour que le **même analyseur** serve SQLite et PostgreSQL |
| Embeddings | Job `embed` par lots via `Embedder` ; reprise **par chunk** (les chunks déjà embarqués sont sautés) ; `embedder_profile` enregistré | Voir §7.3 pour l'empreinte |
| Contrôle qualité | Par document : pages, caractères/page, % de pages OCR, nb d'articles, langue, pages à relire ; **alerte** si un document attendu a < 500 caractères utiles ; **couverture documentaire** (voir §7.9) | Alimente le rapport de qualité (critère C1) |
| Revue | Aperçu page par page, métadonnées modifiables (titre, n°, date, juridiction, fiabilité, **validité**, licence, redistribuable, **dérogation de partage**), chunks, avertissements | Rien n'est publié sans « Publier la version » |

Métadonnées proposées automatiquement : titre, langue, n° et date de texte, type. **Aucune licence n'est devinée** (`redistribution = unknown`). Extraction de métadonnées par LLM : P2.

## 7.2 Chunk et provenance

Chaque chunk : `id`, `document_version_id`, `kb_id`, `doc_title`, `page_start/end`, `article`, `section`, `language`, `text`, `search_text`, `text_sha256`, `char_start/end`, `evidence_tag`. Les citations (`decision_citation`, `mandate_source`) référencent le `chunk.id` **et** l'`article`/`page` ; le contrôle de citation vérifie leur cohérence ([08 §8.5](08-agents-and-simulation.md)).

## 7.3 Recherche hybride : `SearchScope` et classement

```python
@dataclass(frozen=True)
class SearchScope:
    workspace_id: str
    seat_id: str | None          # None = rôle UI/analyste (portée dérivée du rôle)
    purpose: Literal["agent", "human_seat", "analyst", "ui_preview", "eval"]
    # PAS de liste d'ids fournie par l'appelant : la portée est lue en base, jointure sur
    #   exercise_scope_item(seat_id → document_version_id)       [agents/sièges]
    #   kb_version publiée de la KB                                [UI selon rôle]

def search(scope: SearchScope, query: str, k: int = 5, *, filters: SearchFilters | None = None) -> list[Hit]: ...
```

Règles de sécurité :

1. **Le `SearchScope` n'est construit que par le backend**, jamais depuis un paramètre d'outil ni d'API. Pour un siège : **jointure sur `exercise_scope_item`**, calculée au lancement (grants ∩ version publiée) et **non modifiable** ensuite. `filters` ne peuvent que restreindre.
2. **Deny-by-default** : portée vide → aucun résultat.
3. **Pré-filtrage dans le SQL**, avant tout classement, sur **les deux** branches (lexicale et vectorielle). Pas de post-filtrage.
4. `RETRIEVAL` journalise : requête, `scope_hash`, `embedder_profile_id`, ids et scores renvoyés.
5. Défense en profondeur : le contrôle de citation revérifie le `chunk_id` contre le retrieval de l'activation **et** la portée du siège.
6. **Test de propriété** exécuté sur **chaque adaptateur** (`pgvector`, `sqlite_exact`, lexical PG/SQLite, `qdrant` si présent) : *aucun chunk hors portée n'est jamais renvoyé*, quelle que soit la requête (canari `CANARY-<uuid>`), et idem entre espaces de travail. Bloquant en CI.

### Algorithme

```
dense   = exact : ORDER BY chunk_embedding.vec <=> :q  parmi les chunks de la portée     (pgvector, halfvec)
          ou NumPy exact sur la matrice des chunks de la portée                          (SQLite)  -> top 50
lexical = bm25()/ts_rank_cd sur chunk.search_text, MÊME portée                            -> top 50
fusion  = RRF(k=60) sur les RANGS des deux listes
hit     = top k  (chunk_id, doc_code, titre, article, page, snippet, score, signaux{dense,lexical})
```

| Point | Décision |
|---|---|
| **Pas de HNSW en P0** | Le planificateur ne peut alors pas choisir « HNSW puis filtre » (risque documenté de pgvector : filtre appliqué après le parcours d'index ; `hnsw.iterative_scan` en contournement). Mesures **sur le poste de développement personnel, à titre indicatif seulement** (à re-mesurer sur E2/E3) : 20 000 × 1024 dims, scan exact complet 170 ms ; scan filtré à 5 000 chunks 45 ms (conteneur éphémère PostgreSQL 17.12 + pgvector 0.8.7 ; [A16](appendix/A16-verification-log.md)). Si un HNSW devient nécessaire (> ~200 k chunks sur une portée) : **index partiels par KB** + `iterative_scan` + test de rappel |
| Stockage | `halfvec(1024)` (410 Mo pour 200 k chunks au lieu de 820 Mo en float32) ; BLOB float16 sous SQLite |
| **Empreinte d'embedder** | Une requête n'est exécutée que si `embedder_profile` de la requête = celui des vecteurs de la KB ; sinon **refus explicite** (ou re-embedding de la KB). Les vecteurs d'un même modèle servi par TEI, Ollama et sentence-transformers ne sont **pas** comparables (quantification, pooling, normalisation) |
| Mode dégradé | Moteur d'embeddings injoignable → **lexical seul**, bandeau « recherche dégradée » dans l'UI, `RETRIEVAL.signals.degraded=true`, rapport signalé. Jamais présenté comme la recherche hybride |
| Articles | Un numéro d'article détecté dans la requête (« Article 33 ») ajoute un **filtre exact** (OU) : les modèles le citent souvent |
| Reranker | `bge-reranker-v2-m3` (Apache-2.0) **après mesure** : activé seulement si recall@5 < seuil ou gain mesuré |
| Contextual Retrieval | Optionnel (BP-25) ; hors chemin critique |
| Qdrant / Milvus | (Le sous-agent de [A11](appendix/A11-vector-db-comparison.md) recommandait Qdrant en premier choix et Milvus Lite en dev ; **l'architecte retient pgvector** après revue d'Opus : un seul magasin transactionnel évite la double écriture, la copie des permissions et la double sauvegarde.) **Adaptateur optionnel** `qdrant` (Apache-2.0, sparse + RRF natifs) pour grande échelle ou hébergement séparé, derrière les mêmes tests de contrat. Rejeté comme base principale : second stockage → double écriture/outbox, permissions recopiées dans le payload, deux sauvegardes/exports. Milvus Lite : un processus, non retenu |
| Lexical | Libellé honnête dans l'UI et les rapports : « BM25 (FTS5) » sous SQLite, « ts_rank_cd » sous PostgreSQL ; parité jugée sur **recall@10** d'un jeu de requêtes FR/AR de référence, pas sur les scores |
| Ordre d'implémentation (livraison) | (1) port `Embedder` client OpenAI-compatible → (2) job `embed` par lots → (3) dense exact sur les deux dialectes → (4) lexical natif → (5) RRF → (6) test de propriété de portée → (7) 30 requêtes FR/AR mesurées sur E2, consignées ([18](18-validation-strategy.md)) |

### Recherche négative (pour les lacunes)

`search_absence(scope=analyste, topic_queries[], languages[])` lance des requêtes standardisées (libellé de l'action dans chaque langue de la KB + synonymes) et enregistre `negative_search` (requêtes, langues, nombre de documents, **`corpus_coverage`**, meilleurs scores, `verdict`). Une absence n'est affirmée que comme « *non trouvée dans le corpus K (N documents ; couverture c % des textes attendus ; langues L)* », jamais comme « n'existe pas » (I3). La **cause** d'une absence apparente est évaluée avec la trace de retrieval : si le document pertinent était dans la portée mais n'a pas été récupéré → `cause = artifact`.

## 7.4 Défense contre les instructions malveillantes des documents

| Couche | Mesure |
|---|---|
| Ingestion | Caractères invisibles retirés ; motifs suspects (« ignore previous instructions », « call decide ») **signalés** dans le rapport de qualité sans altérer le texte légal ; limites de taille/objets ; extraction/OCR dans un **sous-processus borné** (délai, mémoire) |
| Prompt | Extraits dans un bloc `<retrieved_document untrusted="true" id="…">` ; le prompt système dit que c'est une **donnée** ; aucune instruction d'un document n'a d'autorité |
| Outils | Autorisations **dans le code** : un chunk ne peut ni ajouter d'outil, ni changer un destinataire, ni forcer une décision ; `decide` passe par validation + contrôle de citation |
| « Rule of Two » | Un agent traitant du contenu non fiable n'a pas d'action externe : ses sorties sont des enregistrements internes |
| Sortie | Texte/Markdown échappé ; aucune URL chargée automatiquement ; caractères de contrôle retirés avant le ledger |
| Tests | T-SEC-01, 02, 08, 09 ([13](13-security-testing-deployment.md)) |

## 7.5 Versions de KB et reproductibilité

* `document_version` immuable ; `kb_version` = ensemble figé ; `exercise_scope_item` = ce que chaque siège a pu lire.
* Mise à jour d'un document : nouvelle version → nouvelle `kb_version` à publier ; les exercices passés ne changent pas.
* Document « remplacé » : `validity = replaced` + `replaced_by_id` ; filtre `validity != replaced` par défaut dans la portée des agents (désactivable pour exercices historiques).
* Reconstruction d'index : job `reindex(kb_id)` régénère lexique et vecteurs depuis `chunk.text` sans toucher aux chunks.

## 7.6 Export et réimport

### Modes d'export

| Mode | Contenu | Usage |
|---|---|---|
| **Complet réimportable** (défaut) | Manifest, documents, chunks, originaux (si droits), config, **embeddings + empreinte**, mandats et références liés (option) | Migration, sauvegarde, publication privée |
| **Traité seulement** | Sans originaux : texte, chunks, métadonnées | Redistribution des originaux restreinte |
| **Documents seulement** | Originaux sélectionnés + métadonnées | Remise à un tiers |
| **Sélection** | Tout mode restreint à des documents cochés | — |
| **Ouvert (publication)** | Complet, mais **exclut** `restricted` et `unknown` et tout document `sharing_override=local_only` ; échoue avec la liste sinon | Livrable « base de connaissances publiée » |
| **Profil de records ITU** | JSONL de records au format de l'adaptateur du dépôt d'exemple ITU (voir [16](16-itu-reference-code-and-compliance.md)) ; **jamais sans autorisation de partage consignée** (`kb_share_record`) | Intégration au Lab |

### Format d'archive (inspiré de BagIt, RFC 8493)

```
alerte-kb-<code>-v<version>-<date>.zip
├── manifest.json            # métadonnées, hashes, config, droits, empreinte d'embedder, partage (JSON canonique RFC 8785)
├── manifest.sha256          # empreinte du manifest canonique
├── bag-info.txt             # résumé lisible
├── data/
│   ├── kb.json              # nom, description, pays, domaine, langues, kind, version, sharing_policy
│   ├── documents.jsonl      # documents + versions (métadonnées, licence, validité, dérogations)
│   ├── chunks.jsonl         # chunks (id, doc, page, article, texte, search_text, sha256…)
│   ├── expected_documents.jsonl   # (option) liste attendue pour la couverture
│   ├── mandates.jsonl · references.jsonl      # (option)
│   ├── sources/<doc>-v<n>.<ext> # originaux (si autorisés)
│   └── embeddings/<profil>.f16.npy + index.jsonl   # (option) matrice + ordre des chunk_id + embedder_profile
└── signature.json           # (P1) Ed25519 sur manifest.sha256
```

Champs obligatoires du manifest : `format="alerte-kb-archive"`, `format_version` (SemVer), `kb`, `created_at`, `exporter`, `mode`, `purpose`, `files[]` (`path`, `sha256`, `bytes`, `records`), **`embedding` (modèle, révision, runtime, quantification, normalisation, dimension, `included`)**, `chunking`, `documents_summary` (comptes par `redistribution`), `sharing` (politique, **autorisé par / quand / cible**), `provenance`, `warnings[]`. **Aucun chemin absolu, aucun identifiant machine, aucun secret** (liste blanche stricte). Noms de fichiers : ASCII sûr généré (le titre est dans les métadonnées), jamais le nom d'origine.

Un **schéma JSON** versionné (`schemas/alerte-kb-archive-1.0.json`) décrit chaque fichier ; l'import valide contre ce schéma ; migration d'une version de format à l'autre documentée.

### Schéma du manifest (extrait normatif — `schemas/alerte-kb-archive-1.0.json`, JSON Schema 2020-12)

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "alerte-kb-archive-1.0",
  "type": "object",
  "required": ["format", "format_version", "kb", "created_at", "exporter", "mode", "purpose", "files", "embedding", "chunking", "documents_summary", "sharing", "provenance"],
  "properties": {
    "format": {"const": "alerte-kb-archive"},
    "format_version": {"type": "string", "pattern": "^1\\.\\d+\\.\\d+$"},
    "mode": {"enum": ["full_reimportable", "processed_only", "documents_only", "selection", "open_publication", "itu_records_profile"]},
    "purpose": {"enum": ["private", "open_publication", "itu_sharing"]},
    "kb": {"type": "object", "required": ["id", "code", "name", "version", "languages"]},
    "files": {"type": "array", "items": {"type": "object", "required": ["path", "sha256", "bytes", "records"],
              "properties": {"path": {"type": "string", "pattern": "^(manifest\\.json|bag-info\\.txt|signature\\.json|data/[A-Za-z0-9._/-]+)$"},
                             "sha256": {"type": "string", "pattern": "^[0-9a-f]{64}$"}}}},
    "embedding": {"type": "object", "required": ["included", "model", "revision", "runtime", "quantization", "normalized", "dimension"]},
    "sharing": {"type": "object", "required": ["policy"], "properties": {"policy": {"enum": ["local_only", "share_records", "share_records_and_embeddings"]}}},
    "documents_summary": {"type": "object", "required": ["count", "redistribution"]}
  },
  "additionalProperties": false
}
```

Règles : `additionalProperties: false` (un champ inconnu est refusé) ; chemins limités à la liste blanche (pas de `..`, pas de chemin absolu) ; **migration** d'une version de format à l'autre documentée et testée (import d'une archive `1.0` par une application `1.x`) ; le manifest est écrit en JSON canonique (RFC 8785) avant calcul de `manifest.sha256`.

### Séquences

```mermaid
sequenceDiagram
  actor U as Utilisateur
  participant UI as Knowledge Base Manager
  participant API as API /knowledge
  participant J as Worker doc/export
  participant FS as Base + blobs
  U->>UI: Exporter (mode, sélection, options)
  UI->>API: POST /knowledge-bases/{id}/exports
  API->>API: contrôle des droits et du partage
  API-->>UI: 202 {job_id, avertissements}
  API->>J: job export (queued)
  loop progression
    J->>FS: lecture par lots (documents, chunks, vecteurs)
    J->>J: écriture du ZIP en flux + SHA-256 de chaque fichier
    J-->>UI: SSE /jobs/{id}/stream (progress)
  end
  J->>J: manifest canonique + manifest.sha256 (+ signature P1)
  J->>FS: blob de l'archive + kb_export (+ kb_share_record si partage)
  J-->>UI: terminé (réussite ou échec notifié)
  U->>UI: Télécharger
  UI->>API: GET /exports/{id}/download
```

```mermaid
sequenceDiagram
  actor U as Utilisateur
  participant API as API /knowledge
  participant J as Worker doc/export
  participant DB as Base + blobs
  U->>API: POST /knowledge-bases/import (fichier .zip)
  API->>J: job import (dry_run par défaut)
  J->>J: 1. limites ZIP (taille, entrées, ratio), chemins, liens symboliques
  J->>J: 2. manifest : version du format, schéma, hash du manifest, hash de chaque fichier
  J->>J: 3. cohérence : chunk vers document, comptes, embeddings et empreinte
  J-->>U: rapport de validation (erreurs, avertissements, conflits, licences)
  U->>API: confirmer (nouvelle KB ou nouvelle version)
  J->>DB: création dans UNE transaction (rollback complet si échec)
  J->>J: réindexation lexicale, vecteurs importés si empreinte identique, sinon à recalculer
  J-->>U: KB importée + journal d'import
```

* **Identifiants** : préservés sans conflit, sinon `import_map` affichée ; citations internes réécrites.
* **Embeddings** : réutilisés **seulement si l'empreinte complète est identique** à la configuration cible ; sinon recalcul (job reprenable).
* **Idempotence** : même `manifest.sha256` dans le même espace → refus avec lien, ou nouvelle version sans doublon (par `text_sha256`).
* **Intégrité** : un hash invalide refuse l'import en entier. **Indépendance** : l'archive ne dépend d'aucun moteur d'index ; tout index se reconstruit depuis `chunks.jsonl`.
* **Sécurité de l'archive** : `../`, chemins absolus, liens symboliques, bombes (500 Mo décompressés, 10 000 entrées, ratio 100:1 — seuils de conception, configurables), types hors liste blanche.

### Droits documentaires et licences

* `license_spdx` + `redistribution` par document (défaut `unknown`). Avant l'export, l'interface affiche le tableau redistribuable/restreint/inconnu ; les modes *Ouvert* et *Traité* appliquent des règles distinctes.
* La licence du **logiciel** ne s'applique pas aux textes officiels. Un `LICENSES.md`/`DATA_LICENSES.md` généré liste les licences du contenu ([19](19-licenses-and-sbom.md)). Cas connus à qualifier : Banque mondiale (CM-17, GL-07), article éditeur (AE-06), publications OMS/ITU, presse (CM-14).
* **Politique de partage** (nouveau) : voir §7.10.

## 7.7 Page Knowledge Base Manager

| Zone | Contenu |
|---|---|
| Liste des KB | Nom, pays, domaine, langues, version publiée, documents, état d'indexation (lexical/vecteurs/**profil d'embedder**), qualité, **couverture documentaire**, politique de partage |
| Détail d'une KB | Onglets : **Documents** · **Chunks** (recherche hybride avec signaux) · **Qualité** · **Couverture** (documents attendus vs présents) · **Versions** · **Index** (reconstruire, changer de modèle) · **Export / Import / Partage** |
| Document | Aperçu, métadonnées, historique de versions, pages à relire, « remplacé par », dérogation de partage |
| Exporter | Assistant : mode → sélection → options → contrôle des droits et du partage → progression → téléchargement |
| Importer | Dépôt d'archive → rapport de validation (dry-run) → confirmation → progression |

## 7.8 Amorçage de la démonstration (réutilisation de l'existant)

Un script `legacy_to_archive` convertit `alerte/index/documents.json` + `chunks.jsonl` (4 235 chunks, 45 documents) en archives au format ci-dessus, importées **par l'interface** (ce qui teste l'import). Pas de ré-OCR. Les embeddings sont calculés par un vrai serveur d'embeddings sur **E2/Sandbox** puis inclus dans l'archive. Corrections connues (A3) : AE-04 = charte IA des EAU ; AE-06 article scientifique ; CM-14 presse ; CM-17 et GL-07 Banque mondiale ; CM-01 et CM-07 scans quasi vides ; 141 pages à relire ; **aucune colonne de licence** (donc export ouvert vide tant que les droits ne sont pas qualifiés). Documents absents (AE-03, AE-07, CM-06, GL-08, GL-10, ITU-03/04) : déclarés « manquants » dans `kb_expected_document`, jamais inventés.

## 7.9 Qualité de la KB et couverture documentaire (critère C1)

Rapport par KB : complétude (liste *attendue* saisie par l'utilisateur vs présente → **ratio de couverture**), exactitude (extraction : caractères/page, OCR, pages à relire), structure (% avec articles), doublons, langues, métadonnées manquantes, droits, alertes d'injection. T1 s'exécute sur un jeu de questions de la KB (`eval_question`, import CSV). Le ratio de couverture accompagne **toute** affirmation d'absence (lacunes, rapports).

## 7.10 Partage, localisation des données et intégration ITU

| Classe de données | Règle |
|---|---|
| Documents sources | Restent sous contrôle de l'espace (national) ; jamais transmis automatiquement |
| Records (chunks + métadonnées) | Partageables seulement si `sharing_policy ∈ {share_records, share_records_and_embeddings}` **et** autorisation consignée (`kb_share_record` : qui, quand, cible, portée, empreinte du manifest) |
| Embeddings | Considérés comme des records (un vecteur peut conserver de l'information de la source) ; partage séparé |
| Dérogation | `document.sharing_override = local_only` exclut un document d'un partage de KB |
| Preuve de non-sortie | `llm_call.endpoint_ref` : l'endpoint effectivement appelé est enregistré ; un appel vers une API externe contredirait la promesse « données dans le pays » |

Le rapport ITU contient des exigences contradictoires sur ce point (REQ-015/025/026/007, [A10](appendix/A10-itu-pdfs-findings.md)) : les interprétations, la politique retenue et les questions aux organisateurs sont en [16](16-itu-reference-code-and-compliance.md). **Aucune donnée nationale n'est déplacée vers un service externe sans décision explicite.**
