# 14 — Plan d'implémentation, chemin critique et organisation des agents

> **Révision du 2026-11-21 (samedi).** `alerte-platform/` ne contient **aucun code** : seuls les documents de conception existent. Échéances : **mercredi 25 nov.** (chaîne de bout en bout) ; **28 nov.** (fin d'accès Sandbox, stabilisation) ; finale à Dubaï 8 ou 9 déc. L'architecture cible **n'est pas réduite** pour tenir ces dates : le plan règle l'**ordre de livraison**, pas le périmètre de conception. Les capacités qui ne tiendront pas mercredi restent dans l'architecture sous forme de **ports et d'ADR**, avec leur échéance réelle.

## 14.1 Ce que le calendrier permet — dit franchement

Quatre jours (sam. 21 → mer. 25) pour livrer, avec une équipe réduite et un agent de code coordinateur, le noyau suivant : PostgreSQL + SQLite, processus séparés avec file de jobs, ingestion + embeddings + recherche hybride, runtime d'agents, simulation, lacunes, rapports **avec PDF**, comptes, CI sur 3 OS, **et une validation avec un vrai modèle**. C'est **très ambitieux**. Conclusions de la revue d'Opus (accord de l'architecte) :

* Ce qui est **impossible à rajouter après coup** doit être livré d'abord : clés étrangères composites, table de jobs avec fencing, ledger sur octets canoniques, séparation api/worker, CI 3 OS dès le premier commit, **premier appel à un vrai modèle dès dimanche soir** (pas mercredi).
* **Ne tiendront probablement pas mercredi** (restent dans l'architecture, livrés ensuite) : RLS PostgreSQL, adaptateur Qdrant, OIDC, `pg_textsearch`, PostgreSQL natif en CI Windows/macOS, règles **G4–G10**, **T3/T4 formels** (protocole complet), profil compose `gpu-vllm`, **XLSX**, **reranker**, extraction de mandats par LLM, graphe de mandats, import de rapports antérieurs assisté, comparaison de rapports.
* Le risque principal n'est plus la machine de développement (hors sujet) : c'est **l'intégration greenfield** et **la disponibilité d'un environnement E2** (machine puissante de l'équipe) avec un endpoint de modèles dès dimanche.

Décision demandée à l'équipe : confirmer E2 (machine, GPU, modèle servi) **aujourd'hui** ([15](15-decisions-to-validate.md) V5-bis/V22).

## 14.2 Périmètre par vague de livraison

| Vague | Contenu | Échéance |
|---|---|---|
| **Fondations** (irréversible d'abord) | Modèle de données avec FK composites (PostgreSQL **et** SQLite) ; Alembic dès le premier commit ; `job` + lease + fencing ; `ledger_head` + ledger sur octets canoniques ; séparation api/worker ; auth (Argon2id, sessions, `require_role`) ; ports (`LLMProvider`, `Embedder`, `VectorIndex`, `LexicalIndex`, `PdfRenderer`) ; CI 3 OS + job PostgreSQL ; `doctor`/`setup` | Sam. 21 → dim. 22 |
| **Connaissance** | Ingestion (portage de l'extraction, sans PyMuPDF, OCR), analyseur FR/AR, embeddings (job reprenable), recherche hybride + RRF + test de propriété de portée, export/import ZIP vérifié, couverture documentaire | Dim. 22 → lun. 23 |
| **Simulation et agents** | Runtime d'agents (enveloppe plate), 4 outils, citations, COORD, runner de job `sim`, siège humain (`waiting_input`), SSE, `llm_call` avant l'appel | Dim. 22 → lun. 23 |
| **Lacunes, rapports, évaluation** | Registre de mandats + règles **G1, G2, G3, G8** + signaux + couverture + cause + revue ; références curées ; rapports MD/JSON/CSV/**PDF** ; T2, T6 | Lun. 23 → mar. 24 |
| **Frontend** | Shell, Studio, KB Manager, Agent/Access, Scenario Builder, Readiness, Room, Player, Gaps, Reports, Audit | Dim. 22 → mar. 24 (sur fixtures OpenAPI) |
| **Validation** | Suite `model` sur E2 ; kill/reprise ; sécurité (17 tests) ; acceptation des 15 étapes ; **journal de validation** | Mar. 24 → mer. 25 |
| **Stabilisation / Sandbox** | Déploiement E4, vrais runs, embeddings KB, cassettes, T1–T6, G4–G10, XLSX, reranker, comparaison de rapports, import de rapports | Jeu. 26 → ven. 27 |
| **Exports finaux** | KB + embeddings, cassettes, rapports, base d'exemple | Sam. 28 |

## 14.3 Calendrier détaillé

| Jour | Objectif | Critère de sortie |
|---|---|---|
| **Sam. 21** (matin) | **Gel des contrats** (coordinateur seul, ≈ 4 h) : modèles + FK composites, catalogue d'événements (octets canoniques), OpenAPI stub, ports, scénario « doré », conventions ; création de la branche | Dossier `contracts/` ; types TS générés ; CI squelette |
| Sam. 21 (après-midi) | **Squelette de bout en bout** : 1 événement → ledger → SSE → 1 page ; api + worker séparés ; CI **ubuntu + windows + macos** verte ; migrations de zéro (SQLite + PG) | `python -m app.dev` et compose affichent un événement en direct |
| **Dim. 22** | Flux A/B/C/D en parallèle (§14.5) ; **E2 expose l'endpoint partagé** (LLM + embeddings) ; **premier appel à un vrai modèle dimanche soir** | Appel réel tracé au ledger (`LLM_CALL`) |
| **Lun. 23** | Runner, siège humain, recherche hybride mesurée sur E2 (30 requêtes FR/AR), lacunes G1/G2/G3/G8 sur les nouveaux axes | Exercice complet `scripted` étiqueté ; hybride mesurée |
| **Mar. 24** | Rapports + PDF ; tests kill/reprise ; sécurité ; **gel des fonctionnalités à midi** ; Alembic baseline déjà en place | Branche d'intégration verte (3 OS + PG) |
| **Mer. 25** | **Recette M1** sur E3 : 15 étapes ; **M1b** : suite `model` sur E2 (vrai modèle + vrais embeddings) ; journal de validation généré | Chaîne opérationnelle ; IA validée ou statut « non validé » honnêtement indiqué |
| Jeu. 26 | Déploiement Sandbox (E4) ; vrais runs ; P-vague stabilisation | Exercices réels Sandbox |
| Ven. 27 | Mesures T1–T6, G4–G10 si prêts, kit de démo, documentation | **M2** |
| Sam. 28 | Fin d'accès Sandbox : exports finaux seulement | — |
| 29 nov – 7 déc | Répétition (E5), rapport technique de 5 pages (**à réécrire**), vidéo (obligatoire si retenu) | Hors plateforme |

## 14.4 Chemin critique

```mermaid
gantt
  dateFormat  YYYY-MM-DD
  axisFormat  %d/%m
  section Fondations
  Gel des contrats                         :crit, c0, 2026-11-21, 1d
  Squelette bout en bout et CI 3 OS        :crit, w0, 2026-11-21, 1d
  FK composites, jobs et fencing, ledger   :crit, f1, 2026-11-21, 2d
  section Connaissance
  Ingestion et analyseur FR AR             :k1, 2026-11-22, 2d
  Embeddings et recherche hybride          :crit, k2, 2026-11-22, 2d
  Export et import vérifiés                :k3, 2026-11-23, 2d
  section Moteur
  Runtime d'agents et outils               :crit, m1, 2026-11-22, 2d
  Premier appel à un vrai modèle           :milestone, crit, m1a, 2026-11-22, 0d
  Runner COORD siège humain SSE            :crit, m2, 2026-11-23, 2d
  section Analyse
  Registre et règles G1 G2 G3 G8           :crit, a1, 2026-11-22, 2d
  Rapports et PDF                          :crit, a2, 2026-11-24, 1d
  section Frontend
  Shell et Studio                          :d1, 2026-11-22, 2d
  Room Gaps Reports Audit                  :crit, d2, 2026-11-24, 1d
  section Validation
  Suite model sur E2                       :crit, v1, 2026-11-24, 2d
  Recette M1 et M1b                        :milestone, crit, v2, 2026-11-25, 0d
  Sandbox et vrais runs                    :s1, 2026-11-26, 1d
  Stabilisation M2                         :milestone, v3, 2026-11-27, 0d
  Fin d'accès Sandbox                      :milestone, v4, 2026-11-28, 0d
```

Chemin critique : **contrats → FK/jobs/ledger → embeddings + hybride → runtime d'agents → runner → lacunes → rapports/PDF → suite `model` sur E2 → recette**. Le frontend dépend des **fixtures OpenAPI**, pas du backend terminé.

## 14.5 Flux de travail et propriété du code (découpage par couches, pas par machines)

| Flux | Packages possédés | Dépend de |
|---|---|---|
| **A — Core/Data** | `core` (db/dialect, jobs, auth, blobs, canonical_json), `workspaces`, migrations, CI, scripts (`doctor`, `setup`, `dev`) | contrats |
| **B — Connaissance** | `knowledge` (ingestion, ports `Embedder`/`VectorIndex`/`LexicalIndex`, archives, partage), `mandates` (CRUD) | contrats, A |
| **C — Simulation** | `agents`, `audit`, `simulation`, `scenarios` | contrats, A, `search()` (stub puis B) |
| **D — Analyse** | `gaps`, `mandates` (règles/graphe), `reports`, `evaluation` | contrats, catalogue d'événements |
| **E — Frontend** | `frontend/` | OpenAPI (fixtures) |
| **Coordinateur** | `contracts`, intégration, merges quotidiens, `docs/`, ADR | tous |

Règles : un **worktree par flux** ; interdiction de modifier un package d'un autre flux ; **merge quotidien** ; le **golden run** reste vert ; revue **indépendante** quotidienne par l'agent `audit`. **Contrats à figer en premier** (samedi matin) : modèles SQLAlchemy + DTOs ; catalogue d'événements (types, payload, visibilité, octets canoniques) ; OpenAPI stub ; ports (`LLMProvider.complete`, `Embedder.embed`, `search(scope, query, k)`, `detect(...)`) ; schéma d'archive de KB.

## 14.6 Ordre de report si le calendrier se dégrade (décidé à l'avance, sans toucher aux fondations)

1. XLSX, reranker, graphe de mandats, extraction de mandats par LLM → 2. G4–G10 → 3. comparaison de rapports/exercices → 4. import assisté de rapports antérieurs → 5. juge LLM du scorecard (grille manuelle conservée) → 6. vitesse/surprise → 7. observateur « tout » (lecture seule simple conservée) → 8. interface FR (clés i18n conservées, anglais complet) → 9. adaptateur Qdrant, RLS, OIDC, `pg_textsearch` (déjà hors vague). **Jamais reportés** : FK composites, jobs avec fencing, hybride vraie avec embeddings, permissions dans le SQL, citations vérifiées, ledger chaîné + vérification, snapshot + `exercise_scope_item`, siège humain, preuves des lacunes + revue humaine, export/import de KB vérifié, **PDF réel**, comptes + jetons hachés, étiquetage « SANS IA », **validation avec un vrai modèle**.

## 14.7 Organisation des modèles dans Claude Code (vérifiée)

| Rôle | Modèle (ID vérifié, [A8](appendix/A8-claude-code-capabilities.md)) | Usage |
|---|---|---|
| Coordinateur / architecte | **Sonnet 5.5** (`claude-sonnet-5-5`) | Conception, contrats, intégration, décision finale |
| Sous-agents | **Haiku 5.5** (`claude-haiku-5-5`) | `search` (recherche/vérification de sources), `grep` (analyse du dossier, incohérences), `audit` (revue indépendante) |
| Conseiller | **Opus 5.5** (`claude-opus-5-5`) | Décisions majeures (consulté sur cette révision) |
| « JEV » | **Introuvable** (documentation et web) | Non utilisé ; décisions déterministes dans le code Python |

Capacités effectivement disponibles dans cette installation : l'outil `Agent` accepte `model` ∈ {sonnet, opus, haiku, fable} et `isolation: worktree` ; **un worktree ne contient que les fichiers suivis par Git** — les documents non commités de `alerte-platform/` n'y sont pas : une revue en worktree exige de **commiter d'abord** (sur autorisation). Le drapeau `claude --advisor opus` est documenté mais **non vérifié pour la version installée** (l'exécutable `claude` n'est pas dans le PATH de ce shell) ; l'avis d'Opus a été obtenu en lançant un sous-agent de modèle `opus`. Les fichiers `.claude/agents/{search,grep,audit}.md` et un *hook* `PreToolUse` limitant l'écriture à `alerte-platform/` sont **proposés, non créés** (hors périmètre de cette phase). Le **Workflow** multi-agents (coût élevé) n'est lancé qu'avec accord explicite ([15](15-decisions-to-validate.md) V14).

## 14.8 Registre des risques (à jour)

| # | Risque | Prob. × Impact | Mitigation | Responsable |
|---|---|---|---|---|
| R1 | **Pas d'environnement E2** (endpoint de modèles) dimanche | Moyenne × critique | Désigner E2 aujourd'hui ; **dimensionnement indicatif (estimations non vérifiées)** : Qwen2.5-14B-Instruct en bf16 ≈ 28 Go de VRAM, en quantification 4 bits ≈ 8–10 Go ; 7B bf16 ≈ 15 Go ; viser ≥ 24 Go de VRAM ; + TEI/BGE-M3 ; repli : Sandbox plus tôt | Équipe |
| R2 | **Sandbox inconnue** (conteneurs ? PostgreSQL ? GPU ?) | Élevée × élevée | Questions aux organisateurs aujourd'hui ([16 §16.8](16-itu-reference-code-and-compliance.md)) ; profils `light`/`shared` | Équipe |
| R3 | Intégration greenfield (5 flux, 2 dialectes, 3 OS) | Élevée × élevée | Contrats gelés ; CI 3 OS dès le 1er commit ; golden run ; ordre « irréversible d'abord » | Coordinateur |
| R4 | Qualité des sorties structurées des modèles ouverts | Élevée × moyenne | Enveloppe plate, 4 pas, relance, repli ; mesure < 5 % d'échec ; modèle plus gros | Flux C |
| R5 | Qualité/droits du corpus (scans, mauvais fichiers, 141 pages, licences inconnues) | Élevée × moyenne | Réutiliser le texte extrait ; qualifier les droits ; documents manquants déclarés | Équipe |
| R6 | Détection perçue comme circulaire / pré-programmée | Moyenne × critique | Garde-fous doc 09 §9.9 ; contrôle négatif ; scénarios indépendants ; benchmark externe | Flux D |
| R7 | Parité PostgreSQL/SQLite (FK, JSON, verrous, dates) | Moyenne × élevée | `db/dialect/` ; contrats communs ; « fait = vert sur PG » | Flux A |
| R8 | Empreinte d'embedder / mélange de vecteurs | Moyenne × élevée | `embedder_profile` ; refus de mélange ; T-SEC-14 | Flux B |
| R9 | PDF sous Windows (Pango) | Moyenne × moyenne | WeasyPrint en image/Linux/macOS ; xhtml2pdf repli testé 3 OS | Flux D |
| R10 | Dérive de périmètre (30 livrables, 17 catégories) | Élevée × élevée | Vagues figées ; report ordonné §14.6 | Coordinateur |
| R11 | Le rapport technique de 5 pages contredit la plateforme (12 divergences relevées) | Certaine × moyenne | Le réécrire à partir de ce dossier avant le 8 déc. | Équipe |
| R12 | Fatigue/disponibilité (≤ 4 personnes) pour valider (mandats, droits, relecture aveugle) | Moyenne × moyenne | Validations groupées ; relecture aveugle limitée aux lacunes retenues | Équipe |

## 14.9 Revues du conseiller (Opus 5.5) et prise en compte

**Revue 1 (2026-11-20)** — intégrée dans la v1 : fournisseur `cassette`, `rationale` public + trace, enveloppe plate, citations limitées à l'activation, test contrefactuel, démo indépendante de la Sandbox.
**Revue 2 (2026-11-21)** — **corrigée dans la v2** : lexique **natif** sur `search_text` (la table de postings maison est écartée) ; pgvector **sans HNSW en P0** (scan exact pré-filtré) et `halfvec` ; Qdrant en **adaptateur** P2 ; **fencing** par `lease_token`, `llm_call` écrit avant l'appel (*effectively-once*), `waiting_input`, curseur SSE sur `seq` par exercice, tests de panne avec `ALERTE_FAULT` ; parité de dialectes (`PRAGMA foreign_keys`, `db/dialect/`) ; auth P0/P1 resserrée ; politique de partage « fédérée souveraine » avec dérogation par document et preuve de non-sortie ; quatre garde-fous de lacunes ajoutés (pré-engagement, contrôle négatif, cause, variance) ; badge composé pour le jury ; ordre de livraison « irréversible d'abord » ; E2 partagé + runner `gpu` + journal de validation **généré** ; pièges de portabilité (pgvector/Windows, NFC, `.gitattributes`, psycopg sync, xhtml2pdf+bidi) ; hachage du ledger sur octets stockés ; empreinte d'embedder complète ; **réutilisation du prototype** (registre §05 5.9). **Non retenu tel quel** : « corriger les 15 documents après mercredi » — le brief exige un dossier cohérent avant tout développement ; la révision a donc été faite avant, avec ADR 011-019 prioritaires. Les avis d'Opus n'ont pas été vérifiés par un second modèle ; les estimations de perfs hors mesures de §05 5.7 restent **non mesurées**.
