# 15 — Décisions V1 à V26 : révision, risques non résolus et questions aux organisateurs

> **Révision du 2026-11-21.** Statuts : **conservée** · **modifiée** · **rejetée** · **à confirmer** (attend une réponse de l'équipe ou des organisateurs). Les corrections de votre dernier brief sont prioritaires ; toute décision de la v1 incohérente avec elles a été modifiée ou rejetée. Aucune implémentation ne démarre avant votre validation.

## 15.1 Décisions V1 à V18 (v1) révisées

| Id | Décision | Proposition originale (v1) | Nouvelle recommandation | Justification | Conséquences | Statut |
|---|---|---|---|---|---|---|
| **V1** | Node.js | Installer Node 22 via nvm (sans root) ; build Docker multi-stage en plus | **Node 22 LTS** sur chaque poste de dev (`fnm`/`nvm`/`nvm-windows`/`volta`, `.nvmrc`, `engines`) ; `npm ci` ; l'image Docker/Podman construit le SPA mais **n'est pas obligatoire** pour développer | Vite 8 exige Node ≥ 20.19 / 22.12 [V] ; Docker non requis ([17](17-portability-environments-ci.md)) | Une installation locale par poste ; `doctor` vérifie | **modifiée** |
| **V2** | Valider l'architecture | Monolithe modulaire, FastAPI sync, SQLite WAL, SSE sur ledger, boucle maison, `SearchScope` dans le SQL | **Architecture v2** (ce dossier) : monolithe modulaire **multi-processus**, **PostgreSQL+pgvector cible / SQLite léger**, hybride vraie, jobs avec fencing, comptes, portabilité 3 OS | Votre brief de révision ; revue Opus du 2026-11-21 | Remplace la v1 ; ADR 011-019 priment | **à confirmer** (votre validation) |
| **V3** | PDF des rapports | P0 : page d'impression ; P1 : PDF serveur | **PDF réel dès la première version** : WeasyPrint (image/Linux/macOS/MSYS2) + xhtml2pdf (repli testé sur 3 OS) ; page d'impression = secours seulement | Exigence explicite ; PDF indépendant de la machine de dev | Dépendances Pango dans l'image ; gabarit CSS restreint pour xhtml2pdf | **rejetée** (au profit de PDF réel) |
| **V4** | Périmètre P0/P1/P2 et ordre de coupe | Listes P0/P1/P2 qui retardaient vecteurs, PDF, observateur, etc. | **Architecture cible complète** ; plan en **vagues de livraison** ordonnées « irréversible d'abord » ; ce qui ne tiendra pas mercredi est listé franchement ([14](14-implementation-plan.md) §14.1) | « Ne pas réduire les capacités fondamentales » | Report assumé de G4–G10, T3/T4 formels, XLSX, reranker, Qdrant, RLS, OIDC | **modifiée** |
| **V5** | Branche Git et dépôt | Branche dédiée `platform/rebuild` ; commits sur demande | **Conservée**, avec une précision : une revue en **worktree** exige des commits (les fichiers non suivis n'y sont pas) ; il faudra donc commiter les documents | Constat vérifié sur l'outil d'agents | Demande d'autorisation de commit le moment venu | **conservée** (à confirmer pour le commit) |
| **V5-bis** | **E2 : machine(s) puissante(s) de l'équipe** (nouveau) | — | Désigner **E2** (GPU, RAM, OS) qui héberge un endpoint partagé LLM+embeddings et un runner CI `gpu` | Brief : tests réels sur machine adaptée | Sans E2, le jalon IA est reporté à la Sandbox | **à confirmer** |
| **V6** | Rapport de lacunes à importer | `ALERTE_Technical_Report_v2.pdf` (section 6 : 6 lacunes de politique + 5 de standards) | **Conservée** : c'est le seul rapport rédigé du projet ; import comme **« analyse antérieure »** ; ne pas confondre avec les nouvelles lacunes ; dire s'il existe un autre document | Inventaire A3 | Saisie structurée assistée (P1) | **à confirmer** |
| **V7** | Modèle de test local | Télécharger un petit modèle sur la machine perso | **Rejetée** comme critère de conception : les fonctions IA sont validées sur **E2/E4** avec un modèle adapté (≈ 14B Apache-2.0) ; la machine perso utilise l'endpoint partagé ou `scripted` | Brief : ne pas dimensionner sur la machine personnelle | Dépend de V5-bis | **rejetée** (remplacée par V5-bis) |
| **V8** | Contacter les organisateurs | Écrire aujourd'hui (GPU, modèles, durée, API) | **Conservée et étendue** : liste de questions en §15.4 (Lab, format de record, localisation, PostgreSQL/conteneurs) | Interprétation des REQ contradictoires ([16](16-itu-reference-code-and-compliance.md)) | Je peux rédiger le message | **conservée** (à envoyer) |
| **V9** | Hiérarchie Simple / Spec | Simple = comportement ; Spec = outils/schémas/règles/métriques ; **vos exigences prévalent** | Inchangée | — | — | **conservée** |
| **V10** | Licences | Choisir la licence du code ; ne pas l'appliquer aux textes ; documents `unknown` par défaut | **Recommandation** : code sous **Apache-2.0** (ou MIT) ; politique de licences permissives ; **SBOM CycloneDX en CI** ; modèles par défaut Apache-2.0/MIT ; `MODEL_LICENSES.md`/`DATA_LICENSES.md` ([19](19-licenses-and-sbom.md)) | Brief §12 | CI bloquante sur licence interdite | **modifiée** (choix de la licence du code : à confirmer) |
| **V11** | Siège humain dans le MVP | Oui (web) ; Slack hors périmètre | Conservée, avec `waiting_input` (libère le lease) ; sièges liés à des comptes ou à des liens à portée | Revue Opus | — | **conservée** |
| **V12** | Statuts de lacunes | Deux axes + `evidence_origin` | Deux axes nommés **« Origine de la preuve »** (hypothèse / observé / déduit d'une règle / soutenu par les documents) et **« Statut de revue »** (proposé / confirmé / contesté / rejeté) + **cause** (institutionnelle / documentaire / artefact) ; **badge composé** pour le jury | Lisibilité jury ; garde-fous | Modèle `gap` v2 | **modifiée** |
| **V13** | Langue de l'interface | Anglais complet P0, français P1 | Conservée + **arabe : recherche et rapport RTL** exigés (pas d'interface arabe) | Jury anglophone ; UAE ; critère probable | Clés i18n dès le départ ; polices arabes embarquées | **conservée** (à confirmer FR en P0 ?) |
| **V14** | Parallélisation | Sessions séparées par worktree ; Workflow seulement avec accord | Conservée ; découpage **par couches** (A–E), pas par machines | Revue Opus | Workflow : accord explicite | **conservée** (à confirmer) |
| **V15** | Création des agents `.claude/agents`, hook, CLAUDE.md du projet | Après validation, dans `alerte-platform/.claude/` | Idem | Hors périmètre de cette phase | — | **à confirmer** |
| **V16** | Authentification | **Jetons seuls**, pas de comptes | **Rejetée** : comptes Argon2id, sessions serveur, rôles, jetons hachés à portée, port IdP (OIDC plus tard) | Brief §11 | Tables `app_user`, `workspace_member`, `auth_session`, `access_token` | **rejetée** |
| **V17** | API de modèles tierces autorisées ? | À confirmer (V8) | Interdites par défaut ; tout appel externe **enregistré** (`endpoint_ref`) ; question aux organisateurs | Données nationales | — | **à confirmer** |
| **V18** | Date de la finale et vidéo | 8 vs 9 décembre ; vidéo obligatoire si retenu | Inchangée | Page événement vs fiche | Sans effet sur le code | **à confirmer** |

## 15.2 Nouvelles décisions (révision)

| Id | Décision | Recommandation | Justification | Conséquences | Statut |
|---|---|---|---|---|---|
| **V19** | Base de données | **PostgreSQL 17/18 (cible) + SQLite (profil léger)**, mêmes modèles ; « fait = vert sur PG » | Déploiement partagé, transactions, jobs, vecteurs, audit dans un magasin ; SQLite pour dev/CI/repli Sandbox | Parité de dialectes suivie ([06 §6.8](06-data-model.md)) | **à confirmer** |
| **V20** | Recherche | **Hybride vraie** : embeddings réels (BGE-M3), pgvector **exact pré-filtré** (`halfvec`, sans HNSW en P0), lexique natif sur `search_text`, RRF ; Qdrant adaptateur P2 | [07](07-knowledge-and-rag.md), [A11](appendix/A11-vector-db-comparison.md), mesures [A16](appendix/A16-verification-log.md) | Perte de rappel du filtre HNSW **non reproduite**, à tester sur corpus réel | **à confirmer** |
| **V21** | Exécution | Processus `api` + workers (`sim`, `doc/export`), file en base avec **fencing** | Durabilité, reprise, concurrence | `app.dev` pour le dev ; compose en option | **à confirmer** |
| **V22** | Environnements | E1…E5 ([17](17-portability-environments-ci.md)) ; validation `model` sur E2/E4 uniquement ([18](18-validation-strategy.md)) | Brief §2, §13 | Journal de validation généré | **à confirmer** |
| **V23** | Portabilité | uv + Node 22, scripts Python (`doctor`, `setup`, `dev`), Docker **et** Podman optionnels, CI 3 OS | Brief §3 | PostgreSQL sous Windows via WSL2/Podman/serveur | **à confirmer** |
| **V24** | ITU | **Architecture fédérée souveraine** ; politique de partage par KB ; matrice de conformité R/I/S ; adaptateur de records ITU | [16](16-itu-reference-code-and-compliance.md) | Aucune donnée n'est déplacée sans décision explicite | **à confirmer** (et organisateurs) |
| **V25** | Modèles par défaut | Génération **Qwen2.5-14B-Instruct (Apache-2.0)** ou Mistral Nemo 12B ; embeddings **BGE-M3 (MIT)** ; reranker bge-reranker-v2-m3 | [19](19-licenses-and-sbom.md) ; fiabilité JSON à mesurer | Évite Llama/Gemma/Qwen 3B/72B par défaut | **à confirmer** (après mesure sur E2) |
| **V26** | Réutilisation du prototype `alerte/` | **Portage** derrière les ports (extraction/OCR sans PyMuPDF, chunker, texte déjà extrait, scénarios, mandats) ; ne pas porter moteur/UI | [05 §5.9](05-architecture-overview.md) | Copie + adaptation ; `alerte/` intact | **à confirmer** |

## 15.3 Risques non résolus

1. **E2 non désigné** et capacités de la **Sandbox inconnues** (conteneurs, PostgreSQL, GPU) : conditionnent V19-V22 et le jalon IA.
2. **Fiabilité des sorties structurées** de chaque modèle ouvert : à mesurer (< 5 % d'échec).
3. **Qualité de la recherche arabe** et du lexique FR/AR : à mesurer sur 30 requêtes de référence (aucun moteur lu ne confirme l'arabe de bout en bout hors Milvus).
4. **Perte de rappel d'un filtre post-HNSW** (pgvector) : non reproduite ; évitée par l'absence de HNSW en P0 ; à tester si HNSW introduit.
5. **Droits des documents** (aucune licence qualifiée) : l'export « ouvert » restera vide tant que non qualifiés.
6. **Rapport AI Readiness contradictoire** (local/distribué, format de record non défini) : interprétations §16.3 ; réponse des organisateurs nécessaire.
7. **Parité PostgreSQL/SQLite** et tests PostgreSQL non couverts sous Windows/macOS en CI.
8. **Perception de circularité** de la détection : garde-fous ([09](09-gap-analysis-and-reports.md) §9.9) à démontrer avec chiffres (contrôle négatif, κ, variance).
9. **Rapport technique de 5 pages** contradictoire avec la plateforme : à réécrire.
10. **Volume du périmètre** vs 4 jours : voir [14](14-implementation-plan.md) §14.1.
11. Références **[NV]/[P]** restantes (liste complète : [04 §H et H.1](04-best-practices-registry.md)) : NIST AI 600-1 (contenu), HSEEP/ISO 22398/CAP/IFRC (texte), EW4All (source secondaire), pages SQLite, version exacte de React/Vite (à relire à l'échafaudage), licence du paquet Milvus Lite, licences Qwen 0.5B/1.5B/Qwen3/Mistral 7B/Phi/DeepSeek.

## 15.4 Points à confirmer auprès des organisateurs (message à rédiger)

1. Le **ITU AI for Good Lab** héberge-t-il une KB vectorielle ? Quel **endpoint/format de record** ? Existe-t-il un **schéma** (REQ-024) ?
2. Un **record** transféré est-il une donnée soumise à REQ-026 (« data not moved from the country ») ? Les **embeddings** peuvent-ils être transférés ?
3. **Sandbox** : GPU (type, quantité), RAM, durée, modèles préinstallés, **conteneurs (Docker/Podman)**, **PostgreSQL**, accès Internet, **API de modèles hébergées autorisées** ? Fin d'accès le 28 : prolongation possible ?
4. **Licence open source** exigée pour le dépôt ? Format de présentation finale ; **date (8 ou 9 déc.)** ; vidéo obligatoire pour les équipes retenues (liste annoncée le 18 nov.) ?
5. Le dépôt d'exemple cité sur la page est-il bien la référence attendue (il n'est pas officiel ITU) ?
