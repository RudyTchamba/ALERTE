# 16 — Code de référence ITU, exigences de l'UIT et conformité

> Sources : dépôt cloné et lu le 2026-11-21 par un sous-agent ([A9](appendix/A9-itu-reference-code-study.md)) ; lecture intégrale des deux PDF ITU locaux ([A10](appendix/A10-itu-pdfs-findings.md)) ; pages officielles du hackathon ([A7](appendix/A7-research-hackathon-and-methods.md)). Niveau de certitude indiqué : **[LU]** lu, **[DÉDUIT]**, **[NV]** non vérifié. **Aucune affirmation de conformité n'est faite sans composant réellement utilisé** (§16.7).

## 16.1 Ce qu'est réellement le dépôt cité par la page du hackathon

La page de l'événement renvoie vers `github.com/CrashingGuru/ITUAIReadiness` comme « Reference code for KB creation » [LU]. Constats [LU, A9] :

| Point | Constat |
|---|---|
| Statut | **Dépôt non officiel de l'ITU** : un seul contributeur, créé le 2026-03-22, dernier push 2026-10-20 ; le nom ITU n'apparaît que dans le contenu. Licence **MIT** (© 2026 Vishnu Ram OV) |
| Contenu | Deux pipelines : (1) `simulation/` — FastAPI + **ChromaDB** + **Ollama** (qwen2.5:14b, nomic-embed-text), jeu d'**évaluation de maturité IA des pays** (7 agents = appels LLM isolés, graphe causal, what-if) ; (2) notebook Colab — RAG générique FAISS + all-MiniLM-L6-v2 + Llama 1B |
| Ingestion | docling optionnel (non packagé) → **PyMuPDF (AGPL-3.0)** en pratique ; chunks de 256 mots / 30 de recouvrement ; **IDs uuid4** (pas d'idempotence) ; métadonnées **plates** (pays déduit par regex du nom de fichier), sans titre/page/hash/licence/version |
| Schéma de « knowledge record » | **Aucun schéma unique** : chaque collection Chroma a le sien |
| Défauts confirmés | Filtre `dimension_id` sur une collection sans cette métadonnée (retrieval vide silencieux) ; `kb_decisions` jamais relue ; doubles indexations ; notebook de jeu cassé ; `AuditLog` n'audite pas les mutations de KB malgré la docstring |
| Absent | Permissions/auth (CORS ouvert), front React, tests, simulation multi-agents réelle, simulation de **crise** (le jeu évalue la maturité IA), isolation par pays, versionnement, évaluation |
| Documents | ~65 PDF (67 fichiers dont 2 `.txt`) redistribués **sans licence**, ce qui contredit son propre « not redistributed » ; comptes incohérents (27 / 57 / 67) |

## 16.2 Ce que disent réellement les exigences de l'UIT

Page du hackathon [LU, A7] : KB « mapped to and adhere to the published and open documents provided by the country » ; « vectorized, distributed knowledge base hosted in the ITU AI for Good Lab » construite avec le code de référence ; sources attendues : lois, stratégies nationales IA/numérique/cybersécurité, protection des données, PI.

Rapport **AI Readiness 2.0** [LU intégral, A10] — extraits pertinents :

| Réf. | Exigence |
|---|---|
| REQ-024 (p. 41) | La KB utilise un format de record **uniforme** ; « knowledge records are a processed form of data inputs. An example … is vectorized data records » — **le format n'est jamais défini** |
| REQ-015 (p. 40) | La KB est **hébergée dans l'ITU AI4G Sandbox** |
| REQ-025 (p. 41) | La KB est **distribuée**, les consommateurs sélectionnent/traitent les records selon leurs préférences |
| REQ-026 (p. 41) | Le toolkit est utilisé **localement** et **les données ne sortent pas du pays** ; la KB est mise à jour dans le Sandbox avec les formats de record |
| REQ-007 NOTE (p. 39) | Plusieurs instances connectées en parallèle au Sandbox « for KB records transfer only » |
| REQ-027/028 | Règles locales de confidentialité/gouvernance ; **seuls les records persistent**, les entrées sont supprimées après usage — *contredit par la FAQ 16 (p. 48)* |
| REQ-010 | Vérification des métadonnées et de la **provenance** des jeux de données, cycle de vie des modèles, conformité |
| p. 26 / Dim. 9 | « accountability of final decisions remains with humans » (garde-fou humain) |
| Ch. 4 | **Gap analysis** : trois catégories — lacunes de **standards**, de **mise en œuvre**, de **politiques** ; notion de **« compound gap »** (REQ-012) |

**Y.3172** [LU] : SRC, C, PP, M, P, D, SINK, MLFO, ML sandbox sont **définis dans le texte** (3.2.2, 3.2.6, 8.1) ; « ML intent » est décrit en NOTE 12 (8.1) mais non défini en clause 3 ; **aucune exigence d'audit, de traçabilité, de provenance ni d'intervention humaine** (clause 9 : seulement empêcher l'accès non autorisé et les fuites de données). Les concepts « knowledge record », vectorisation, agents, AI Lab **n'existent pas** dans Y.3172 : ils viennent du rapport AI Readiness.

## 16.3 Les tensions et leurs interprétations

| Réf. | Tension | Interprétation A | Interprétation B | Interprétation C |
|---|---|---|---|---|
| Tension A | **Local** (REQ-026) vs **hébergé au Sandbox** (REQ-015) vs **distribué** (REQ-025) | Le *toolkit* tourne dans le pays ; **seuls les records** (pas les sources) remontent au Sandbox | La KB de référence est centrale au Sandbox, les pays la consomment | Fédération : chaque pays garde sa KB ; le Sandbox agrège des records choisis |
| Tension B | Un « record » est-il une « donnée » au sens de REQ-026 ? | Non (forme traitée) | Oui (forme traitée **de** la donnée) → il ne sort pas | À préciser |
| Tension C | Vecteur = information ? | Un embedding peut conserver de l'information de la source | — | — |
| Tension D | Format de record | Aucun défini | « vectorized data records » en exemple | À demander |
| Tension E | Documents privés temporaires (FAQ 16) vs seuls records persistants (REQ-028) | — | — | À demander |

**Décision d'architecture (défendable quelle que soit la réponse)** : **architecture fédérée souveraine**, pilotée par une **politique de partage par KB** (doc 06 `knowledge_base.sharing_policy`) :

* `local_only` (**défaut**) — rien ne sort ; l'export reste un acte volontaire de l'utilisateur.
* `share_records` — chunks + métadonnées partageables, **sur décision explicite** consignée (`kb_share_record` : qui, quand, cible, portée, empreinte du manifest).
* `share_records_and_embeddings` — idem + vecteurs (traités comme records à part).
* **Dérogation par document** (`sharing_override=local_only`) dans une KB partageable.
* **Preuve de non-sortie** : l'endpoint de chaque appel LLM/embeddings est enregistré (`llm_call.endpoint_ref`) ; un seul appel vers une API externe contredit « les données restent dans le pays ».
* **Aucune publication automatique** vers un service externe ; la cible « ITU Lab » est un adaptateur configuré **dont les modalités sont à confirmer**.

## 16.4 Matrice de conformité aux exigences des organisateurs (composants réellement utilisés)

Statuts : **R** = code réutilisé (attribution MIT) · **I** = interopérable (testé automatiquement) · **S** = inspiré (concept, pas de code) · **—** = non couvert.

| # | Exigence des organisateurs | Composant ALERTE | Statut | Preuve / limite |
|---|---|---|---|---|
| 1 | KB alignée sur les documents officiels ouverts du pays | `knowledge` : provenance, validité, licence, couverture documentaire | — (conçu en propre) | Rapport de qualité C1 ; pas dérivé du dépôt (il n'a pas de métadonnées de provenance) |
| 2 | Extraction / structuration / ingestion avec le code de référence | Pipeline `ingest` (pypdfium2/pdfplumber/Tesseract, chunking par article) | **S** (idée générale) ; **pas R** | Leur ingestion a des défauts (A9 §J) et utilise PyMuPDF (AGPL) : **non réutilisée** ; on le dit |
| 3 | KB vectorisée | `VectorIndex` pgvector/SQLite exact, embeddings BGE-M3 | **S** (ChromaDB + nomic-embed chez eux) | Vecteurs réels, filtrés par portée |
| 4 | KB distribuée / hébergée au Lab | Export/partage de records + adaptateur Lab | **I** (profil de records ITU, §16.5) | Modalités du Lab **à confirmer** ; round-trip testé avec leur format Chroma (P2) |
| 5 | Format de record uniforme (REQ-024) | Schéma JSON versionné `alerte-kb-archive` + profil de records ITU | **S/I** | Leur format n'est pas défini (Tension D) ; on documente le nôtre et le mapping |
| 6 | Grille 13 dimensions | `data/framework/dimensions.json` → scorecard | **R** (données, attribution) | Libellés alignés avec le rapport (A10) ; échelle de maturité **non définie** par l'UIT : conçue par nous |
| 7 | Y.3172 (pipeline ML) | Table de correspondance nœuds → modules ([03](03-hackathon-conformance.md) §3.3) | **S** | Nœuds vérifiés dans le texte (A10) ; Y.3172 n'impose pas l'audit : c'est notre exigence propre |
| 8 | Agents institutionnels / coordination | `agents`, `simulation` | — (absent chez eux) | Le dépôt n'a pas de simulation multi-agents |
| 9 | Audit, traçabilité | `audit` (ledger chaîné) | — | `AuditLog` du dépôt n'audite pas la KB ; le nôtre est conçu en propre |
| 10 | Lacunes (standards / mise en œuvre / politiques) | Typologie `gaps` ([09](09-gap-analysis-and-reports.md)) alignée sur Ch. 4 | **S** | Catégories reprises comme axe de classement |

## 16.5 Adaptateur d'interopérabilité (profil « records ITU »)

Mapping bidirectionnel avec les métadonnées réelles du dépôt d'exemple (A9 §C.1) :

| Champ chez eux | Champ ALERTE | Remarque |
|---|---|---|
| `id` (uuid4) | `chunk.id` ; **ID déterministe** `sha256(source\|index\|texte)` dans l'export | Rend l'import idempotent |
| `document` | `chunk.text` | — |
| `metadata.source_file` | `document.code` + `document_version` | — |
| `metadata.source_type` (regex) | `document.doc_type` (validé) | Leur valeur vient d'une regex sur le nom de fichier ; la nôtre est validée par l'utilisateur |
| `metadata.country` (regex, défaut `global`) | `knowledge_base.country_id` / `document.jurisdiction` | Idem |
| `metadata.chunk_index`, `total_chunks` | `chunk.ordinal` + comptage | Contrôle de complétude |
| `metadata.ingested_at`, `document_category` | `document_version.created_at`, `knowledge_base.kind` | — |
| *(absent)* titre, éditeur, année, URL, licence, page, hash, version | présents chez nous | Ajoutés à l'export en champs supplémentaires |

* **Export** : JSONL (un record par chunk) + **export optionnel d'une collection Chroma** compatible (dépendance facultative, hors cœur) ; **import** : lit le même format, **recalcule les embeddings si le modèle diffère** (ne jamais mélanger les dimensions).
* **Test automatisé (P2)** : export ALERTE → collection Chroma au format du dépôt → **leur code de retrieval non modifié** → résultats → réimport ALERTE ; compare le nombre de chunks et les hashs de texte.
* Ne **pas** importer leurs `kb_decisions`/`kb_framework` tels quels (régénérés depuis notre référentiel).

## 16.6 Attribution et licence

Pour tout code ou donnée réutilisé : conserver `LICENSE` MIT et le copyright « Vishnu Ram OV », citer le dépôt et « ITU AI Ready — Analysis Towards a Standardized Readiness Framework, Report 2.0 (janvier 2026) » (source de `dimensions.json`). **Ne pas versionner** leurs PDF (droits des éditeurs) ; référencer les URL officielles. Ne pas utiliser leurs `sample_national_strategy_*.txt` (données synthétiques) comme sources. Contrôle du contenu de `dimensions.json` contre le rapport avant usage (fait : 13 libellés alignés).

## 16.7 Comment démontrer l'intégration aux évaluateurs (sans surdéclarer)

1. Présenter la **matrice §16.4** telle quelle, avec ses « — » : l'honnêteté est un argument.
2. Ne jamais écrire « code de référence ITU » sans nuance : écrire « **dépôt d'exemple cité par la page du hackathon (non officiel ITU)** ».
3. Démontrer l'**aller-retour** de records (§16.5) et la **politique de partage** (consentement consigné, preuve de non-sortie).
4. Montrer la typologie standards / mise en œuvre / politiques dans le rapport de lacunes, avec la structure *status quo → lacune → recommandations*.
5. Montrer l'**arabe** (recherche AR, rapport RTL) et l'**exécution réelle** sur la Sandbox (journal de validation).

## 16.8 Questions à poser aux organisateurs

1. Le Lab héberge-t-il une KB vectorielle ? Quel **endpoint / format de record** attend-il ? Un **schéma** existe-t-il (REQ-024) ?
2. Un « record » transféré au Sandbox est-il une donnée soumise à REQ-026 ?
3. Les embeddings peuvent-ils être transférés ?
4. Sandbox : GPU, durée, modèles disponibles, conteneurs (Docker/Podman) autorisés, PostgreSQL possible, API de modèles hébergées autorisées ?
5. Licence open source exigée pour le dépôt ? Date et format de la présentation finale (8 vs 9 décembre) ?
