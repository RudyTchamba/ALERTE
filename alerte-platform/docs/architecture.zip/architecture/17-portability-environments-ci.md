# 17 — Portabilité multiplateforme, environnements et CI

> Sources : [A13](appendix/A13-portability-pdf-ci.md) (recherche), [A12](appendix/A12-runtime-db-jobs.md), revue d'Opus (doc 14 §14.9), vérifications locales ([A16](appendix/A16-verification-log.md)). **[V]** lu, **[P]** partiel, **[NV]** non vérifié. L'application doit pouvoir être **clonée, installée, configurée et exécutée** sur Ubuntu/Linux, Windows et macOS. Docker/Podman sont des moyens **optionnels** de déploiement reproductible, jamais l'unique voie ; **Docker Desktop n'est pas requis** (licence commerciale conditionnelle).

## 17.1 Les cinq types d'environnement

| Id | Environnement | Rôle | Profil | Modèles/embeddings |
|---|---|---|---|---|
| **E1** | Machines de développement personnelles (n'importe quel OS, ressources quelconques) | Écrire du code, tests unitaires/intégration | `light` (SQLite) | `fixture` / `scripted` ; **ou** endpoint partagé de E2 |
| **E2** | **Machine(s) plus puissante(s) de l'équipe** (GPU si possible) | **Tests des fonctions IA réelles**, charge, OCR lourd, ré-indexation ; héberge un **endpoint partagé** (vLLM/Ollama + TEI) accessible à l'équipe (VPN/LAN) ; runner CI auto-hébergé (label `gpu`) | `shared-gpu` | Vrais modèles |
| **E3** | Déploiement partagé de recette (PostgreSQL + pgvector, api + workers) | Recette de bout en bout, démos d'équipe | `shared` | Via E2 ou Sandbox |
| **E4** | **Sandbox ITU** | Exécutions réelles, embeddings, mesures, preuves | `shared` si PostgreSQL/conteneurs possibles, sinon `light` (**à confirmer**) | Selon ressources (inconnues) |
| **E5** | Démonstration finale (Dubaï) | Démo reproductible | `shared` portable (compose) ou `light` ; cassettes + mini-run | Endpoint réel si disponible, sinon rejeu **étiqueté** |

Principe : **le code est identique** ; seule la configuration d'environnement change (variables `ALERTE_*`, fichiers compose, URLs de modèles). La machine de développement personnelle n'est **jamais** un critère de conception : tout ce qui ne peut y tourner est exécuté en E2/E3/E4 ([18](18-validation-strategy.md)).

## 17.2 Matrice de support par composant

| Composant | Linux (Ubuntu) | macOS | Windows | Remarques |
|---|---|---|---|---|
| Python 3.12 + `uv` | ✔ | ✔ | ✔ | `uv sync --locked` [P : doc uv non lue] |
| Node 22 (Vite 8 : ≥ 20.19 ou ≥ 22.12 [V]) | ✔ | ✔ | ✔ | `.nvmrc` ; `nvm`/`fnm`/`nvm-windows`/`volta` ; `npm ci` |
| **Profil `light`** (SQLite + `sqlite_exact` + FTS5) | ✔ | ✔ | ✔ | Aucune installation de base ; **voie normale sous Windows** |
| **PostgreSQL + pgvector** (profil `shared`) | ✔ natif ou conteneur | ✔ (brew + build ou conteneur) | **Pas de binaire pgvector officiel connu** [NV : avis du conseiller, à vérifier] : build MSVC/nmake, ou **WSL2 / Podman / serveur d'équipe** | Image `pgvector/pgvector:pg17` vérifiée ; sous Windows, utiliser le profil `light` ou un PostgreSQL distant (E3) |
| Tesseract (`ara+fra+eng`) | apt | brew | installeur UB Mannheim ; PATH ; `TESSDATA_PREFIX` | `doctor` détecte et explique ; tests OCR en `skip` si absent |
| PDF : WeasyPrint | apt (pango) | brew | **MSYS2** + pip [V] | Repli **xhtml2pdf** (pur Python) testé sur les 3 OS |
| Extraction PDF : pypdfium2 + pdfplumber | ✔ | ✔ (arm64 : vérifier les roues) | ✔ | PyMuPDF **exclu** (AGPL) |
| Docker / Podman | Docker Engine ou Podman | Podman via `podman machine`, ou Docker | Podman via `podman machine` (WSL2/Hyper-V [V]) | Compose standard OCI |
| Serveur de modèles | vLLM/Ollama/TEI | Ollama/TEI (Metal) | Ollama ; TEI Windows [NV] | Hors machine de dev : E2 |

## 17.3 Installation et démarrage (scripts portables)

| Script | Rôle |
|---|---|
| `scripts/doctor.py` (stdlib) | Vérifie : versions Python/Node, `uv`, Tesseract + langues, WeasyPrint/Pango, PostgreSQL/pgvector (si profil `shared`), accès aux endpoints de modèles/embeddings, droits d'écriture, espace disque ; sortie claire et **commandes d'installation propres à l'OS** |
| `scripts/setup.py` (stdlib) | Crée le venv (`uv sync --locked`), `npm ci`, copie `.env.example`, initialise la base (Alembic), vérifie la CI locale |
| `setup.sh` / `setup.ps1` | Enveloppes fines qui appellent `setup.py` (évite `make`, indisponible sous Windows) |
| `python -m app.dev` | Lance api + workers (+ Vite en option) via `subprocess.Popen`, groupe de processus Windows (`CREATE_NEW_PROCESS_GROUP`), arrêt propre |
| `python -m app.admin create-admin` | Crée le premier administrateur (pas d'inscription publique) |
| `python -m app.backup` / `restore` | Sauvegarde/restauration portables (§17.7) |

Documentation d'installation par OS dans `docs/runbooks/install-{linux,macos,windows}.md`, plus `docker/podman` (compose) et la voie « sans conteneur ».

## 17.4 Règles de portabilité du code

* **Chemins** : `pathlib` partout ; aucune concaténation de chaînes ; aucun chemin absolu en base ; `ALERTE_DATA_DIR` configurable ; **stockage adressé par SHA-256** (évite les noms réservés/interdits Windows, collisions de casse `Loi.pdf`/`loi.pdf` sous macOS/Windows, NFC/NFD macOS, `MAX_PATH` 260).
* **Encodage** : `encoding="utf-8"` explicite sur chaque `open()` ; `PYTHONUTF8=1` en CI ; ne pas s'appuyer sur PEP 686 avant Python 3.15 [NV].
* **Fins de ligne** : `.gitattributes` `* text=auto eol=lf` ; `binary` pour les fixtures et archives (sinon `autocrlf` casse les hashs).
* **Verrous de fichiers** (Windows) : fermer les handles avant `unlink`/`rename` ; aucun fichier ouvert pendant la suppression.
* **Processus** : `multiprocessing` en mode **spawn** (macOS/Windows) → aucun engine/connexion hérités ; code de lancement sous `if __name__ == "__main__"` ; **signaux Windows non fiables** → la reprise repose sur l'expiration de lease ([05 §5.6](05-architecture-overview.md)).
* **psycopg 3 en mode synchrone** (psycopg async incompatible avec la boucle Proactor de Windows).
* **Fuseaux** : dépendance `tzdata` ; tout en UTC.
* **Architecture CPU** : macOS arm64 vs x64 — vérifier les roues binaires (onnxruntime, pypdfium2…).
* **Dépendances verrouillées** : `uv.lock` + `uv sync --locked` ; `package-lock.json` + `npm ci` ; la CI échoue si un lock est désynchronisé ; actions GitHub **épinglées par SHA**.
* **Polices** : une police arabe libre est **embarquée** pour le PDF (sinon rendu dépendant de l'OS).

## 17.5 Docker / Podman (optionnels)

* `Dockerfile` multi-stage (Node → build SPA ; Python → image applicative avec Tesseract et Pango) ; `compose.yaml` avec profils `light`, `shared`, `shared-gpu` (+ `ollama`/`vllm`/`tei` optionnels) ; **aucune fonctionnalité réservée à Docker**.
* **Podman** : mêmes fichiers via `podman compose` ; rootless par défaut (ports < 1024 → rootful) [V] ; volumes avec `:Z`/`:z` sous SELinux [NV] ; Windows/macOS via `podman machine` (WSL2 ou Hyper-V [V], non simultanés) ; chemins Windows `/c/...` entre guillemets [V]. Test de fumée Podman dans la CI Linux (job non bloquant au début).
* Pas de socket Docker monté dans les conteneurs ; utilisateur non-root dans l'image.

## 17.6 CI GitHub Actions (stratégie, non une preuve de portabilité à elle seule)

| Job | OS | Contenu | Bloquant |
|---|---|---|---|
| `unit-integration` | **ubuntu-24.04, windows-2025, macos-15** | `uv sync --locked`, `pytest -m "not model and not gpu and not postgres"` (profil `light`, SQLite), tests de contrat des ports sur adaptateurs `fixture`, migrations Alembic **de zéro** (SQLite), tests de chemins/encodage/noms NFC, PDF `xhtml2pdf` (texte extrait par pypdfium2), Tesseract (**skip** si absent, seuil de CER sinon) | Oui |
| `frontend` | 3 OS | `npm ci`, lint, `tsc`, Vitest, `schema.d.ts` à jour, axe a11y | Oui |
| `postgres` | ubuntu-24.04 (service container `pgvector/pgvector:pg17`) | Migrations de zéro, **tests de contrat PG**, jobs/lease/fencing, recherche pgvector, test de propriété de portée, WeasyPrint, compose build | Oui |
| `kill-resume` | ubuntu-24.04 (+ windows en non bloquant) | Tests de pannes : `ALERTE_FAULT` + `Popen.kill()` ; zombie par `SIGSTOP`/`SIGCONT` (Linux/macOS) | Oui (Linux) |
| `e2e` | ubuntu-24.04, windows-2025 | Playwright sur le parcours de bout en bout, fournisseur `scripted` **étiqueté** | Oui |
| `model` | **runner auto-hébergé E2** (label `gpu`) | `pytest -m model` : vrais LLM + embeddings, recherche hybride, citations ; **journal de validation généré** | Pas par PR : nocturne + avant jalon |
| `sbom-licences` | ubuntu-24.04 | CycloneDX (Python + npm), contrôle des licences, `pip-audit`/`npm audit` ([19](19-licenses-and-sbom.md)) | Oui |
| `postgres-win-mac` | windows/macOS | PostgreSQL natif via setup | **Non bloquant** (à vérifier ; service containers Linux uniquement [V]) |

Limites reconnues : PostgreSQL/pgvector testé **sur Linux seulement** en CI ; macOS coûte nettement plus de minutes facturées si le dépôt est privé [NV : multiplicateur à vérifier dans la facturation GitHub] ; les runners GPU hébergés exigent des plans payants [V] → runner auto-hébergé. Ne pas présenter une compilation Linux comme preuve multiplateforme : le tableau ci-dessus dit précisément ce qui est testé où.

## 17.7 Sauvegarde et restauration portables

| Élément | Méthode |
|---|---|
| Base PostgreSQL | `pg_dump` (format custom) ; SQLite : API `sqlite3 .backup` (jamais copie à chaud du fichier) |
| Blobs | Répertoire adressé par SHA-256 : copie ou `rsync`/`robocopy`/archive ; vérification des hashs |
| Paquet de sauvegarde | `alerte-backup-<date>.zip` : dump + manifeste (versions de schéma/format, hashs) + blobs ; `restore` valide le manifeste puis restaure dans un espace vide ; test **aller-retour PG↔SQLite non supporté** pour la base brute (on passe par les exports logiques de KB et de rapports) |
| Exports logiques | Archives de KB et rapports (doc 07, 09) : portables entre dialectes ; le **ledger** est transporté avec ses `canonical_bytes` (hash vérifiable après import) |
| Clés | Clé de signature des ancres sauvegardée **séparément** (jamais dans le paquet) |

## 17.8 Pièges multiplateformes suivis (à tester dès le premier commit)

Noms de fichiers Windows (`:` `*` `?` `"` `<` `>` `|`, noms réservés CON/NUL/COM1, dates avec `:`) · chemins longs · fins de ligne des scripts `.sh` · encodage des `open()` · fichiers ouverts non supprimables · `spawn` et pickling · SQLite `check_same_thread` · Tesseract hors PATH · polices arabes · macOS arm64/x64 · Podman sous Windows · version de Node · lockfiles désynchronisés · NFC/NFD macOS · casse insensible (Windows/macOS) · `tzdata`.
