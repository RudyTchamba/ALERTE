# 18 — Stratégie de validation sur plusieurs machines

> Principe : **le code est conçu une seule fois et validé dans plusieurs environnements** ([17](17-portability-environments-ci.md) §17.1). La machine de développement personnelle (E1) n'est qu'un poste parmi d'autres : tout test qui exige des ressources est assigné **explicitement** à l'environnement adapté (E2 machine puissante de l'équipe, E3 recette, E4 Sandbox, E5 démo). **On ne réduit jamais une fonctionnalité pour faire passer un test sur E1.**

## 18.1 Règles non négociables

1. `scripted` et `cassette` sont des **outils de test déterministes et de rejeu**. Ils **ne prouvent pas** le fonctionnement des agents IA : tout exercice, rapport ou métrique issu de ces modes porte l'étiquette **« SANS IA » / « REJEU »** (champ `exercise.ai_mode`, bandeau UI, en-tête de rapport).
2. **Un jalon de fonctionnalité IA n'est « validé » qu'après un test `model` réussi avec un vrai modèle et de vrais embeddings** sur E2 (ou E4). Avant cela, son statut est « implémenté, non validé ».
3. Chaque validation est consignée dans le **journal de validation** (§18.4), généré automatiquement.
4. Une fonctionnalité de base de données est « faite » seulement si elle est **verte sur PostgreSQL** ; SQLite doit rester vert.
5. Un test qui ne peut pas tourner sur E1 est marqué (`model`, `gpu`, `postgres`, `load`) et **indique** l'environnement requis ; il n'est jamais supprimé ni affaibli.

## 18.2 Marqueurs pytest et environnements

| Marqueur | Exigence | Où il s'exécute | Déclencheur |
|---|---|---|---|
| `unit` | Rien | E1, CI 3 OS | chaque commit |
| `integration` | SQLite, fixtures | E1, CI 3 OS | chaque commit |
| `postgres` | PostgreSQL + pgvector | CI Linux, E3 | chaque PR |
| `contract` | Contrats communs des ports (`VectorIndex`, `LexicalIndex`, `Embedder`, `LLMProvider`, `PdfRenderer`) sur **tous** les adaptateurs disponibles | CI | chaque PR |
| `restart` | Pannes injectées, `Popen.kill()`, zombie | CI Linux (+ Windows non bloquant), E3 | chaque PR |
| `model` | **Vrai LLM + vrais embeddings** (endpoint E2/E4) | **E2 (runner `gpu`)**, E4 | nocturne + avant chaque jalon |
| `gpu` | GPU | E2 | nocturne |
| `ocr` | Tesseract + langues | CI (skip si absent), E2 | PR concernant l'ingestion |
| `e2e` | API+UI, `scripted` étiqueté ; version `model` sur E2 | CI ; E2 | PR ; avant jalon |
| `load` | Charge, SSE multiples, ingestion simultanée | E3/E4 | avant démo |
| `crossos` | Chemins, encodage, noms, NFC | CI 3 OS | chaque commit |

## 18.3 Les dix familles de tests demandées

| # | Famille | Contenu précis | Environnement |
|---|---|---|---|
| 1 | Unitaires et intégration automatisés | Règles G, canonisation/hachage, citation checker, chunking, analyseur FR/AR, RRF, transitions d'état, API | E1 + CI |
| 2 | Multiplateformes | Chemins/encodage/noms, migrations de zéro, PDF `xhtml2pdf`, install via `doctor`/`setup` | CI ubuntu/windows/macos |
| 3 | Machine puissante de l'équipe | Toute la suite `model` + `gpu` + `ocr` complète | **E2** |
| 4 | Vrais modèles et vrais embeddings | Enveloppe d'action (taux d'échec de schéma < 5 % sur 50 prompts/modèle), citations, discipline de rôle, `ask_legal`, signature d'embedder | **E2/E4** |
| 5 | Recherche vectorielle et hybride | **Test de propriété de portée** (aucun chunk hors portée, canari) sur chaque adaptateur ; **30 requêtes FR/AR de référence** (jeu de **recette** distinct des 40 questions du protocole T1) : recall@5/10, MRR, nDCG pour lexical seul / dense seul / hybride ; qualité de l'arabe ; perf à 5 k, 50 k, 200 k chunks | CI (propriété) ; **E2** (qualité/perf) |
| 6 | Traitement documentaire et OCR | 30 pages FR/EN/AR (10 scannées) : CER OCR, qualité d'extraction, articles détectés, pages à relire ; ingestion d'une archive piégée | CI (sans OCR lourd) ; **E2** |
| 7 | Bout en bout sur scénarios réels | Les 15 étapes ([13](13-security-testing-deployment.md) §13.6) ; version `scripted` étiquetée **et** version `model` | CI ; **E2/E3** |
| 8 | Sandbox | Déploiement, vrais runs, embeddings de la KB, cassettes, mesures T1–T6, exports finaux | **E4** |
| 9 | Reprise après interruption | `kill -9` d'un worker en plein tour, après un appel LLM avant le commit, au milieu d'un lot d'ingestion/PDF ; zombie `SIGSTOP`→`SIGCONT` | CI Linux ; E3 |
| 10 | Performance et charge | 2–3 flux SSE + 1 exercice + 1 ingestion simultanés ; verrous ; temps de recherche ; saturation des workers | **E3/E4** |

### Assertions des tests de reprise (9)

La chaîne du ledger se vérifie ; **aucun `seq` en double ni manquant** ; aucun message d'agent dupliqué ; la nouvelle tentative est **visible au ledger** (`LLM_CALL` (`retried=true`)) ; la reprise intervient en ≤ TTL du lease + délai de poll ; un worker zombie dont l'écriture est refusée (`lease_token` périmé) n'écrit rien.

## 18.4 Journal de validation (généré, jamais écrit à la main)

Un script lit les rapports JUnit des runs `model`/`gpu`/`e2e` et l'**empreinte de configuration** (modèle de génération + révision, embedder + empreinte complète, version du moteur, OS, GPU, commit) et produit `docs/validation-log.md` :

| Fonctionnalité IA | Test | Environnement | Machine | Modèle / embedder | Commit | Date | Résultat |
|---|---|---|---|---|---|---|---|
| (généré) | | | | | | | |

Un jalon est réputé validé **uniquement** si la ligne correspondante existe pour un environnement `model`. Les journaux de runs `scripted`/`cassette` y figurent dans une section **« non probant IA »**.

## 18.5 Évaluation de la détection de lacunes (indépendante du développement)

| Mesure | Protocole | Environnement |
|---|---|---|
| **Contrôle négatif** | Exercice dont les mandats sont **complets** pour les actions demandées : on attend ≈ 0 lacune ; on publie le **taux de faux positifs** | E2 |
| **Ablation de corpus** | Retirer/ajouter un document → la lacune apparaît/disparaît (avec limite : n'écarte pas à lui seul « pré-programmé ») | E2 |
| **Scénarios de validation indépendants** | Rédigés et scellés par une **deuxième personne** qui ne construit pas le registre | E2 |
| **Benchmark externe** | Listes de lacunes de sources externes (IFRC, EW4All, catégories AI Readiness) : couverture mesurée sans nos fixtures | E2 |
| **Variance** | ≥ 3 exécutions (et ≥ 2 modèles si possible) : taux de stabilité des signaux et des lacunes ; les règles G doivent produire les **mêmes** lacunes `rule_deduced` quel que soit le modèle | E2 |
| **Revue humaine aveugle** | Deux relecteurs, sans voir l'étiquette du détecteur : précision avec **intervalle de confiance** et **κ** | équipe |
| **Pré-engagement** | `commitment_sha256` (règles + demandes + registre) inscrit au lancement | automatique |

## 18.6 Jalons et critères d'acceptation

| Jalon | Critère | Environnement de validation |
|---|---|---|
| **M0 — Squelette** | 1 événement → ledger → SSE → page ; CI 3 OS verte ; migrations de zéro sur les deux dialectes | CI |
| **M1 — Chaîne de bout en bout** | Les 15 étapes réelles en `scripted` étiqueté ; **premier appel à un vrai modèle dès que E2 expose un endpoint** (cible : dimanche soir) | CI + E2 |
| **M1b — IA validée** | Suite `model` verte : agents, citations, hybride FR/AR, 1 exercice complet avec vrai modèle ; journal de validation généré | **E2** |
| **M2 — Stabilisation** | Reprise après kill, charge, sécurité (17 tests), PDF, SBOM ; T1–T6 calculées ou « non calculées » | E3 + E4 |
| **M3 — Démo** | Kit exporté (KB + embeddings, cassettes, rapports) ; répétition sur E5 | E5 |

## 18.7 Organisation de la validation collaborative

* **E2 expose un endpoint partagé** (vLLM ou Ollama avec un modèle Apache-2.0 type Qwen2.5-14B ; TEI avec BGE-M3) via VPN/LAN : toute l'équipe frappe le vrai modèle dès le début.
* **Runner GitHub auto-hébergé** sur E2 (label `gpu`) : suite `model` nocturne.
* Le parallélisme du travail est découpé **par couches** (core, knowledge, simulation+gaps, frontend), **pas par machines** ([14](14-implementation-plan.md)).
* Le choix et le dimensionnement de E2 (GPU, RAM, modèle servi) sont une **décision d'équipe à confirmer** ([15](15-decisions-to-validate.md)).
