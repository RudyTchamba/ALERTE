# 19 — Licences, dépendances et SBOM

> Source : [A14](appendix/A14-licenses-sbom-models.md) (sous-agent, fichiers LICENSE et cartes de modèles officiels) et [A11](appendix/A11-vector-db-comparison.md). **[V]** fichier de licence lu ; **[P]** connaissance générale non relue — **à confirmer automatiquement au verrouillage des dépendances** (§19.4). **Ce document n'est pas un avis juridique** ; les points signalés §19.7 en exigent un. Une technologie gratuite n'est pas nécessairement open source ; **aucune dépendance propriétaire n'est obligatoire** pour l'exécution normale d'ALERTE.

## 19.1 Politique de licences

| Catégorie | Règle |
|---|---|
| **Autorisées par défaut** | MIT, Apache-2.0, BSD-2/3, ISC, PostgreSQL License, PSF, domaine public, Unlicense/0BSD |
| **À revue explicite** (liste de décision) | LGPL (lien dynamique, non modifié, documenté), MPL-2.0, CC-BY (données/modèles) |
| **Interdites sans décision d'équipe** | AGPL, GPL (dans le chemin distribué), SSPL, BUSL/BSL, Elastic License, RSAL, « source-available », licences non commerciales (CC-BY-NC) |
| **Licence du code d'ALERTE** | À décider (**V10**) ; recommandation Apache-2.0 ou MIT ; elle ne s'applique **pas** aux documents ni aux modèles |

## 19.2 Logiciels — points d'attention (liste complète générée par la CI, §19.4)

| Composant | Licence | Statut | Décision |
|---|---|---|---|
| **PyMuPDF** | **AGPL-3.0** (ou commerciale Artifex) | [V] | **Exclu.** Remplacé par pypdfium2 (Apache-2.0 ou BSD-3) + pdfplumber (MIT) / pdfminer.six / pypdf. Le prototype `alerte/` et le dépôt d'exemple ITU l'importent : à retirer au portage |
| **Docker Desktop** | Conditionnelle (gratuit < 250 employés **et** < 10 M$ de CA) | [V] | **Non requis.** Docker Engine/Compose (Apache-2.0) ou **Podman** (Apache-2.0) |
| **psycopg 3** | LGPL-3.0 | [P] | Accepté comme dépendance non modifiée, **documentée** ; alternative asyncpg (Apache-2.0) si refus |
| PostgreSQL | PostgreSQL License | [P] | OK |
| pgvector | PostgreSQL License | [V] | OK |
| SQLite | Domaine public | [P] | OK |
| WeasyPrint | BSD-3-Clause | [P] | OK ; xhtml2pdf (Apache-2.0) en repli |
| ReportLab | BSD (open source) + offre commerciale distincte | [P] | Non retenu (inutile) |
| Tesseract + tessdata | Apache-2.0 | [P] | OK ; vérifier le LICENSE du dépôt tessdata |
| pdfplumber / pypdfium2 / snowballstemmer | MIT / Apache-2.0 ou BSD-3 / BSD-3 (MIT) | [P] | OK |
| FastAPI, Starlette, Uvicorn, Pydantic, SQLAlchemy, Alembic, httpx, NumPy, NetworkX | MIT / BSD-3 | [P] | OK |
| argon2-cffi | MIT | [P] | OK |
| cryptography | Apache-2.0 ou BSD-3 | [P] | OK |
| `rfc8785` (JCS) | **[NV]** | [NV] | Vérifier la licence du paquet PyPI ; sinon implémentation interne (≈ 80 lignes) |
| React, Vite, TypeScript, React Router, TanStack, Tailwind, Radix, shadcn/ui (code copié), lucide-react, Recharts, react-i18next, openapi-typescript, Vitest, Playwright | MIT / Apache-2.0 / ISC | [P] | OK ; conserver l'attribution de shadcn/ui |
| ChromaDB | Apache-2.0 | [V] | Hors cœur (export de profil ITU, dépendance facultative) |
| Qdrant | Apache-2.0 | [V] | Adaptateur optionnel (P2) |
| Milvus / Lite | Apache-2.0 (licence du paquet **Lite non vérifiée**) | [V]/[NV] | Non retenu |
| FAISS, LanceDB | MIT, Apache-2.0 | [V] | Non retenus |
| ParadeDB `pg_search`, VectorChord-bm25 | **AGPL-3.0** / AGPLv3 ou **ELv2** | [V] | **Exclus** |
| pg_textsearch (Timescale) | PostgreSQL License | [P] | Optionnel plus tard (jeune) |
| Ollama, llama.cpp, vLLM, TEI | MIT, MIT, Apache-2.0, Apache-2.0 | [P] | OK (serveurs hors image) |
| Dépôt d'exemple ITU (CrashingGuru/ITUAIReadiness) | MIT (© 2026 Vishnu Ram OV) | [V] | Attribution si du code/des données sont réutilisés ([16](16-itu-reference-code-and-compliance.md)) |

### 19.2b Compléments relevés par l'audit (à confirmer par l'outillage du §19.4)

| Composant | Licence attendue | Statut | Remarque |
|---|---|---|---|
| python-docx | MIT | [P] | Ingestion DOCX |
| pypdf, pdfminer.six | BSD-3 ; MIT | [P] | Cités sans fiche |
| RapidOCR | Apache-2.0 | [NV] | OCR de repli sans installation système ; arabe à valider |
| docling | MIT | [P] | Optionnel ; modèles téléchargés à vérifier séparément |
| sentence-transformers | Apache-2.0 | [P] | Adaptateur `Embedder` optionnel |
| pytesseract | Apache-2.0 | [P] | — |
| **Pango** (requis par WeasyPrint) | LGPL-2.1+ | [P] | Bibliothèque **système**, liée dynamiquement ; à documenter |
| **arabic-reshaper**, **python-bidi** (repli xhtml2pdf RTL) | **[NV]** (python-bidi : licence copyleft possible) | [NV] | **À vérifier avant d'adopter le repli RTL** ; alternative : implémentation interne ou autre rendu |
| axe-core (tests a11y) | MPL-2.0 | [P] | Outil de test, non distribué |
| Polices arabes libres (ex. Noto Naskh Arabic, Amiri) | SIL OFL 1.1 attendue | [NV] | Licence à vérifier ; mention dans `THIRD_PARTY_LICENSES.md` |

## 19.3 Modèles et poids (licence du code ≠ licence des poids ≠ conditions d'usage)

| Modèle | Licence des poids | Statut | Décision |
|---|---|---|---|
| **Qwen2.5-7B / 14B / 32B-Instruct** | **Apache-2.0** | [V] | **Par défaut** (génération) |
| Qwen2.5-3B | `qwen-research` (non commerciale/recherche) | [V] | **Évité** |
| Qwen2.5-72B | Licence « Qwen » propre | [V] | À revue juridique |
| **Mistral Nemo 12B** | **Apache-2.0** | [V] | Alternative |
| Llama 3.x | Llama Community License (non OSI ; seuil 700 M d'utilisateurs ; « Built with Llama ») | [V] | **Non par défaut** ; optionnel après revue |
| Gemma | Gemma Terms of Use (propriétaire ; redistribution conditionnée) | [V] | **Non par défaut** |
| Qwen2.5-0.5B/1.5B, Qwen3, Mistral 7B/Small, Phi, DeepSeek | **[NV]** (cartes illisibles) | [NV] | Vérifier la carte avant tout usage |
| **BGE-M3** (embeddings, dense+sparse+multi-vector, 1024 d) | **MIT** | [V] | **Par défaut** |
| multilingual-e5-large(-instruct) | MIT | [V] | Alternative |
| **bge-reranker-v2-m3** | **Apache-2.0** | [V] | Reranker optionnel |
| nomic-embed-text-v2-moe, Qwen3-Embedding-0.6B | Apache-2.0 attendu | [NV : API Hugging Face non lue] | Alternatives (arabe non confirmé) |
| **jina-embeddings-v3** | **CC-BY-NC-4.0** (non commercial) | [P] | **Exclu** |

Pour les modèles : support FR/AR/EN annoncé mais **non vérifié sans exécution** ; la **fiabilité des sorties structurées JSON Schema** (vLLM/Ollama) doit être mesurée sur E2 (taux d'échec < 5 %) avant d'adopter un modèle ([18](18-validation-strategy.md)). Un fichier `MODEL_LICENSES.md` consigne, pour chaque modèle réellement servi : nom, révision, licence des poids, source, condition d'usage, date de vérification.

## 19.4 SBOM et contrôle de licences (CI)

| Étape | Outil | Détail |
|---|---|---|
| SBOM Python | `cyclonedx-py` (CycloneDX 1.6) | Généré depuis `uv.lock` à chaque PR, publié comme artefact |
| SBOM npm | `@cyclonedx/cyclonedx-npm` | Depuis `package-lock.json` |
| SBOM image | `anchore/sbom-action` (Syft) | Pour l'image `alerte-platform` |
| Inventaire des licences | `pip-licenses`, `license-checker` | **Échec de la CI** si une licence hors liste autorisée apparaît (dépendances **transitives** incluses) |
| Vulnérabilités | `pip-audit`, `npm audit`, OSV-Scanner ; `actions/dependency-review-action` | Bloquant à partir de « high » |
| Épinglage | Actions GitHub par SHA ; images de base par digest ; `uv.lock`, `package-lock.json` | — |
| Conformité du dépôt | `REUSE` (SPDX headers) en option | — |

Format privilégié : **CycloneDX 1.6** (SPDX si un organisateur l'exige). Le SBOM et `THIRD_PARTY_LICENSES.md` (généré) sont livrés avec le dépôt.

## 19.5 Données et documents importés

* **Par document** : `license_spdx` (ou `LicenseRef-…`), `redistribution` (`allowed | restricted | unknown`, défaut `unknown`), source, date d'accès. **Aucune supposition juridique** sur les textes officiels (cf. [07 §7.6](07-knowledge-and-rag.md)) : la méthode est de qualifier chaque document, pas de le présumer libre.
* `DATA_LICENSES.md` généré à l'export ; export « ouvert » = uniquement les documents `allowed`.
* Cas connus à qualifier avant publication (A3) : Banque mondiale (CM-17, GL-07), éditeur scientifique (AE-06), presse (CM-14), publications OMS/ITU, corpus de l'UE.
* **Ne pas redistribuer** les PDF du dépôt d'exemple ITU (aucune licence pour ces documents).

## 19.6 Registres tenus dans le dépôt

`LICENSES/` (textes), `THIRD_PARTY_LICENSES.md` (généré), `sbom/*.cdx.json` (généré), `MODEL_LICENSES.md`, `DATA_LICENSES.md`, `docs/adr/` (décisions de licence).

## 19.7 Points nécessitant un avis juridique ou une confirmation

PyMuPDF (si jamais réintroduit) · Llama / Gemma / Qwen 72B / Qwen 3B si utilisés · Docker Desktop (si imposé) · **redistribution de tout document officiel** (ITU, OMS, Banque mondiale, éditeurs) · licence de `dimensions.json` (contenu ITU : attribution) · licence du paquet Milvus Lite · conditions d'usage des textes nationaux du Cameroun et des Émirats.
