# ALERTE Platform — Dossier d'architecture technique et fonctionnelle (v2)

> **Statut : version 2 révisée (2026-11-21), en attente de validation.** Aucun code n'a été écrit ; seuls ces documents existent dans `alerte-platform/`. L'ancien dossier `alerte/` est intact. Le résumé de ce qui a changé entre la v1 et la v2 est dans **[00 — Révision du 2026-11-21](00-revision-2026-11-21.md)**. Rédigé par Claude Sonnet 5.5 (coordinateur) ; recherches et audits par sous-agents Haiku 5.5 ; deux revues critiques d'Opus 5.5.

## Résumé

1. **ALERTE Platform** simule des exercices de crise où des agents (ou des humains) jouent des **institutions réelles** bornées par leurs mandats et leurs sources ; les **lacunes institutionnelles émergent** des documents, du registre de mandats, des événements, des interactions et de règles — jamais déduites d'une liste de lacunes pré-écrite (les *demandes* du scénario restent identifiées comme saisies de l'auteur).
2. **Monolithe modulaire** FastAPI + SQLAlchemy 2.0, SPA React/TypeScript/Vite ; **plusieurs processus du même code** : `api` + workers (`sim`, `doc/export`) sur une **file de jobs en base avec fencing** (reprise après interruption, idempotence).
3. **Base cible PostgreSQL 17/18 + pgvector** ; **SQLite** en profil léger (dev, CI sur 3 OS, repli). Isolation entre espaces de travail **garantie par clés étrangères composites**.
4. **Recherche hybride réelle** : embeddings (BGE-M3 par défaut, port interchangeable), recherche vectorielle **exacte pré-filtrée par la portée du siège**, lexique natif FR/AR, fusion RRF ; lexical seul = mode dégradé signalé. Permissions **dans le SQL**.
5. **Agents** : boucle contrôlée par le backend, 4 outils, enveloppe JSON plate, **contrôle de citation déterministe**, coordinateur **en code**. `scripted`/`cassette` = outils de test, **jamais une preuve** ; un jalon IA n'est validé qu'avec un **vrai modèle** sur une machine adaptée.
6. **Audit** : ledger SHA-256 sur **octets canoniques stockés**, `ledger_head` par exercice, ancres contre la troncature, rejeu sans rappeler les modèles, trace de décision.
7. **Gap Analysis** : règles G1–G10 exécutables, signaux observés, **couverture documentaire**, cause (institutionnelle / documentaire / artefact), deux axes lisibles (**origine de la preuve**, **statut de revue**), garde-fous d'indépendance (pré-engagement, contrôle négatif, scénarios indépendants, benchmark externe, relecture aveugle).
8. **Rapports** versionnés : MD, JSON, CSV, XLSX et **PDF réel** (WeasyPrint + repli xhtml2pdf), import de rapports antérieurs, comparaison.
9. **Intégration ITU** : architecture **fédérée souveraine**, politique de partage par KB, matrice de conformité honnête avec le dépôt d'exemple cité par la page du hackathon (non officiel, MIT, défauts relevés).
10. **Portabilité Linux/Windows/macOS**, Docker/Podman **optionnels**, CI sur 3 OS, licences et SBOM, validation multi-machines (E1–E5).

## Index

| # | Document | Contenu |
|---|---|---|
| **00** | [Révision du 2026-11-21](00-revision-2026-11-21.md) | **Synthèse des modifications**, livrables demandés, validations techniques (diagrammes, liens) |
| 01 | [Vision et périmètre](01-vision-and-scope.md) | Finalité, principes d'intégrité, généricité, parcours, principes transverses |
| 02 | [Exigences et arbitrages](02-requirements-and-arbitration.md) | Registre FR-xx (y compris FR-70…83), arbitrage Simple/Spec |
| 03 | [Conformité hackathon](03-hackathon-conformance.md) | Critères officiels, matrice C1–C5, Y.3172 **vérifié** |
| 04 | [Bonnes pratiques](04-best-practices-registry.md) | 48 pratiques sourcées, pratiques écartées, **revue des [NV]/[P]** |
| 05 | [Architecture globale](05-architecture-overview.md) | C4, modules, **modèle d'exécution**, pile, profils, **réutilisation du prototype** |
| 06 | [Modèle de données](06-data-model.md) | ERD (5 vues), **FK composites**, normalisation, parité de dialectes |
| 07 | [Connaissances et RAG](07-knowledge-and-rag.md) | Pipeline, **recherche hybride**, permissions, export/import, **partage** |
| 08 | [Agents et simulation](08-agents-and-simulation.md) | Outils, boucle, citations, scénarios, états, humain, **exécution en workers** |
| 09 | [Lacunes et rapports](09-gap-analysis-and-reports.md) | Typologie, règles, **nature des résultats**, **garde-fous**, rapports/PDF |
| 10 | [Audit et évaluation](10-audit-and-evaluation.md) | Ledger, **octets canoniques**, rejeu, T1–T6 |
| 11 | [Organisation backend/frontend](11-backend-frontend-organization.md) | Arborescence, conventions, routes, Simulation Room |
| 12 | [Contrats API et SSE](12-api-and-sse-contracts.md) | Endpoints, auth, jobs, SSE, erreurs |
| 13 | [Sécurité](13-security-testing-deployment.md) | Menaces, **comptes et sessions**, 15 tests de sécurité |
| 14 | [Plan d'implémentation](14-implementation-plan.md) | Vagues de livraison, calendrier, risques, agents Claude |
| 15 | [Décisions V1 à V26](15-decisions-to-validate.md) | **Tableau révisé**, risques non résolus, questions aux organisateurs |
| **16** | [Code de référence ITU et conformité](16-itu-reference-code-and-compliance.md) | Étude du dépôt, REQ de l'UIT, interprétations, matrice R/I/S |
| **17** | [Portabilité, environnements, CI](17-portability-environments-ci.md) | E1–E5, matrice OS, scripts, Docker/Podman, CI, sauvegarde |
| **18** | [Stratégie de validation](18-validation-strategy.md) | Marqueurs, 10 familles de tests, journal de validation généré |
| **19** | [Licences et SBOM](19-licenses-and-sbom.md) | Politique, logiciels, modèles, données, CycloneDX |
| ADR | [Décisions d'architecture](adr/README.md) | ADR-001 à 019 (008, 010-019 : révision) — **priment** sur les formulations antérieures |
| A1–A16 | [Annexes](appendix/) | Registres d'exigences, inventaire, recherches brutes, étude ITU, comparatifs, **journal de vérification (A16)** |

Diagrammes : Mermaid, **rendus avec l'outil officiel mermaid-cli** (résultat dans le document 00).
