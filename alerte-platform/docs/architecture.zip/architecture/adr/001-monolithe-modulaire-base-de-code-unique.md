# ADR-001 — Monolithe modulaire, base de code unique

- **Statut** : Révisée par 013
- **Date** : 2026-11-20
- **Références** : BP-08, BP-09

## Contexte
Dix modules aux frontières vérifiées par test ; pas de microservices.

## Décision
Une seule base de code, dix modules (core, workspaces, mandates, knowledge, agents, scenarios, simulation, audit, gaps, reports, evaluation) ; dépendances autorisées vérifiées par un test d'architecture.

## Conséquences
Maintenabilité par l'équipe ; frontières claires pour paralléliser ; la v2 autorise plusieurs **processus** du même code (ADR-013).
