# ADR-002 — Boucle d'agent maison, enveloppe d'action plate

- **Statut** : Maintenue
- **Date** : 2026-11-20
- **Références** : BP-31, BP-32, BP-33

## Contexte
Les petits et moyens modèles ouverts gèrent mal le tool-calling natif et les unions `oneOf`.

## Décision
Le backend contrôle la boucle (≤ 4 pas, 1 relance, repli consigné). Le modèle renvoie une enveloppe JSON **plate** (`action` + champs optionnels) ; l'union discriminée est validée côté serveur (Pydantic). Aucun framework d'agents.

## Conséquences
Déterminisme et audit ; validation par Pydantic ; coût : ~500 lignes à écrire. Fiabilité par modèle à mesurer (< 5 % d'échec).
