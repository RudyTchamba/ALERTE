# ADR-003 — Ledger = journal d'audit et source du flux SSE

- **Statut** : Révisée (curseur par exercice)
- **Date** : 2026-11-20
- **Références** : BP-04, BP-13, BP-34

## Contexte
Une seule source de vérité pour l'audit, le temps réel et le rejeu.

## Décision
`ledger_event` est lu par curseur sur `seq` **gap-free par exercice** (jamais un id auto-incrémenté global) ; `ledger_head` par exercice ; hash sur `canonical_bytes` stockés ; SSE par polling, `LISTEN/NOTIFY` seulement comme réveil.

## Conséquences
Pas de bus mémoire ; reprise par `Last-Event-ID` ; contention limitée à l'exercice.
