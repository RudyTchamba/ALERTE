# ADR-004 — Documents et versions en ajout seul ; snapshot par références

- **Statut** : Maintenue
- **Date** : 2026-11-20
- **Références** : BP-26

## Contexte
Reproductibilité d'un exercice malgré l'évolution des KB.

## Décision
`document_version` immuable ; `kb_version` = ensemble figé ; au lancement, la portée est matérialisée dans `exercise_scope_item`.

## Conséquences
Pas de copie des chunks ; l'ablation de corpus devient possible.
