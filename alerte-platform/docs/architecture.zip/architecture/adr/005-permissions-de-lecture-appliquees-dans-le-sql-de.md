# ADR-005 — Permissions de lecture appliquées dans le SQL de la recherche

- **Statut** : Renforcée
- **Date** : 2026-11-20
- **Références** : BP-23

## Contexte
L'agent ne doit pas pouvoir lire une base non autorisée en reformulant sa requête.

## Décision
`SearchScope` construit par le backend ; **jointure sur `exercise_scope_item`**, deny-by-default, pré-filtrage avant FTS et vecteurs ; test de propriété sur chaque adaptateur d'index.

## Conséquences
Aucun post-filtrage ; aucune identité fournie par le LLM.
