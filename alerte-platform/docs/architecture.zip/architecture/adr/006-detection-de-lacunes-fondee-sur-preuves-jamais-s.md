# ADR-006 — Détection de lacunes fondée sur preuves, jamais sur des lacunes attendues

- **Statut** : Révisée par 019
- **Date** : 2026-11-20
- **Références** : A7

## Contexte
Éviter la circularité.

## Décision
Registre de mandats validé + demandes de scénario + signaux observés + règles G ; fixtures privées ; revue humaine.

## Conséquences
Voir ADR-019 pour les garde-fous supplémentaires.
