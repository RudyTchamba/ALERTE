# ADR-007 — Fournisseurs de modèles : openai_compat, scripted, cassette

- **Statut** : Révisée par 017
- **Date** : 2026-11-20
- **Références** : BP-32

## Contexte
Tests déterministes sans prétendre valider l'IA.

## Décision
`openai_compat` (réel) ; `scripted` et `cassette` = outils de test/rejeu, **toujours étiquetés** (« SANS IA » / « REJEU »).

## Conséquences
Un jalon IA n'est validé qu'avec un vrai modèle (ADR-017).
