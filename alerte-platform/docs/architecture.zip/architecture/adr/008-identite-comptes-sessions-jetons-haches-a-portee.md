# ADR-008 — Identité : comptes, sessions, jetons hachés à portée

- **Statut** : **Remplace** la décision « jetons seuls »
- **Date** : 2026-11-21
- **Références** : BP-29, OWASP A01

## Contexte
Il faut distinguer propriétaire, facilitateur, participant, agent, observateur, auditeur, avec révocation.

## Décision
`app_user` (Argon2id) ; `auth_session` (SHA-256 du jeton, cookie HttpOnly SameSite=Lax, contrôle d'Origin) ; `workspace_member(role)` ; `access_token` (siège/observation/API) hachés, expirants, révocables, liens par fragment d'URL ; agents = principals non connectables ; port IdP pour OIDC.

## Conséquences
Évolution vers le multi-utilisateurs sans changer le modèle ; P1 : jetons d'API, rate-limit, RLS ; P2 : OIDC.
