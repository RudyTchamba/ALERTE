# ADR-009 — Rapports : versions immuables, MD canonique, PDF réel

- **Statut** : Révisée (PDF dès la première version)
- **Date** : 2026-11-21
- **Références** : BP-36

## Contexte
Rapports consultables, versionnés, téléchargeables en PDF/MD/JSON/CSV (XLSX).

## Décision
`report_version` immuable ; rendus dérivés ; **WeasyPrint** (cible) + **xhtml2pdf** (repli pur Python, testé 3 OS) derrière le port `PdfRenderer`.

## Conséquences
Dépendances Pango dans l'image ; gabarit CSS restreint pour le repli.
