# ADR-010 — Migrations Alembic dès le premier commit

- **Statut** : **Remplace** « au gel du modèle »
- **Date** : 2026-11-21
- **Références** : BP-11

## Contexte
Deux dialectes et trois OS : les migrations doivent être testées de zéro dès le début.

## Décision
Alembic (`render_as_batch` pour SQLite) ; `create_all` interdit hors tests ; CI : migrations de zéro sur SQLite et PostgreSQL.

## Conséquences
Friction initiale acceptée ; évite toute dérive de schéma.
