# ADR-011 — Base cible PostgreSQL 17/18 + pgvector ; SQLite en profil léger

- **Statut** : **Remplace** « SQLite seul »
- **Date** : 2026-11-21
- **Références** : A12, A16

## Contexte
Déploiement partagé, transactions, jobs, ledger, vecteurs et permissions dans un seul magasin.

## Décision
PostgreSQL = cible ; SQLite = profil `light` (dev, CI, repli) ; mêmes modèles SQLAlchemy ; code de dialecte confiné dans `db/dialect/` ; « fait = vert sur PG » ; `PRAGMA foreign_keys` à chaque connexion.

## Conséquences
Windows : pas de binaire pgvector officiel **connu [NV, à vérifier]** → profil `light` ou PG distant/WSL2/Podman. Parité suivie par tests de contrat.
