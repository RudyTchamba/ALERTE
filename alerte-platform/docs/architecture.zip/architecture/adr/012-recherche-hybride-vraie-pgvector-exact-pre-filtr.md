# ADR-012 — Recherche hybride vraie : pgvector exact pré-filtré, lexique natif, RRF

- **Statut** : **Remplace** « BM25/FTS5 par défaut, vecteurs en P1 »
- **Date** : 2026-11-21
- **Références** : BP-21, BP-23, A11

## Contexte
Les embeddings font partie du besoin fondamental et des exigences du hackathon.

## Décision
`Embedder` (BGE-M3 par défaut) ; `halfvec(1024)` ; scan exact filtré par la portée, **sans HNSW en P0** ; `search_text` normalisé (FR/AR) indexé par FTS5/`tsvector 'simple'` ; fusion RRF k=60 ; mode lexical seul = **dégradé et signalé** ; Qdrant = adaptateur optionnel P2 ; empreinte d'embedder complète.

## Conséquences
Aucune perte de rappel due à un index approximatif ; zéro fuite garanti par le pré-filtrage et vérifié par un test de propriété (à écrire) ; mesures indicatives sur le poste de dev personnel (20 k × 1024 : 170 ms ; 5 k filtrés : 45 ms), **à re-mesurer sur E2/E3** ; HNSW partiel seulement si > ~200 k chunks. Écart assumé avec A11 (qui recommandait Qdrant) : un seul magasin transactionnel.
