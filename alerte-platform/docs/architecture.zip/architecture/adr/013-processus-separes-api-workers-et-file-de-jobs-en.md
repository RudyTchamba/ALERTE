# ADR-013 — Processus séparés (api, workers) et file de jobs en base avec fencing

- **Statut** : **Remplace** « un processus, un thread par exercice »
- **Date** : 2026-11-21
- **Références** : BP-05, A12

## Contexte
Durabilité, reprise, concurrence, évolution.

## Décision
`api` ne lance jamais de simulation ; `worker` files `sim`/`doc`/`export` ; table `job` : `SKIP LOCKED` (PG) / `BEGIN IMMEDIATE` (SQLite), lease + `lease_token` (fencing) + heartbeat + timeout par étape ; `waiting_input` libère le lease ; `llm_call` avant l'appel (effectively-once) ; pas de Redis/Celery.

## Conséquences
Reprise par expiration de lease (signaux Windows non fiables) ; mode `light` : worker embarqué.
