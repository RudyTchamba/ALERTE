# ADR-014 — Isolation inter-espaces par clés étrangères composites

- **Statut** : Nouvelle
- **Date** : 2026-11-21
- **Références** : OWASP LLM02

## Contexte
Empêcher les références croisées entre espaces de travail au niveau de la base.

## Décision
`UNIQUE(workspace_id, id)` sur chaque parent ; FK composites `(workspace_id, x_id)` ; RLS PostgreSQL en P1 ; test d'insertion croisée sur les deux dialectes.

## Conséquences
Schéma plus verbeux ; sécurité garantie par la base.
