# ADR-015 — Portabilité Linux/Windows/macOS ; Docker/Podman optionnels ; CI 3 OS

- **Statut** : Nouvelle
- **Date** : 2026-11-21
- **Références** : A13

## Contexte
Clonable et exécutable proprement partout ; pas de dépendance à Docker Desktop.

## Décision
uv + `uv.lock`, Node 22 + `package-lock.json`, scripts Python (`doctor`, `setup`, `dev`), `pathlib`, UTF-8, `.gitattributes`, stockage par SHA-256 ; CI ubuntu/windows/macos + job PostgreSQL Linux + runner `gpu` auto-hébergé.

## Conséquences
PostgreSQL non testé en CI sous Windows/macOS (limite assumée).
