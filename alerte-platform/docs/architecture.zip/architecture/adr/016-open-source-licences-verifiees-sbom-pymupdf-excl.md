# ADR-016 — Open source, licences vérifiées, SBOM, PyMuPDF exclu

- **Statut** : Nouvelle
- **Date** : 2026-11-21
- **Références** : A14

## Contexte
Aucune dépendance propriétaire obligatoire ; publication sous licence permissive.

## Décision
Liste de licences autorisées ; CycloneDX en CI ; PyMuPDF (AGPL) remplacé par pypdfium2 + pdfplumber ; modèles par défaut Apache-2.0/MIT ; fichiers MODEL/DATA_LICENSES.

## Conséquences
Avis juridique nécessaire sur certains points (doc 19 §19.7).
