# ADR-017 — Validation multi-machines ; scripted/cassette non probants ; journal généré

- **Statut** : Nouvelle
- **Date** : 2026-11-21
- **Références** : doc 18

## Contexte
La puissance de la machine de dev n'est pas un critère de conception.

## Décision
Environnements E1–E5 ; marqueurs pytest (`model`, `gpu`, `postgres`, `restart`, …) ; un jalon IA est validé seulement après un test `model` sur E2/E4 ; `docs/validation-log.md` **généré** depuis JUnit + empreinte de configuration.

## Conséquences
Un E2 doit être désigné ; sans lui le jalon IA glisse.
