# ADR-018 — Intégration ITU : architecture fédérée souveraine, politique de partage par KB

- **Statut** : Nouvelle
- **Date** : 2026-11-21
- **Références** : doc 16

## Contexte
Le rapport AI Readiness est contradictoire sur local vs distribué et ne définit pas le format de record.

## Décision
`sharing_policy` par KB (`local_only` défaut) ; dérogation par document ; `kb_share_record` (qui/quand/cible/empreinte) ; endpoint de chaque appel enregistré ; adaptateur de records au format du dépôt d'exemple ; matrice de conformité R/I/S honnête.

## Conséquences
Aucune donnée n'est déplacée sans décision explicite ; modalités du Lab à confirmer.
