# ADR-019 — Garde-fous d'intégrité de la détection de lacunes (v2)

- **Statut** : Nouvelle
- **Date** : 2026-11-21
- **Références** : doc 09 §9.9

## Contexte
Renforcer la défense contre « c'est pré-programmé ».

## Décision
`basis_kind` des actions attendues ; pré-engagement (`commitment_sha256`) ; contrôle négatif (taux de faux positifs) ; `cause` institutionnelle/documentaire/artefact ; variance (≥ 3 runs) ; couverture documentaire ; scénarios indépendants rédigés par un tiers ; benchmark externe ; relecture aveugle (κ).

## Conséquences
Charge de validation humaine ; résultats chiffrés exigés (précision avec IC).
