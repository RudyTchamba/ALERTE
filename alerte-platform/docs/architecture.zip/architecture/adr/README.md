# Décisions d'architecture (ADR)

Format minimal (MADR allégé). **Les ADR 008, 010, 011, 012, 013 remplacent des décisions de la v1 ; les ADR 014 à 019 sont nouveaux. En cas de contradiction avec un document antérieur, l'ADR le plus récent prime** (révision du 2026-11-21).

| ADR | Décision | Statut | Date |
|---|---|---|---|
| [001](001-monolithe-modulaire-base-de-code-unique.md) | Monolithe modulaire, base de code unique | Révisée par 013 | 2026-11-20 |
| [002](002-boucle-d-agent-maison-enveloppe-d-action-plate.md) | Boucle d'agent maison, enveloppe d'action plate | Maintenue | 2026-11-20 |
| [003](003-ledger-journal-d-audit-et-source-du-flux-sse.md) | Ledger = journal d'audit et source du flux SSE | Révisée (curseur par exercice) | 2026-11-20 |
| [004](004-documents-et-versions-en-ajout-seul-snapshot-par.md) | Documents et versions en ajout seul ; snapshot par références | Maintenue | 2026-11-20 |
| [005](005-permissions-de-lecture-appliquees-dans-le-sql-de.md) | Permissions de lecture appliquées dans le SQL de la recherche | Renforcée | 2026-11-20 |
| [006](006-detection-de-lacunes-fondee-sur-preuves-jamais-s.md) | Détection de lacunes fondée sur preuves, jamais sur des lacunes attendues | Révisée par 019 | 2026-11-20 |
| [007](007-fournisseurs-de-modeles-openai-compat-scripted-c.md) | Fournisseurs de modèles : openai_compat, scripted, cassette | Révisée par 017 | 2026-11-20 |
| [008](008-identite-comptes-sessions-jetons-haches-a-portee.md) | Identité : comptes, sessions, jetons hachés à portée | **Remplace** la décision « jetons seuls » | 2026-11-21 |
| [009](009-rapports-versions-immuables-md-canonique-pdf-ree.md) | Rapports : versions immuables, MD canonique, PDF réel | Révisée (PDF dès la première version) | 2026-11-21 |
| [010](010-migrations-alembic-des-le-premier-commit.md) | Migrations Alembic dès le premier commit | **Remplace** « au gel du modèle » | 2026-11-21 |
| [011](011-base-cible-postgresql-17-18-pgvector-sqlite-en-p.md) | Base cible PostgreSQL 17/18 + pgvector ; SQLite en profil léger | **Remplace** « SQLite seul » | 2026-11-21 |
| [012](012-recherche-hybride-vraie-pgvector-exact-pre-filtr.md) | Recherche hybride vraie : pgvector exact pré-filtré, lexique natif, RRF | **Remplace** « BM25/FTS5 par défaut, vecteurs en P1 » | 2026-11-21 |
| [013](013-processus-separes-api-workers-et-file-de-jobs-en.md) | Processus séparés (api, workers) et file de jobs en base avec fencing | **Remplace** « un processus, un thread par exercice » | 2026-11-21 |
| [014](014-isolation-inter-espaces-par-cles-etrangeres-comp.md) | Isolation inter-espaces par clés étrangères composites | Nouvelle | 2026-11-21 |
| [015](015-portabilite-linux-windows-macos-docker-podman-op.md) | Portabilité Linux/Windows/macOS ; Docker/Podman optionnels ; CI 3 OS | Nouvelle | 2026-11-21 |
| [016](016-open-source-licences-verifiees-sbom-pymupdf-excl.md) | Open source, licences vérifiées, SBOM, PyMuPDF exclu | Nouvelle | 2026-11-21 |
| [017](017-validation-multi-machines-scripted-cassette-non.md) | Validation multi-machines ; scripted/cassette non probants ; journal généré | Nouvelle | 2026-11-21 |
| [018](018-integration-itu-architecture-federee-souveraine.md) | Intégration ITU : architecture fédérée souveraine, politique de partage par KB | Nouvelle | 2026-11-21 |
| [019](019-garde-fous-d-integrite-de-la-detection-de-lacune.md) | Garde-fous d'intégrité de la détection de lacunes (v2) | Nouvelle | 2026-11-21 |
