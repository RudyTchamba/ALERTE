> **Annexe — Recherche : file de jobs, PostgreSQL vs SQLite, processus.**
> Matériau de recherche brut produit le 2026-11-21 par un sous-agent (modèle Haiku 5.5), relu en partie par l'architecte. Les marqueurs « non vérifié » / `[NV]` / `[V]` / `[P]` / `[S]` / `[LU]` / `[SUPPOSÉ]` sont ceux du sous-agent. Pièce justificative, pas une spécification.

---

# 13 - Runtime, base de données et file de jobs (ALERTE)

Date de recherche : 2026-11-21.
Légende : **[V]** = page officielle lue directement ; **[P]** = partiel (extrait de recherche, dépôt ou page secondaire) ; **[NV]** = non vérifié (pas lu, ou lecture en échec).

## 1. Recommandation tranchée

| Sujet | Décision |
|---|---|
| Processus | 4 rôles, un même code : `api` (FastAPI/uvicorn, SSE), `worker` (`python -m app.worker --queues sim` ; moteur de simulation LLM), `worker` (`--queues doc`), `worker` (`--queues export`). Chaque rôle est une commande distincte, scalable indépendamment. Les workers ne sont jamais lancés depuis l'API. |
| File de jobs | **File maison** : table `job` + `SELECT … FOR UPDATE SKIP LOCKED` (PostgreSQL) + lease/heartbeat. Pas de Redis, RabbitMQ ni Celery. |
| Bibliothèque | Alternative acceptable : **Procrastinate** (MIT, PostgreSQL 13+). Écartée car elle gère son propre schéma (conflit avec Alembic), ne couvre pas le ledger ni la progression SSE, et son connecteur SQLAlchemy utilise psycopg2 et non psycopg 3. |
| Base cible | **PostgreSQL 17 ou 18** (version épinglée dans compose). Démo partagée et production : PostgreSQL uniquement. |
| Mode test léger | SQLite fichier en WAL, un seul hôte, une seule machine, un seul écrivain à la fois. Usage tests unitaires et dev solo uniquement. Pas de démo multi-utilisateurs ni de workers multiples écrivant en parallèle. |
| SSE | Le flux lit la table `job_event` avec un curseur `id > Last-Event-ID` (polling 1 s). `LISTEN/NOTIFY` peut servir uniquement de signal de réveil, jamais de source de vérité. |
| Ledger | Table `ledger_head` (une ligne par exercice) verrouillée `FOR UPDATE` dans la même transaction que l'insertion de `ledger_entry` ; triggers d'immuabilité. |
| Arrêt propre | Ne pas compter sur les signaux (voir section 3). Le mécanisme de reprise est la lease expirée, pas le signal. |

## 2. File de jobs : PostgreSQL et bibliothèques

### 2.1 Primitives PostgreSQL

| Élément | Statut | Source | Note |
|---|---|---|---|
| `FOR UPDATE SKIP LOCKED` : lignes verrouillées ignorées, « not suitable for general purpose work, but can be used to avoid lock contention with multiple consumers accessing a queue-like table » | [V] | https://www.postgresql.org/docs/current/sql-select.html | Version « current » de la doc vue : PostgreSQL 19 (annoncée sortie le 2026-11-19). |
| `NOWAIT` vs `SKIP LOCKED` ; si les deux sont mentionnés pour une table, NOWAIT prime | [V] | idem | |
| `SKIP LOCKED` interdit avec `FETCH … WITH TIES`, `GROUP BY`, `DISTINCT`, `UNION` | [V] | idem | |
| `NOTIFY` : charge utile < 8000 octets par défaut ; livraison au COMMIT de la transaction ; messages livrés dans l'ordre des commits | [V] | https://www.postgresql.org/docs/current/sql-notify.html | Consigne de la doc : mettre les grosses données en table et envoyer la clé. |
| `NOTIFY` perdu si personne n'écoute | [P] | idem (la doc ne le dit pas explicitement) | Traiter `NOTIFY` comme lossy : toujours un polling de secours. |
| Comportement de `NOTIFY` à la déconnexion du listener | [NV] | idem | Non documenté dans la page lue. |
| `pg_advisory_xact_lock` : verrou applicatif libéré au COMMIT/ROLLBACK | [NV] | https://www.postgresql.org/docs/current/functions-admin.html | Page en échec. Comportement attendu, à relire avant usage. |
| `gen_random_uuid()` natif | [NV] | doc PostgreSQL « functions-uuid » | Natif depuis PostgreSQL 13, de mémoire ; non relu. |

### 2.2 Bibliothèques

| Bibliothèque | Licence | Backend | Statut | Source | Verdict |
|---|---|---|---|---|---|
| **Procrastinate** | MIT | PostgreSQL 13+ | Python 3.11+ selon recherche (une ancienne page dit 3.10+). Connecteur async psycopg v3 pour worker ; connecteur SQLAlchemy = psycopg2, déférence seulement. Une page PyPI (2.3.0) indique « looking for additional maintainers » ; la dernière version vue est 2.14.1. | [P] https://procrastinate.readthedocs.io/en/stable/ ; https://pypi.org/project/procrastinate/ (extrait) | Option de repli. Trop couplée à son schéma pour notre cahier des charges. |
| **pgqueuer** | MIT | PostgreSQL seul (LISTEN/NOTIFY + SKIP LOCKED) | Dernière version rapportée : 1.0.1 (2026-05-18), via pepy.tech ; non confirmé sur PyPI. | [P] https://pypi.org/project/pgqueuer/ (extrait) | Candidat sérieux à évaluer ; moins mature en retour d'expérience vérifié. |
| Dramatiq | — | Redis / RabbitMQ | — | [NV] | Exclu (broker requis). |
| RQ | — | Redis | — | [NV] | Exclu (Redis). |
| Celery | — | broker requis | — | [NV] | Exclu (broker requis, hors cahier des charges). |
| arq | — | Redis | — | [NV] | Exclu. |
| taskiq | — | broker au choix | — | [NV] | Non évalué en détail. |
| Huey | — | Redis / SQLite | — | [NV] | Non lu. |
| River, Oban | — | non Python | — | — | Hors périmètre. |

Points à vérifier pour pgqueuer et Procrastinate avant tout choix : garanties réelles de reprise après lease expirée, support des timeouts par job, sémantique at-least-once (les deux sont at-least-once, à confirmer), et présence de la progression observable. Non lu directement.

### 2.3 Sémantique

- Exactly-once n'existe pas en pratique : viser **at-least-once + idempotence**. Chaque étape LLM écrit son résultat dans une table `sim_step (run_id, step_no)` avec contrainte UNIQUE ; un rejeu saute les étapes déjà présentes.
- Clés d'idempotence des jobs : `UNIQUE (kind, idempotency_key)` (voir schéma).

## 3. Processus et signaux

| Sujet | Statut | Source | Constat |
|---|---|---|---|
| Windows : `signal.signal()` n'accepte que SIGABRT, SIGFPE, SIGILL, SIGINT, SIGSEGV, SIGTERM, SIGBREAK ; autres → ValueError | [P] (extrait de recherche) | https://docs.python.org/3/library/signal.html | SIGTERM existe mais n'est pas émis par Windows à l'arrêt ; `Popen.terminate()` = arrêt forcé. |
| Windows : `Popen.send_signal(SIGTERM)` = alias de `terminate()` | [P] | https://docs.python.org/3.7/library/subprocess.html | Donc arrêt non gracieux. |
| `uvicorn` multi-workers vs processus séparés | [NV] | doc uvicorn | Non lu. Recommandation : API en 1 à N processus (état en base, donc sans problème) ; workers en processus séparés. |
| supervisord (non-Windows), honcho/Procfile, docker compose | [NV] | — | Non lu. Pour Windows : honcho ou simple script `start_all.py` à base de `subprocess`. |

Conséquences : au lancement, chaque worker enregistre son `worker_id` et sa lease ; à l'arrêt (Ctrl+C sur Windows = SIGINT ; Ctrl+Break = SIGBREAK), il libère ses jobs proprement si possible. Dans tous les cas, la récupération se fait par lease expirée, donc un arrêt brutal reste correct.

## 4. SQLite vs PostgreSQL

| Sujet | Statut | Source | Constat |
|---|---|---|---|
| WAL : un seul écrivain à la fois, lecteurs concurrents | [V] | https://sqlite.org/wal.html | |
| WAL sur système de fichiers réseau non supporté | [V] | idem | Interdit pour un partage entre machines. |
| WAL : plusieurs processus OK sur une même machine, tous les lecteurs sur la même machine | [V] | idem | |
| Checkpoint : auto vers ~1000 pages ; un lecteur long bloque la progression, le WAL grossit | [V] | idem | Surveiller la taille du WAL. |
| `BEGIN DEFERRED` (défaut) : upgrade en écriture peut échouer en SQLITE_BUSY | [V] | https://sqlite.org/lang_transaction.html | Pour un claim de job : utiliser `BEGIN IMMEDIATE`. |
| `BEGIN IMMEDIATE` : prend la transaction d'écriture tout de suite, peut échouer en SQLITE_BUSY | [V] | idem | `busy_timeout` obligatoire. |
| `BEGIN EXCLUSIVE` : hors WAL bloque les lectures ; en WAL = IMMEDIATE | [V] | idem | |
| SQLite et système de fichiers réseau (useovernet) | [NV] | https://sqlite.org/useovernet.html | Page en échec deux fois. Constat ci-dessus vient de wal.html. |
| `SELECT … FOR UPDATE SKIP LOCKED` sous SQLite | [NV] | — | Non disponible (de mémoire). Le claim doit passer par `BEGIN IMMEDIATE`. |
| Séquence sans trou par exercice | — | — | Sous SQLite : tout écrivain est sérialisé, donc `seq = max+1` dans une transaction `BEGIN IMMEDIATE` est sûr sur une machine. Sous PostgreSQL : `SELECT … FOR UPDATE` sur `ledger_head`. |
| `pg_advisory_xact_lock` | [NV] | doc PostgreSQL | Alternative au verrou de ligne si la ligne `ledger_head` n'existe pas encore (pré-insérer la ligne à la création de l'exercice). |
| JSONB, FTS, pgvector | [NV] | — | Non lus. Non nécessaires au cahier des charges immédiat. |
| Sauvegardes : `pg_dump` ; `sqlite3 .backup` | [NV] | — | Non lus. |

**Triggers d'immuabilité** : PostgreSQL = fonction `RAISE EXCEPTION` en `BEFORE UPDATE OR DELETE`. SQLite = `CREATE TRIGGER … BEFORE UPDATE … BEGIN SELECT RAISE(ABORT, '…'); END;` [NV, syntaxe de mémoire, non relue].

## 5. SQLAlchemy 2.0, psycopg, asyncpg, Alembic

| Sujet | Statut | Source | Constat |
|---|---|---|---|
| `Select.with_for_update(skip_locked=True, nowait=…, read=…, of=…, key_share=…)` : rendu `FOR UPDATE SKIP LOCKED` sur PostgreSQL et Oracle ; `FOR SHARE SKIP LOCKED` si `read=True` | [P] (extrait) | https://docs.sqlalchemy.org/en/20/core/selectable.html | Même signature sur `Query.with_for_update()` et `Session.get/refresh`. |
| Support SQLite de `with_for_update` | [NV] | — | Ignoré ou non émis selon le dialecte ; ne pas s'y fier. |
| Types JSON/JSONB, UUID portables | [NV] | doc SQLAlchemy « types » | Non lu. Prévoir un `TypeDecorator` (JSON générique, JSONB sur PostgreSQL) et `Uuid` (SQLAlchemy 2.0). |
| psycopg 3 : licence | [P] | https://github.com/psycopg/psycopg | **LGPL-3.0** (libellé du dépôt ; texte du LICENSE non lu). Usage en dépendance Python : compatible avec un projet MIT/propriétaire, sous réserve de la LGPL (liaison dynamique via pip, pas de modification du code). À faire valider par juridique. |
| psycopg 3 : versions Python | [NV] | https://www.psycopg.org/psycopg3/docs/basic/install.html | Page en échec. |
| asyncpg : Apache-2.0 | [NV] | — | Non lu. |
| Alembic multi-dialectes | [NV] | — | Non lu. Recommandation : migrations écrites avec `op.*` génériques ; blocs spécifiques PostgreSQL (triggers, `SKIP LOCKED`) conditionnés par `op.get_bind().dialect.name`. |

## 6. Schéma SQL minimal (PostgreSQL)

Schéma indicatif, à relire avant migration Alembic.

```sql
CREATE TABLE job (
  id               uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  queue            text        NOT NULL,              -- 'sim' | 'doc' | 'export'
  kind             text        NOT NULL,              -- type de tâche
  payload          jsonb       NOT NULL DEFAULT '{}'::jsonb,
  status           text        NOT NULL DEFAULT 'queued'
                   CHECK (status IN ('queued','running','succeeded','failed','dead','cancelled')),
  priority         int         NOT NULL DEFAULT 0,
  run_at           timestamptz NOT NULL DEFAULT now(),
  attempts         int         NOT NULL DEFAULT 0,
  max_attempts     int         NOT NULL DEFAULT 5,
  timeout_s        int         NOT NULL DEFAULT 3600,
  locked_by        text,                               -- id du worker
  lease_expires_at timestamptz,
  heartbeat_at     timestamptz,
  progress         jsonb       NOT NULL DEFAULT '{}'::jsonb,
  result           jsonb,
  last_error       text,
  idempotency_key  text,
  version          int         NOT NULL DEFAULT 0,     -- verrou optimiste pour les écritures d'état
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX job_idem  ON job (kind, idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX        job_claim ON job (queue, priority DESC, run_at) WHERE status = 'queued';
CREATE INDEX        job_lease ON job (lease_expires_at)         WHERE status = 'running';

CREATE TABLE job_event (                               -- source du flux SSE
  id         bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  job_id     uuid        NOT NULL REFERENCES job(id),
  kind       text        NOT NULL,                     -- 'state' | 'progress' | 'log'
  data       jsonb       NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX job_event_job ON job_event (job_id, id);
```

**Claim** (un worker, une requête, pas de double prise) :

```sql
WITH c AS (
  SELECT id FROM job
  WHERE queue = :queue AND status = 'queued' AND run_at <= now()
  ORDER BY priority DESC, run_at
  LIMIT 1
  FOR UPDATE SKIP LOCKED
)
UPDATE job j
SET status = 'running', attempts = j.attempts + 1, locked_by = :worker,
    lease_expires_at = now() + make_interval(secs => :lease_s),
    heartbeat_at = now(), updated_at = now(), version = j.version + 1
FROM c WHERE j.id = c.id
RETURNING j.*;
```

**Heartbeat** : `UPDATE job SET lease_expires_at = now() + …, heartbeat_at = now() WHERE id = :id AND locked_by = :worker AND status = 'running';` Si 0 ligne : le job a été repris, le worker s'arrête.

**Récupération** (exécuté périodiquement par chaque worker ; idempotent) :

```sql
UPDATE job
SET status = CASE WHEN attempts < max_attempts THEN 'queued' ELSE 'dead' END,
    locked_by = NULL, lease_expires_at = NULL,
    last_error = COALESCE(last_error, '') || ' [lease expirée]',
    updated_at = now(), version = version + 1
WHERE id IN (
  SELECT id FROM job
  WHERE status = 'running' AND lease_expires_at < now()
  FOR UPDATE SKIP LOCKED
);
```

Le timeout par job est appliqué côté worker (`timeout_s` comparé à `now() - claim_at`) ; la lease couvre la panne du processus.

## 7. Ledger d'audit (chaîne de hachage, séquence sans trou)

```sql
CREATE TABLE ledger_head (
  exercice  text    PRIMARY KEY,
  last_seq  bigint  NOT NULL DEFAULT 0,
  last_hash bytea   NOT NULL
);
CREATE TABLE ledger_entry (
  exercice  text    NOT NULL,
  seq       bigint  NOT NULL,
  prev_hash bytea   NOT NULL,
  hash      bytea   NOT NULL,
  payload   jsonb   NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (exercice, seq)
);
```

Écriture : dans une transaction, `SELECT last_seq, last_hash FROM ledger_head WHERE exercice = :e FOR UPDATE`, puis insertion avec `seq = last_seq + 1`, `prev_hash = last_hash`, puis `UPDATE ledger_head`. Le verrou sérialise les écrivains multi-processus. Sans lecture de `ledger_head` avant le verrou, deux processus peuvent produire le même `seq` : la clé primaire le bloque, mais la transaction doit alors être rejouée.

## 8. Dev sans Docker, CI, Podman

| Sujet | Statut | Source | Constat |
|---|---|---|---|
| GitHub Actions : service containers (`services:`) exigent un runner Linux (Ubuntu pour les hébergés) | [V] | https://docs.github.com/en/actions/using-containerized-services/about-service-containers | Donc PostgreSQL en service seulement sur `ubuntu-latest`. |
| PostgreSQL sur `windows-latest` / `macos-latest` en CI | [NV] | — | Installer via choco / brew ; non vérifié. |
| Installateurs officiels PostgreSQL (Windows, macOS, Linux) | [NV] | https://www.postgresql.org/download/windows/ | Page en échec. |
| `pgserver`, `postgresql-wheel`, `testing.postgresql`, Testcontainers, embedded-postgres : licences et maturité | [NV] | — | Non lus. Ne pas retenir sans lecture. |
| Podman : `podman compose` est un projet communautaire, sous-ensemble de Docker Compose | [P] | https://www.redhat.com/en/blog/podman-compose-docker-compose | Éviter les fonctionnalités avancées (pods, secrets) ; tester le fichier compose sous Podman avant de s'y fier. |
| Podman : API compatible Docker, `docker compose` possible via socket Podman rootless + `DOCKER_HOST` | [P] | recherche (billet communautaire) | Non confirmé par doc officielle. |
| Podman : mode rootless par défaut | [P] | tutoriel DataCamp | Non confirmé par doc officielle. |

Compose : un seul `docker-compose.yml` avec service `postgres` (image épinglée), `api`, `worker-sim`, `worker-doc`, `worker-export`, un `Dockerfile` commun. Dev sans Docker : PostgreSQL local installé, ou SQLite en mode léger.

## 9. Points non lus (à traiter avant de figer)

1. Pages en échec (2 tentatives chacune) : sqlite.org/useovernet.html ; procrastinate.readthedocs.io (lecture directe) ; pypi.org/project/pgqueuer ; docs SQLAlchemy `orm/queryguide/select` ; postgresql.org `explicit-locking` et `functions-admin` (advisory locks) ; docs.python.org signal (lu via recherche seulement) ; postgresql.org download.
2. Non lus : asyncpg (licence), Alembic multi-dialectes, uvicorn multi-workers, SSE (limites de connexions par navigateur HTTP/1.1, proxies), honcho, supervisord, Testcontainers, pgserver, embedded-postgres, Huey, taskiq, Dramatiq, RQ, Celery (détails).
3. Contradiction : Procrastinate indique Python 3.11+ (recherche) et 3.10+ (ancienne page) ; version « 2.14.1 » vue dans les résultats mais page 2.3.0 indique « looking for maintainers ». Statut de maintenance à revérifier sur GitHub.
4. `NOTIFY` sans écouteur ou déconnexion : comportement non explicite dans la doc lue.
5. Licence psycopg : LGPL-3.0 d'après le libellé GitHub, texte LICENSE non lu.

## Sources

- https://www.postgresql.org/docs/current/sql-select.html [V]
- https://www.postgresql.org/docs/current/sql-notify.html [V]
- https://sqlite.org/wal.html [V]
- https://sqlite.org/lang_transaction.html [V]
- https://docs.sqlalchemy.org/en/20/core/selectable.html [P]
- https://github.com/psycopg/psycopg [P]
- https://procrastinate.readthedocs.io/en/stable/ [P]
- https://pypi.org/project/pgqueuer/ [P]
- https://docs.python.org/3/library/signal.html [P]
- https://docs.python.org/3.7/library/subprocess.html [P]
- https://docs.github.com/en/actions/using-containerized-services/about-service-containers [V]
- https://www.redhat.com/en/blog/podman-compose-docker-compose [P]
