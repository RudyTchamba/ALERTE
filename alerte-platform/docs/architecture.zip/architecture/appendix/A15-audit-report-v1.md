> **Annexe — Rapport d'audit indépendant de la première version du dossier (corrections appliquées dans la v2).**
> Matériau de recherche brut produit le 2026-11-21 par un sous-agent (modèle Haiku 5.5), relu en partie par l'architecte. Les marqueurs « non vérifié » / `[NV]` / `[V]` / `[P]` / `[S]` / `[LU]` / `[SUPPOSÉ]` sont ceux du sous-agent. Pièce justificative, pas une spécification.

---

# Rapport d'audit indépendant : dossier d'architecture ALERTE

Périmètre : `/home/rtti/Documents/Github/ALERTE-for-ITUAIReadiness/alerte-platform/docs/architecture/` (README.md, 01 à 15, appendix/A1 à A8). Lecture seule. Aucun fichier du dépôt modifié. Les références `NN-xxx.md:L` sont relatives à ce dossier ; `appendix/` est noté `A*`. Date de revue : 2026-11-20.

---

## 1. Liens

- **Aucun lien relatif cassé.** 22 liens relatifs vérifiés : README vers 01 à 15 et `appendix/` ; 02 vers A1, A2, 09 ; 03 vers A7 ; 07 vers A5 ; 09 vers A7 ; 13 vers A6 ; 14 vers 15. Toutes les cibles existent.
- Références internes du type « doc NN §x.y » : toutes les sections citées existent.
- **Mineur** : `README.md:37` pointe vers le dossier `appendix/` et non vers les fichiers A1 à A8 ; préférer une liste explicite.
- Non vérifiées : 225 URL externes (pas d'accès réseau). Des URL sont marquées « illisible » ou « [NV] » dans les annexes ; c'est traité au point 4.

## 2. Cohérence des priorités P0/P1/P2

### Bloquant

- **B1. Hash de tête non reproductible, contrairement au rejeu et au golden test.** `10-audit-and-evaluation.md:43` : `canon(e)` inclut `exercise_id`, `real_time`, `seat_id`, `payload`. Or `payload` de `LLM_CALL` contient `ms` (durée, L27), et `exercise_id` est un ULID/UUIDv7 (`06-data-model.md:3`), donc différent à chaque re-run ; `genesis` dépend de `exercise_id` (L44). Cela contredit : `02-requirements-and-arbitration.md:74` (FR-42, « même hash de tête après rejeu »), `08-agents-and-simulation.md:151` (cassette : « reproduit le même hash de tête »), `10-audit-and-evaluation.md:71`, `13-security-testing-deployment.md:43` (golden bloquant), `11-backend-frontend-organization.md:138`.
  Correction : sortir du canon les champs non déterministes (`real_time`, `ms`, latences, identifiants temporels) ou les stocker hors chaîne ; définir un hash de rejeu sur `seq`, `type`, `payload` déterministe ; comparer par `payload_sha256` plutôt que par l'identifiant d'exercice.

- **B2. Critère P0 conditionné à un modèle réel que le plan dit possiblement indisponible.** `14-implementation-plan.md:13` (P0 : « au moins un run réel enregistré en cassette ») et `:27` (mer. 25 : « run réel enregistré ») ; `14-implementation-plan.md:104` (R1 : repli « exercice enregistré sur Sandbox jeudi ») ; `15-decisions-to-validate.md:15` (V7 : « premier vrai test sur Sandbox jeudi » si non tranché). `13-security-testing-deployment.md:69` exige des étapes « avec un modèle réel » avant validation. Le jalon M1 est donc incompatible avec son propre repli.
  Correction : trancher V7 ce soir, ou redéfinir le critère P0 (cassette produite à partir d'un modèle de test, ou run `scripted` explicitement étiqueté « SANS IA »), et l'écrire dans 14 §14.2 et 13 §13.3.

### Majeur

- **M1. G1–G10 et T3/T4 : P0 contradictoire.** `03-hackathon-conformance.md:24` (C3, P0, « Module Gap Analysis (G1–G10 + catégories) », preuves « T3, T4 ») contredit `02-requirements-and-arbitration.md:84` (FR-50 : P0 = G1, G2, G3, G8 ; P1 = G4–G7, G9, G10), `09-gap-analysis-and-reports.md:75`, `14-implementation-plan.md:13-14`, `14-implementation-plan.md:118` (« limitée à 4 règles en P0 »). T3 et T4 sont P1 (`10-audit-and-evaluation.md:82-83`, `02-requirements-and-arbitration.md:98`). Idem C1 (`03:22`) qui cite T1 (P1).
  Correction : ramener C3 à « G1, G2, G3, G8 en P0 » et déplacer T3/T4 dans la colonne P1.

- **M2. Priorités internes de 09 incohérentes.** `09-gap-analysis-and-reports.md:40` : ORPHAN_REQUEST « P0 (signal) » ; `:47` : mêmes signaux « P1 ». `:45` : G8 décrit comme « traçabilité/validité IA », P2 ; `:51` et `:67` : G8 = « AI oversight gap », P0. `:48` : G2, G7, G6 en « P0/P1 » alors que G6 et G7 sont P1 (`:75`). `:52` : G9 en « P0/P1 » alors que G9 est P1 (`:75`).
  Correction : une étiquette P par règle et par signal, la même dans les tableaux §9.2 et §9.3.

- **M3. Signature Ed25519 présentée comme contrôle en vigueur.** `13-security-testing-deployment.md:20` (« Falsification du ledger : chaîne + ancres + export de tête signé ») ne porte pas de mention P1, alors que `10-audit-and-evaluation.md:61` (ancre signée = P1), `02-requirements-and-arbitration.md:73` (FR-41 : signature = P1), `05-architecture-overview.md:140` (P1) et `14-implementation-plan.md:14` (P1) le placent en P1. Le même point en P0 est déjà affirmé dans `04-best-practices-registry.md:60` (BP-34 sans P).
  Correction : mentionner « P1 » dans 13 L20 et BP-34, ou ne citer en P0 que la tête exportée non signée.

- **M4. Alembic : trois positions.** `14-implementation-plan.md:14` (P1 « Alembic baseline ») ; `:26` (mar. 24, dans le plan P0 : « Alembic baseline ») ; `13-security-testing-deployment.md:123` (`alembic upgrade head` au démarrage, sans condition de gel). `05-architecture-overview.md:127` et `:170` disent « au gel du modèle ». `14-implementation-plan.md:118` dit « repoussé au gel ».
  Correction : une seule règle (gel du modèle, mar. 24, P1) reprise dans 13 §13.4.

- **M5. Jetons d'accès dans l'URL, contrairement à la règle « jamais de jeton dans les logs ».** `12-api-and-sse-contracts.md:11` et `:155` (`?stream_token=`) ; `08-agents-and-simulation.md:292` et `:301` (`/play/{token}`, jeton `player` de longue durée) ; `11-backend-frontend-organization.md:84-85` (`/play/:seatToken`, `/watch/:token`) ; `04-best-practices-registry.md:33` (BP-17 : jeton en paramètre d'URL). `13-security-testing-deployment.md:31` affirme : « jamais de jeton ... dans les logs applicatifs ». Les journaux d'accès du serveur, l'historique du navigateur et l'en-tête Referer exposent ces URL.
  Correction : jeton de siège ou d'observateur en en-tête ou en cookie `HttpOnly`/`SameSite=Strict` (pour SSE aussi) ; ou masquer les segments de chemin dans les logs ; ajouter un test dans 13 §13.3.

- **M6. Repli après JSON invalide : deux résultats contraires.** `08-agents-and-simulation.md:117` : fallback `decide{outcome: refer}` marqué `author=fallback`, une décision est donc enregistrée. `06-data-model.md:517` : `not_recorded` = « JSON invalide deux fois », sans décision. `author` n'existe pas dans `DECISION` (`06:455-471`).
  Correction : choisir l'un des deux comportements ; ajouter `author` au modèle s'il est retenu.

- **M7. Modèle DECISION incomplet par rapport aux contrats.** `08-agents-and-simulation.md:55` et `10-audit-and-evaluation.md:30` : `legal_basis[]` est dans la décision ; `06-data-model.md:455-471` n'a pas de colonne `legal_basis` (les citations sont dans `DECISION_CITATION`, `:472-481`). `08:57` : `options_considered` ; `06:465` : `options`.
  Correction : aligner les noms et dire que `legal_basis` est reconstruit à partir de `DECISION_CITATION`.

- **M8. Clé de fixture T3 : deux noms.** `10-audit-and-evaluation.md:82` (T3 : « par `fingerprint` ») ; `06-data-model.md:352` : `eval_fixture.expected_gap_key`. Aucun des deux n'est défini dans le texte de 09.
  Correction : retenir `expected_gap_key` et définir son calcul = `fingerprint` ; ou l'inverse.

- **M9. Suppression de document : UPDATE interdit et autorisé.** `06-data-model.md:244` : « Supprimer un document marque la version `retired` » (un UPDATE) ; `:728` : pas d'UPDATE/DELETE applicatif sur `document_version` ; `12-api-and-sse-contracts.md:44` : `DELETE /documents/{id}` (version `retired`).
  Correction : ajouter `document_version.status` aux exceptions de §6.5, ou passer par une table d'événements de cycle de vie.

- **M10. Définition FTS5 non exécutable.** `06-data-model.md:249` : `chunk_fts(text, title, article, content='chunk')`, mais `CHUNK` (`:180-196`) n'a pas de colonne `title` (elle est dans `DOCUMENT`). Une table FTS5 en contenu externe échouera au rebuild.
  Correction : dénormaliser `title` dans `CHUNK` ou retirer `content=` et gérer l'index à la main.

- **M11. « Fichier externe » qui se trouve sur le même volume.** `10-audit-and-evaluation.md:53` : ancres dans « fichier externe `data/anchors/<exercise>.jsonl` ». `13-security-testing-deployment.md:83` et `:93` : `anchors` est dans le même volume `/data` que la base. Un administrateur contrôle donc les deux. La limite est bien écrite à `10:62` et `:64`, mais le mot « externe » est exagéré à `:53`.
  Correction : écrire « fichier d'ancre sur le même volume (non externe) » ; réserver « externe » à la tête signée exportée hors serveur (P1).

- **M12. Affirmations de preuve sur-vendues pour le jury.** `01-vision-and-scope.md:114` : le test contrefactuel est « la preuve que les lacunes ne sont pas pré-écrites ». `09-gap-analysis-and-reports.md:165` : « les lacunes émergent des documents ». Or `09:154` (garde-fou 2) admet que le registre curé rend toute absence « lacune par construction », et `09:156` que la démo `scripted` pré-écrit les lacunes.
  Correction : « le test montre que la lacune dépend du corpus ; il ne prouve pas l'absence de pré-écriture, le registre et le scénario étant curés ».

- **M13. Nœuds Y.3172 présentés comme vérifiés.** `03-hackathon-conformance.md:39` : « Spec L712-723, vérifié dans A1 §H ». Le tableau `:45-54` attribue les 10 nœuds à Y.3172. `appendix/A7-research-hackathon-and-methods.md:155` : contenu du PDF Y.3172 « [NV] » ; `:154` : « Le sandbox ML n'est pas dans Y.3172 » (sous-agent, non vérifié). `04-best-practices-registry.md:69` (BP-38) reprend « sandbox » comme nœud Y.3172.
  Correction : attribuer la liste à la Spec (L712-723) et écrire « nœud sandbox : attribué par la Spec, non vérifié dans Y.3172 ».

- **M14. Fichiers annoncés comme présents qui n'existent pas.** `13-security-testing-deployment.md:115` : « Le dépôt contient `deploy/sandbox/README.md` ... et `deploy/vllm.sh` ». `10-audit-and-evaluation.md:74` : « script `verify_ledger.py` ... fourni dans le dépôt ». Dans `alerte-platform/`, seul `docs/` existe.
  Correction : « sera fourni » ou « à créer ».

- **M15. EW4All : « piloté par l'ITU » sur une source non lue.** `09-gap-analysis-and-reports.md:113` et `04-best-practices-registry.md:68` (BP-37, marqué [P]). `A7-research-hackathon-and-methods.md:200` : niveau [S] (extrait de moteur de recherche). Le lien ITU repose sur le flyer GL-10, absent du corpus (`A3-inventory-and-gap-reports.md:189`).
  Correction : passer à [S] dans BP-37 ; ne pas présenter le pilier 3 comme acquis tant que la source n'est pas lue.

- **M16. Diagramme de Gantt invalide.** `14-implementation-plan.md:58` : `Sandbox : vrais runs, embeddings :s1, ...`. Le deux-points du libellé est lu comme séparateur ; le rendu échouera ou décalera la tâche.
  Correction : remplacer par « Sandbox - vrais runs, embeddings ».

### Mineur

- m1. `15-decisions-to-validate.md:47` : la colonne « Vérifié (lu directement) » contient des vérifications faites par sous-agents (« via sous-agents », « via sous-agent »). Renommer la colonne.
- m2. `03-hackathon-conformance.md:58` : « Les cinq volets de base lus » ; `A7:159` n'indique que le sommaire lu.
- m3. `03:15` et `15:31` : la liste retenue a été annoncée le 18 nov. (`A7:103`, date passée) ; l'obligation de vidéo est peut-être déjà en vigueur. Non signalé.
- m4. `14-implementation-plan.md:104` : « 5-8 tok/s », « plus d'une minute par appel » sont présentés comme faits ; `:118` dit « non mesurées ».
- m5. `05-architecture-overview.md:131` : BGE-M3 « multilingue FR/EN/AR » ; `A5:136`, `:147`, `:157` : qualité arabe non mesurée [NV].
- m6. `05-architecture-overview.md:139` (React 19, Vite 8) et `11-backend-frontend-organization.md:121` (openapi-typescript) : versions et outil présentés comme retenus ; `15:47` et `04:35` (BP-19 [NV]) les disent non vérifiés.
- m7. `14-implementation-plan.md:86` : Haiku 0,10 $/0,50 $ ; `A8:122` ajoute le palier 0,50 $/2,50 $ au-delà de 100K tokens (omis).
- m8. Renvois faux : `08-agents-and-simulation.md:153` et `05-architecture-overview.md:151` citent « décision V12 ». V12 (`15:25`) concerne les statuts de lacunes ; le bon renvoi est V7 (`15:15`).
- m9. Statuts de lacune : `09-gap-analysis-and-reports.md:98` ajoute `reopened` ; `:128` réouvre vers `proposed` ; `06-data-model.md:715` n'a pas `reopened`. `02-requirements-and-arbitration.md:107` (D-06) décrit la confiance comme « texte confirmé/suspecté », alors que `06:715` et `09:96` utilisent high/medium/low.
- m10. `10-audit-and-evaluation.md:22` : `ai_mode` dans SNAPSHOT, valeurs `ai | scripted | cassette` ; `08:150` le place dans STATE ; `13:94` donne `openai_compat`.
- m11. `10-audit-and-evaluation.md:22` : SNAPSHOT contient `kb_versions` ; `06:374` : `document_version_ids`.
- m12. `02-requirements-and-arbitration.md:72` (FR-40, 10 types) omet SNAPSHOT, présent en `10:22` et `12:160`. `08-agents-and-simulation.md:117` utilise `LLM_OUTAGE`, absent du catalogue (`10:16-36`).
- m13. `08-agents-and-simulation.md:309` : `POST /seats/{id}/decision` ; `12-api-and-sse-contracts.md:86` : `POST /seats/me/decision`.
- m14. `06-data-model.md:157` : `reliability` inclut `unofficial` ; `02:29` (FR-12) : officiel/résumé/non trouvé.
- m15. Tables citées mais absentes de l'ERD 06 : `gap_rule` (`09:56`, `02:123`), `import_map` (`07:180`). `exercise.snapshot` (`03:45`) n'est pas un attribut (`06` : `EXERCISE_SNAPSHOT`).
- m16. `07-knowledge-and-rag.md:205` : « indexés le 2026-11-11 » n'apparaît pas dans A3. La liste des corrections omet CM-14 et CM-17 (`A3:177`, `:226`, `:284`) ; CM-17 est un document de la Banque mondiale, pertinent pour l'export « ouvert ». Même omission en `15:38`.
- m17. `12-api-and-sse-contracts.md:116`, `:118`, `:120` : XLSX (P2), import de rapports (P1) et scorecard (P1) sont dans le contrat gelé samedi (`14:22`) sans étiquette de priorité.
- m18. `11-backend-frontend-organization.md:125` (FR « exigé par la spec », P1) et `:127` (téléphone « (spec) ») : hors liste P0 de `14:13` et des coupes `14:79`.
- m19. `13-security-testing-deployment.md:105` : `ALERTE_BOOTSTRAP_ENABLED` vaut `true` par défaut ; `12:26` ouvre `POST /workspaces` sans restriction. Défaut à `false` recommandé.
- m20. Seuil d'appels : `13:99` (défaut `ALERTE_MAX_LLM_CALLS = 200`) contre `10:85` et `02:98` (T6 : « < 200 appels ») ; un run qui atteint 200 appels échoue T6. Mettre le défaut à 199 ou le seuil à « ≤ 200 ».
- m21. `08-agents-and-simulation.md:298-301` : alias de participant `/play/{token}` contenant des accolades ; à vérifier au rendu.
- m22. XLSX et PDF apparaissent comme sorties sans priorité : `01-vision-and-scope.md:39`, `README.md:15`.

## 3. Cohérence des noms (doc 06 vs 07, 08, 09, 10, 12)

| Élément | Verdict |
|---|---|
| `gap_review` | Cohérent (06, 09, 10, 12). |
| `ledger_anchor` / `LEDGER_ANCHOR` | Cohérent (06, 10, 08). |
| `negative_search` / `NEGATIVE_SEARCH` | Cohérent (06, 07, 09). |
| `exercise_snapshot` | Cohérent comme entité (06 `EXERCISE_SNAPSHOT`). Décalage avec `kb_versions` (10:22) et `exercise.snapshot` (03:45). Voir m11. |
| `kb_version` | Cohérent (06, 07, 09, 12). |
| `decision.status` | 06:517 : `recorded \| not_verified \| not_recorded`. 08:110 et 12:174 n'utilisent que les deux premières valeurs. Voir M6. |
| `decision.outcome` | Cohérent : `act \| decline \| refer \| no_legal_basis_found` (06, 08, 12). |
| `visibility` | 06:515 : `public \| board \| seat \| audit`. 08:322-327 écrit `seat:<id>`. Mineur. |
| Types d'événements | 15 types cohérents entre 10:16-36 et 12:160. Écarts : `LLM_OUTAGE` (08:117), SNAPSHOT absent de FR-40 (02:72). Voir m12. |
| Validation des mandats et `kind` | Cohérent : 06:109-110 couvre toutes les valeurs utilisées par 09:58-69. |
| `gap.validation_status` | 06:715 (4 valeurs) ; `reopened` (09:98) ; voir m9. |
| `evidence_basis`, `reality_label`, `command.kind`, `reply_status` | Cohérents. |
| `legal_basis`, `options_considered`, `author` | Absents ou différents dans 06. Voir M7 et M6. |
| `fingerprint` / `expected_gap_key` | Voir M8. |
| `gap_rule`, `import_map` | Absents de l'ERD. Voir m15. |
| Chunk `title` (FTS5) | Voir M10. |
| `document.reliability` | Voir m14. |

## 4. Exactitude des citations (12 affirmations vérifiées)

| # | Affirmation (fichier:ligne) | Source annexe | Verdict |
|---|---|---|---|
| 1 | FAQ « Accuracy of the AI Prototype does not fall under any evaluation criteria » (03:9) | A7:37 | Fidèle. |
| 2 | Critères C1–C5 en verbatim (03:22–26) | A7:28–35 | Fidèles. |
| 3 | Dates finale 8 déc. (page) / 9 déc. (fiche) (03:2) | A7:104–108 | Fidèle. |
| 4 | Vidéo 7 min, obligatoire si retenue (03:15) | A7:90 | Fidèle, mais le statut de la liste retenue (18 nov., passée) n'est pas signalé (m3). |
| 5 | Y.3172 « In force », 06/2019 (03:41) | A7:152 | Fidèle (statut seulement). |
| 6 | Dix nœuds Y.3172 et « vérifié dans A1 §H » (03:39–54) | A1:461, A7:154–155 | **Surévalué** : le contenu Y.3172 est [NV]. Voir M13. |
| 7 | « Cinq volets de base lus » (03:58) | A7:159 | **Surévalué** : sommaire lu seulement. Voir m2. |
| 8 | Liste OWASP LLM01–LLM10 2026, mappage LLM03/04/05/08 (13:9–21, 04:54) | A6:20, :26–34 | Fidèle. |
| 9 | Seuils T1–T6 (10:80–85, 02:98) | A1:485–494, SP-201 à SP-210 | Fidèles (T1 40 questions, 32/40 ; T2 95 %, etc.). Le seuil T6 et le budget de 200 appels divergent (m20). |
| 10 | 45 documents, AE-04 = charte IA, 141 pages à relire (15:37–38, 14:108, 07:205) | A3:48, :118, :129, :196 | Fidèle. 15:38 et 07:205 omettent CM-14 et CM-17 (m16). |
| 11 | IDs et prix des modèles : Opus 4/20, Sonnet 2/10, Haiku 0,10/0,50 (14:83–88) | A8:117–122 | Fidèle, palier Haiku omis (m7). |
| 12 | « JEV » introuvable (14:88) ; `--advisor` existe (14:87) | A8:69, :107, :209 | Fidèle. Mais 15:47 range `--advisor` dans « Vérifié (lu directement) » alors que l'annexe dit « non vérifié pour la version installée » (14:87). Voir m1. |

Autres points contrôlés : 12 divergences du rapport v2 (03:33, A3:44–56) fidèles ; 31 lignes de mandats (09:141, 15:36 ; A3:241 : 17 + 14) fidèles ; 321 exigences SP (A1) et 209 SI (A2, « ≈200 ») fidèles ; 47 divergences D-xx (A2) fidèles ; 38 BP (README:25, 04) fidèles ; 21 actions dans `precedents.yaml` (09:109) fidèle ; OWASP Authorization Cheat Sheet [V] (04:44, A5:30) fidèle ; `Prompt Injection` et `File Upload` cheat sheets [V] (A6:39, :49) fidèles.

Marquage [V]/[P]/[NV] : BP-37 (EW4All) marqué [P] alors que l'annexe dit [S] (M15) ; BP-28 [V] avec la mention « page ne liste pas les risques » (honnête) ; NIST (BP-30, 13:3) correctement marqué « métadonnées seulement ».

## 5. Syntaxe Mermaid

Blocs contrôlés : 01 (2), 05 (3), 06 (4 ERD), 07 (3), 08 (4), 09 (3), 13 (1), 14 (1). Jugement par grammaire, sans rendu.

- **Erreur probable** : `14-implementation-plan.md:58` (gantt) : le deux-points dans le libellé (voir M16).
- **À vérifier** : `08-agents-and-simulation.md:301` (accolades dans l'alias de participant) ; mineur.
- ERD (06) : une seule clé par ligne ; types `text`, `int`, `json`, `datetime`, `bool`, `real`, `blob`, `date` valides ; relations à libellé entre guillemets valides. Aucune erreur détectée.
- flowchart (01, 05, 07, 09, 13) : libellés entre guillemets, sous-graphes fermés, arêtes pointillées `-. "…" .->` valides. Aucune erreur détectée.
- sequenceDiagram (07, 08, 09) : `loop`, `alt/else/end` appariés ; pas de `;` ni de `#` dans les messages. Aucune erreur détectée.
- stateDiagram-v2 (08, 09) : libellés après `:` valides. Aucune erreur détectée.
- gantt (14) : format `dateFormat`, `axisFormat`, `crit`, `milestone`, `0d` valides, hors M16.

## 6. Complétude : 30 livrables

| # | Livrable | Statut | Où |
|---|---|---|---|
| 1 | Vision | Couvert | 01 |
| 2 | Registre d'exigences | Couvert | 02, A1, A2 |
| 3 | Matrice hackathon | Couvert | 03 |
| 4 | Registre de bonnes pratiques avec liens | Couvert | 04 (38 BP) |
| 5 | Architecture globale | Couvert | 05 |
| 6 | C4 (contexte, conteneurs, composants) | Couvert | 05 §5.1–5.3 |
| 7 | ERD | Couvert | 06 (4 vues) |
| 8 | Séquences des parcours principaux | **Partiel** | 07 (export/import), 08 (activation, humain, reprise), 09 (rapport). Absents : ingestion (07 §7.1 est un flowchart), revue de lacune (09 §9.7 est un stateDiagram), vérification du ledger, lancement d'exercice. |
| 9 | Machine à états des exercices | Couvert | 08 §8.10 |
| 10 | Pipeline documentaire | Couvert | 07 §7.1 |
| 11 | Export/réimport de KB | Couvert | 07 §7.6 |
| 12 | RAG agentique | Couvert | 07 §7.3, 08 §8.3–8.5 |
| 13 | Agents et outils | Couvert | 08 §8.2–8.3, §8.6 |
| 14 | Permissions et accès documentaires | Couvert | 07 §7.3, 06 `agent_kb_grant`, 11 `/studio/access`, 12 `access-matrix` |
| 15 | Création et gestion de scénarios | Couvert | 08 §8.8–8.9, 11 §11.4, 12 §12.2 |
| 16 | Moteur de simulation | Couvert | 08 §8.11 (contient B1 et M4 en aval) |
| 17 | Interventions humaines | Couvert | 08 §8.12 (route en M13 et m13) |
| 18 | Détection de lacunes | Couvert | 09 §9.1–9.5, §9.9 (priorités : M1, M2) |
| 19 | Modèle de données des lacunes | Couvert | 06 §6.4 |
| 20 | Gestionnaire de rapports | Couvert | 09 §9.10 (P1/P2 non étiquetés : m17) |
| 21 | Audit et évaluation | Couvert | 10 |
| 22 | Organisation backend | Couvert | 11 §11.1–11.3, §11.7 |
| 23 | Organisation frontend | Couvert | 11 §11.4–11.6 |
| 24 | Contrats REST | **Partiel** | 12 §12.2 (endpoints et exemples) ; « brouillon » : pas de schéma requête/réponse ni de matrice rôles × endpoints complète |
| 25 | Contrats SSE | Couvert | 12 §12.4 (+ flux de jobs) |
| 26 | Sécurité | Couvert | 13 §13.1–13.2 ; M3, M5 |
| 27 | Tests | Couvert | 13 §13.3, 11 §11.7 |
| 28 | Déploiement Sandbox | Couvert (avec réserve) | 13 §13.4 ; fichiers `deploy/` annoncés (M14) |
| 29 | Plan et chemin critique | Couvert | 14 §14.2–14.6 (B2, M16) |
| 30 | Décisions à valider | Couvert | 15 |

Bilan : 28 couverts, 2 partiels (8 et 24).

## 7. Intégrité

- **« Infalsifiable »** : le mot n'apparaît pas dans le dossier, seulement dans le titre de `appendix/A6…md:132` (« Journal d'audit infalsifiable »), que la section suivante corrige (A6:153). Le dossier lui-même dit « On ne dit pas infalsifiable » (`10:64`). **Mais** la limite (admin maître de la base et de la clé) n'est pas reportée dans `13:20` (« Falsification du ledger : … export de tête signé »), ni dans `03:25` et `03:67` (démonstration « modifier une ligne en base → entrée altérée »). Ajouter la limite à ces trois endroits (voir M3 et M11).
- **Vérifié contre non vérifié** :
  - `03:39` (« vérifié dans A1 §H ») pour Y.3172 : contenu [NV] (M13).
  - `03:58` (« cinq volets lus ») : sommaire seulement (m2).
  - `15:47` (« Vérifié (lu directement) ») : contient des vérifications par sous-agents (m1).
  - `04:68` (EW4All [P]) contre [S] dans A7 (M15).
  - `14:104` (vitesses CPU) : non mesurées (m4).
  - `05:131` (arabe) : non mesuré (m5).
  - `05:139` (versions) : non vérifiées (m6).
- **Affirmations de preuve exagérées** : `01:114`, `09:165` (M12) ; `10:53` (« externe ») (M11).
- **Fichiers annoncés comme présents** : `13:115`, `10:74` (M14).

---

## Verdict global

1. Dossier bien construit et sourcé : aucun lien cassé, citations majoritairement fidèles aux annexes, les 30 livrables sont couverts (2 partiellement).
2. Deux blocants : le hash de tête n'est pas reproductible tel que défini (B1, rejeu et golden), et le jalon P0 du mercredi 25 dépend d'un modèle réel que le plan lui-même dit possiblement indisponible (B2).
3. Majeurs : contradictions P0/P1 (G1–G10 et T3/T4 en P0 dans 03 ; G6–G9 dans 09 ; Alembic ; Ed25519 implicite en P0) ; jetons d'accès dans les URL contre la règle des logs (M5) ; incohérences du modèle DECISION et du FTS5 ; gantt invalide (M16).
4. Intégrité : deux fichiers annoncés comme présents n'existent pas ; la preuve « lacunes non pré-écrites » est survendue ; Y.3172 et EW4All sont présentés au-delà de ce qui a été lu ; la limite de l'infalsifiabilité manque à trois endroits.
5. Recommandation : traiter B1, B2 et M1 à M16 avant le gel des contrats samedi 21 ; le reste (mineurs) peut attendre la stabilisation.
