> **Annexe — Journal des vérifications exécutées par l'architecte (2026-11-21).**
> Toutes les vérifications ci-dessous ont été réalisées dans des **conteneurs éphémères** (`--rm`, aucun port exposé, aucune installation persistante sur la machine, aucun fichier du dépôt applicatif modifié). Elles ne mesurent **pas** les performances d'un environnement cible.

# A16 — Journal de vérification

## 1. PostgreSQL + pgvector (image `pgvector/pgvector:pg17`)

Machine : poste de développement personnel (Ryzen 3 3200U, 4 cœurs) — **à titre indicatif seulement** ; ces chiffres ne servent pas à dimensionner l'architecture.

| Vérification | Résultat | Statut |
|---|---|---|
| Version | PostgreSQL **17.12** ; pgvector **0.8.7** (`CREATE EXTENSION vector` réussi) | **Vérifié** |
| Configurations de recherche plein texte disponibles | `arabic, armenian, basque, catalan, danish, dutch, english, finnish, french, german, greek, hindi, hungarian, indonesian, irish, italian, lithuanian, nepali, norwegian, portuguese, romanian, russian, serbian, simple, spanish, swedish, tamil, turkish, yiddish` → **`french` et `arabic` présentes** | **Vérifié** (lève le [NV] de la v1) |
| `to_tsvector('arabic', …)` | Stemming arabe appliqué (ex. « المادة » → `ماد`, « الأرصاد » → `ارصاد`) | **Vérifié** (qualité linguistique non évaluée) |
| `to_tsvector('french', …)` | Stemming français appliqué (« opérateurs » → `oper`, « relayer » → `relai`) | **Vérifié** |
| Filtre `WHERE kb=2` (1,7 % des lignes) avec index HNSW, `ef_search=40` (défaut) sur 60 000 vecteurs aléatoires de 32 dimensions | 10 lignes renvoyées (aucune perte de rappel constatée) ; plan = parcours d'index HNSW avec *Filter* | **Risque documenté NON reproduit** sur données aléatoires uniformes ; le risque décrit par pgvector (filtre appliqué après le parcours d'index) reste à tester sur un **corpus réel** |
| Recherche exacte (index vectoriel désactivé) KB minoritaire | 10 lignes, 7 ms | Vérifié |
| Scan exact **filtré** : 5 000 lignes (KB) × `vector(1024)` sur une table de 20 000 | **45 ms** pour le top 10 | Vérifié |
| Scan exact **complet** : 20 000 × `vector(1024)` | **170 ms** pour le top 10 | Vérifié |
| Extrapolation 200 000 × 1024 (float32 → `halfvec`) | ≈ 1,7 s par scan complet (linéaire, **non mesuré**) ; le filtre par portée de siège réduit le volume | **Estimation** |

Conséquence retenue : pas d'index HNSW en P0 ; recherche exacte pré-filtrée ; HNSW partiel par KB seulement si nécessaire.

## 2. Rendu des diagrammes Mermaid

Outil : image officielle `ghcr.io/mermaid-js/mermaid-cli/mermaid-cli:latest` (Chromium `/usr/bin/chromium` dans l'image, `--no-sandbox`). Procédure : chaque bloc ```mermaid des documents est extrait puis rendu en SVG ; un rendu échoué ou contenant « Syntax error » est signalé. Résultat final : voir le bilan en tête de [00-revision-2026-11-21](../00-revision-2026-11-21.md).

## 3. Autres vérifications

| Vérification | Résultat |
|---|---|
| Liste OWASP LLM Top 10 **2026** (LLM01–LLM10) | Confirmée sur les noms de fichiers du dépôt officiel `GenAI-Security-Project/GenAI-LLM-Top10/tree/main/2026/final` (la page OWASP seule ne les liste pas) |
| Docker accessible sans installation | Oui (moteur 29.10, 2026-11-21) ; Podman absent de cette machine |
| `isolation: worktree` de l'outil Agent | Disponible ; ne voit que les fichiers **suivis** par Git |
| Date et jour | Samedi 2026-11-21 ; mercredi 2026-11-25 dans 4 jours |
